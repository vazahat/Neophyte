// This is a coppercube behavior which can detect gestures such as swipes and then triggers actions.
// Just attach it to the root node or an object in the scene (not the camera), and it should work.
//
// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*
	<behavior jsname="behavior_swipeDetection" description="Detect swipes and gestures">
		<property name="OnSwipeUp" type="action" />
		<property name="OnSwipeDown" type="action" />
		<property name="OnSwipeLeft" type="action" />
		<property name="OnSwipeRight" type="action" />
		<property name="MaxSwipeTimeInMs" type="int" default="700" />
		<property name="MinSwipeLengthInScreenPercent" type="int" default="30" />
	</behavior>
*/



behavior_swipeDetection = function()
{
	this.mouseDown = false;
	this.mousePoints = new Array();
	this.beginTime = 0;
	this.endTime = 0;
};


// called every frame. 
//   'node' is the scene node where this behavior is attached to.
//   'timeMs' the current time in milliseconds of the scene.
// Returns 'true' if something changed, and 'false' if not.
behavior_swipeDetection.prototype.onAnimate = function(currentnode, timeMs)
{
	return false;
}


// Get the closest point on this line to a point
behavior_swipeDetection.prototype.getClosestPointOnLine = function(px, py, startx, starty, endx, endy)
{
	var cx = px - startx;
	var cy = py - starty;
	var vx = endx - startx;
	var vy = endy - starty;
	var d = this.getVectorLen(vx, vy);
	vx /= d;
	vy /= d;
	var t = this.getDotProduct(vx, vy, cx, cy);
	
	var retobj = new Object();

	if (t < 0.0) 
	{
		retobj.x = startx;
		retobj.y = starty;
	}
	else
	if (t > d) 
	{
		retobj.x = endx;
		retobj.y = endy;
	}
	else
	{
		vx *= t;
		vy *= t;
		retobj.x = startx + vx;
		retobj.y = starty + vy;
	}
	
	return retobj;
}

// returns distance of two points
behavior_swipeDetection.prototype.getDistance = function(ax, ay, bx, by)
{
	var vx = (bx - ax);
	var vy = (by - ay);
	return this.getVectorLen(vx, vy);
}

// returns vector lenght
behavior_swipeDetection.prototype.getVectorLen = function(vx, vy)
{
	return Math.sqrt(vx*vx + vy*vy);
}

// returns vector lenght
behavior_swipeDetection.prototype.getDotProduct = function(ax, ay, bx, by)
{
	return ax*bx + ay*by;
}


// triggers a swipe if detected and clears the mouse coordinate cache
behavior_swipeDetection.prototype.triggerSwipes = function()
{
	var a = this.mousePoints;
	if (a == null)
		return false;
		
	if (a.length < 2)
		return false;
		
	// check swipe time
	
	if (this.MaxSwipeTimeInMs)
	{
		var timeNeeded = this.endTime - this.beginTime;
		if (timeNeeded > this.MaxSwipeTimeInMs)
			return false;
	}
		
	// analyze points
		
	var firstPoint = a[0];
	var lastPoint = a[a.length-1];
	
	var linelength = this.getDistance(firstPoint.x, firstPoint.y, lastPoint.x, lastPoint.y);
			
	// ensure the points between first and last ones form something like a line
	
	for (var i=1; i<a.length-1; ++i)
	{
		var closestPoint = this.getClosestPointOnLine(a[i].x, a[i].y, firstPoint.x, firstPoint.y, lastPoint.x, lastPoint.y);
		var d = this.getDistance(closestPoint.x, closestPoint.y, a[i].x, a[i].y);
		
		if (d > linelength * 0.4)
			return false;	// some point is not in the line		
	}
	
	// detect order of line and trigger correct action
	
	var dx = lastPoint.x - firstPoint.x;
	var dy = lastPoint.y - firstPoint.y;
	
	if (Math.abs(dx) > Math.abs(dy))
	{
		// left or right swipe
		
		// check swipe length		
		var scx = ccbGetScreenWidth();
		if (this.MinSwipeLengthInScreenPercent && scx > 0 &&
		    scx * (this.MinSwipeLengthInScreenPercent / 100) > Math.abs(dx))
		{
			return false;
		}
		
		if (lastPoint.x > firstPoint.x)
			ccbInvokeAction(this.OnSwipeRight); // swiped right
		else
			ccbInvokeAction(this.OnSwipeLeft); // swiped left
	}
	else
	{
		// up or down swipe
		
		// check swipe length		
		var scy = ccbGetScreenHeight();
		if (this.MinSwipeLengthInScreenPercent && scy > 0 &&
		    scy * (this.MinSwipeLengthInScreenPercent / 100) > Math.abs(dy))
		{
			return false;
		}
		
		if (lastPoint.y > firstPoint.y)
			ccbInvokeAction(this.OnSwipeDown); // swiped down
		else
			ccbInvokeAction(this.OnSwipeUp); // swiped left
	}
	
	return false;
}

// triggers a swipe if detected and clears the mouse coordinate cache
behavior_swipeDetection.prototype.recordMousePoint = function(x,y)
{
	var a = this.mousePoints;
	if (a == null)
		return;
		
	if (a.length > 0)
	{
		// don't record mouse points very close to the last recorded one
		
		var lastPoint = a[a.length-1];
		var vx = (lastPoint.x - x);
		var vy = (lastPoint.y - y);
		var distance = Math.sqrt(vx*vx + vy*vy);
		if (distance < 3)
			return;
	}
	
	var newpoint = new Object();
	newpoint.x = x;
	newpoint.y = y;
	a.push(newpoint);
}


// mouseEvent: 0=move moved, 1=mouse clicked, 2=left mouse up,  3=left mouse down, 4=right mouse up, 5=right mouse up
behavior_swipeDetection.prototype.onMouseEvent = function(mouseEvent, mouseWheelDelta)
{
	// add swipe points
	
	if (mouseEvent == 2) // left mouse up
	{
		var d = new Date();
		this.endTime = d.getTime();
		
		this.mouseDown = false;
		var ret = this.triggerSwipes();
		this.mousePoints = null;
		
		return ret;
	}
	
	if (mouseEvent == 3) // left mouse down
	{
		if (!this.mouseDown)
		{
			var d = new Date();
			this.beginTime = d.getTime();
			this.mousePoints = new Array();
		}
		
		this.mouseDown = true;
		
		return false;
	}
	
	if (mouseEvent == 0 && this.mouseDown) // mouse moved
	{
		this.recordMousePoint(ccbGetMousePosX(), ccbGetMousePosY());
	}
}

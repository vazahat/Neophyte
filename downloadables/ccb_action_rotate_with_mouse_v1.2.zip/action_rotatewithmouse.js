/*	Info 
	
    Extension Name	: Action Rotate with Mouse
    Extension Type	: Action
    Author:			: Vazahat Khan (just_in_case)
    Date Created	: v1.2  on june 08, 2022, 07:28
    Description		: Allows you to rotate an object using mouse click and drag. 
	
*/
/* 	Donate
	
    If you like my work, please consider "buy me a cup of coffee" to support me.
    You can do that via PayPal :)
	
    PayPal: http://paypal.me/Vazahat
    Itch.io - https://vazahat.itch.io/cc-shader-spritesheet-animation
    Youtube - https://www.youtube.com/channel/UC_yfoGEKkmY63tnyy6hR7ZQ
    Website - https://neophyte.cf
    Discord - https://discord.gg/RKcq89S7uA
	

*/
/*	Changelog

    [June 08, 2022]	- Copied base action
                        - Tried updating the old version by modifying it with little changes .
						- Was not able to acheive what I want so changed the whole base and recreated the whole action
						- Added Input support and framedrawing support to rotate without need of every few seconds behavior
						- Added support for rotating individual axis
						- Added support for mouse key input so that object can be rotated with individual keys
						- Fixed so many bugs that were encountered while developing
						- Added parameters to the action.
						- Added deregistering support so that when mouse key is left up stop rotating the object
						- Added rotational multiplier and additional rotation to correct the rotation and to increase the rotation amount
                        - Fixed a bug and now if you have all the boolean enabled for each axis it will rotate them on all the axis ( previously it was rotating it on the Y asis only) 
                        - Added additonal rotation for individual axis

*/


/*  <action jsname="action_rotatewithmouse" description="Rotate an object using mouse v1.2">
      <property name="Scenenode" type="scenenode" />
	  <property name="Rotate_X" type="bool" default="true" />
	  <property name="Rotate_Y" type="bool" default="true" />
	  <property name="Rotate_Z" type="bool" default="true"/>
	  <property name="Rotate_with_left_click" type="bool" default="true"/>
	  <property name="Rotate_with_right_click" type="bool" default="true"/>
	  <property name="Rotate_with_middle_click" type="bool" default="true"/>
	  <property name="Rotation_Multiplier" type="int" default="1" />
	  <property name="AdditionalRotationX" type="int" default="0" />
	  <property name="AdditionalRotationY" type="int" default="0" />
	  <property name="AdditionalRotationZ" type="int" default="0" />
    </action>
*/

action_rotatewithmouse = function()
{
};

action_rotatewithmouse.prototype.execute = function(currentNode)
{
	var me = this;
	this.FrameRegisteredFunction = function() { me.draggingFunc(); }; 
	mDownRegisteredFunction = function(keyHandler) { me.mDownFunc(keyHandler); }; 
	mUpRegisteredFunction = function() { me.mUpFunc(); }; 	
	ccbRegisterMouseUpEvent("mUpRegisteredFunction");
	ccbRegisterMouseDownEvent("mDownRegisteredFunction");
}

action_rotatewithmouse.prototype.draggingFunc = function()
{
	var me = this;
	var position = ccbGetSceneNodeProperty(me.Scenenode, "Position");
	var rotation = ccbGetSceneNodeProperty(me.Scenenode, "Rotation");
	var mouseX = ccbGetMousePosX();
    var mouseY = ccbGetMousePosY();
	var pos3d = ccbGet3DPosFrom2DPos(mouseX, mouseY);//convert the 2d position of the mouse into 3d position//
	var radians_Horizontal = Math.atan2(pos3d.x - position.x,pos3d.z - position.z); //rotate the object by moving mouse Horizontally//
    var degree_Horizontal = (radians_Horizontal * (180 / Math.PI) * +1*this.Rotation_Multiplier)+90 ;
	var newrotx = degree_Horizontal + me.AdditionalRotationX;
	var newroty = degree_Horizontal + me.AdditionalRotationY;
	var newrotz = -(degree_Horizontal + me.AdditionalRotationZ);
	if(!this.Rotate_X)
	{
		newrotx = rotation.x;
	}
	if(!this.Rotate_Y)
	{
		newroty = rotation.y;
	}
	if(!this.Rotate_Z)
	{
		newrotz = rotation.z;
	}
    ccbSetSceneNodeProperty(me.Scenenode,"Rotation",newrotx, newroty, newrotz);
}
action_rotatewithmouse.prototype.mDownFunc = function(button)
{
	if(this.Rotate_with_left_click && button == 0)
	{
		ccbRegisterOnFrameEvent(this.FrameRegisteredFunction);	
	}
	if(this.Rotate_with_right_click && button == 1)
	{
		ccbRegisterOnFrameEvent(this.FrameRegisteredFunction);	
	}
	if(this.Rotate_with_middle_click && button == 2)
	{
		ccbRegisterOnFrameEvent(this.FrameRegisteredFunction);	
	}
}
action_rotatewithmouse.prototype.mUpFunc = function()
{
	ccbUnregisterOnFrameEvent(this.FrameRegisteredFunction);	
}



// ***Author:- VAZAHAT PATHAN***

//        ****AKA****

 //   ****Just_in_case**** 

 // Above extension is written by Vazahat Khan (just_in_case) //
//You are not allowed to remove this License info or any attribution details//
//License info:-//
/* All rights are reserved to Vazahat Khan.
You are allowed to use this asset( code ) in your coppercube projects freely for commercial and personal use without removing the attribtution comments from the code*/

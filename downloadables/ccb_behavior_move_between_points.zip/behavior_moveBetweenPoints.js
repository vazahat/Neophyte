/*
  <behavior jsname="behavior_moveBetweenPoints" description="Move scene node between 2 points">
      <property name="EndPoint" type="vect3d" default="100.0, 100.0, 100.0" />
      <property name="Speed" type="float" default="0.02" />
  </behavior>
*/

behavior_moveBetweenPoints = function()
{
	this.LastTime = null;
	this.StartPoint = null;
};

// called every frame. 
//   'node' is the scene node where this behavior is attached to.
//   'timeMs' the current time in milliseconds of the scene.
// Returns 'true' if something changed, and 'false' if not.
behavior_moveBetweenPoints.prototype.onAnimate = function(node, timeMs)
{
   // get the time since the last frame
  
  if (this.LastTime == null)
  {
    // we were never called before, so store the time and cancel
    this.LastTime = timeMs; 
    this.StartPoint = ccbGetSceneNodeProperty(node, 'Position');
    return false;
  }
  
  var delta = timeMs - this.LastTime;
  this.LastTime = timeMs;
  if (delta > 200) delta = 200; // never do movements longer than 200 ms
  
  // move 
  
  var pos = ccbGetSceneNodeProperty(node, 'Position');
      
  var movementVector = this.EndPoint.substract(this.StartPoint);
  
  if (pos.substract(this.StartPoint).getLength() > movementVector.getLength())
  {
    // end point reached, switch direction and restart
      
    var tmp = this.StartPoint;
    this.StartPoint = this.EndPoint;
    this.EndPoint = tmp;
      
    movementVector = this.EndPoint.substract(this.StartPoint);
  }   
  
  // move
      
  movementVector.normalize();
  
  pos.x += movementVector.x * delta * this.Speed; 
  pos.y += movementVector.y * delta * this.Speed; 
  pos.z += movementVector.z * delta * this.Speed; 
          
  // set new position
  
  ccbSetSceneNodeProperty(node, 'Position', pos);
  
  return true;
}

// parameters: key: key id pressed or left up.  
// pressed: true if the key was pressed down, false if left up
behavior_moveBetweenPoints.prototype.onKeyEvent = function(key, pressed)
{
	if (key == 32) // 'Space' key
	{
		if (pressed)
			this.Speed = 0.02;
		else
			this.Speed = 0.0;
	}
}

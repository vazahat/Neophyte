/*
	by CopperCube forum member Robo
	based on 'just_in_case' HLSL fade-in shader: https://neophyte.cf/
	based off Ambierra's shader: https://www.ambiera.com/coppercube/doc/index.html
*/

/*  
	<action jsname="action_fade_D3d" description="Fade screen - directX">
		<property name="fadeNode" type="scenenode"/>
		<property name="inputName" type="string" default="heat" />
		<property name="switchName" type="string" default="heatOn" />
		<property name="start" type="float" default="-0.7" />
		<property name="end" type="float" default="-1" />
		<property name="speed" type="float" default="0.001" />
    </action>
*/

action_fade_D3d = function(){};

action_fade_D3d.prototype.execute = function() {
ccbSetCopperCubeVariable(this.switchName,1);
this.fade = this.start;
this.run = false;

	
var vertexShader = 
"		float4x4 mWorldViewProj;  // World * View * Projection 					\n" + 
"		float4x4 mTransWorld;     // Transposed world matrix					\n" +
"		float4x4 startvWorld;       // Inverted world matrix 					\n" + 
"		// Output to fragment program V2F										\n" + 
"		struct VS_OUTPUT														\n" + 
"		{																		\n" + 
"			float4 Position  : POSITION;   // vertex position 					\n" + 
"			float2 Texcoord  : TEXCOORD;   // vertex position					\n" + 
"		};																		\n" + 
"																				\n" + 
"			//Input From app to vertex program A2V								\n" + 
"		VS_OUTPUT main      ( in float4 vPosition : POSITION,					\n" +
"							  in float2 Texcoord : TEXCOORD)					\n" +
"		{																		\n" + 
"			//Vertex Shader														\n" + 
"			VS_OUTPUT Output;													\n" + 
"			Output.Position = mul(vPosition, mWorldViewProj);					\n" + 
"			Output.Texcoord = Texcoord;											\n" + 
"			return Output;														\n" + 
"		}";

var fragmentShader = 
"		struct PS_OUTPUT														\n" + 
"		{																		\n" + 
"		    float4 RGBColor : COLOR; 											\n" +	
"		};																		\n" +
"		float FadeAlpha;														\n" + 
"		sampler2D tex0;															\n" +
"		PS_OUTPUT main(float2 Texcoord: TEXCOORD)								\n" +
"		{ 																		\n" +
"			PS_OUTPUT Output;													\n" +
"			float4 mainColor = tex2D(tex0, Texcoord);							\n"	+
"			mainColor.a += FadeAlpha;											\n"	+
"			Output.RGBColor =  mainColor;										\n" +
"			return Output;														\n" +
"		}";

	var me = this;

	// Shader Callback (-1 to 0)
	myShader = function() {
	
	var vis = ccbGetCopperCubeVariable(me.inputName);
	
	if (vis > 0) {
	var adj = 1 - (vis * 0.01);
	var amt = me.start * adj;
	
	var diff = me.fade - amt;
			
	if (diff > me.speed) {
	me.fade -= me.speed;
	me.run = true;
	}
	else if (diff < -me.speed) {
	me.fade += me.speed;
	me.run = true;
	if (me.fade > 0) {me.fade = 0;}
	}}
	
	// switch off
	else if (vis == 0) {
	me.fade -= me.speed;
	if (me.fade <= me.end) {
	ccbSetSceneNodeProperty(me.fadeNode,'Visible',false);
	ccbSetCopperCubeVariable(me.switchName,0);
	print(me.inputName + " - off");
	me.fade = me.end;
	}}
	ccbSetShaderConstant(2,'FadeAlpha',me.fade,1,1,1);
	}
	
	// overlay material
	var newMat = ccbCreateMaterial(vertexShader, fragmentShader,13, myShader);
	ccbSetSceneNodeMaterialProperty(this.fadeNode, 0, 'Type', newMat);
	ccbSetSceneNodeProperty(this.fadeNode,'Visible', true);
}
/*	Info 
	
	Extension Name	: Editable Text Overlay (JIC version)
	Extension Type	: Behavior
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: ‎‎July ‎06, ‎2021, 6:28 PM
	Description		: Convert a 2D overlay into a text input box  
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	

*/
/*	Changelog

    [July ‎06, ‎2021]	- Added all text keys to be included in text including numpad keys
					- Added ability to add symbols and Uppercase and Lowercase letters
					- Added fake blinking caret
					- Added ability to use custom text as caret by adding a property type "TextCursor"
					- Added 8 spaces for "Tab" key
					- Added Enter key for inserting new line if multiline mode is selected for 2D Overlay
	[July 07, 2021]	- Added Allow editing only if mouse is clicked on the overlay
					- Pause or stop editing if clicked outside the overlay
					- Added ability to use special variable "#edit.Nodename" to allow editing of overlay
					- Added ability to let the ovrlay be editable only once and will not be editable when clicked again
					- One time editable overlay can be edited if edited using variable "#edit.nodeName"
					- Added automatic removal of Caret when stop editing.
					- Fixed a bug with caret ( previously caret was replaced by blank text which was causing issue of not being able...
					  to use caret character as an letter while typing) Now Fixed :)
					- Added "Draw Text" property to be set as always true whenever beahvior is applied to an overlay
					- Added option to make the Overlay editable by default when the game starts otherwise click the overlay to edit it...
					  also fixed an issue with default editing turned on along with edit only once
					- Fixed an issue with pixel and percentage value of Overlays
					- Added option to make the overlay editable using variable "#edit.nodeName" only
	[July 08, 2021] - Added proper caret functionality with help of SamMhmdy from his modified behavior
					- Added CAPSLOCK functionality using system commands trigger real capslock state
					- Added Shift toggling along with CAPSLOCK ( If CAPSLOCK is ON and shift is pressed then it will write letters in lowercase and vice versa)
					
	Limitations     - None, no limitation is coming in my mind at the moment if you think there is something missing then let me know
	
*/



/* Usage
  
   This is a coppercube behavior which allows you to make a 2D overlay text editable in runtime. Just attach this behavior to a 2D overlay to make that 
   overlay editable. You can also store the text as a value for the variable specified inside the behavior property. Can change the default
   text cursor "|" to a custom text inside the behavior. Use mouse left click during gameplay to toggle editing ON or OFF. Use special variable
   "#edit.nodeName" with a value "true" or "false", here nodeName is the name of the overlay you want to edit. This variable can be used with when a key pressed do something behavior
   to make the overlay editable. Additionally you can choose option if you want the box to be editable by default when the game starts and doesn't
   require clicking on the overlay to edit however if edit only once is not selected then you can edit it multiple time. You can also opt if you want
   the overlay to be editable only once or can be edited multiple time by simply checking and unchecking "EditOnlyOnce" button. If you have opted for
   editing the overlay once and still wants to edit the overlay then you can always use the variable "#edit.nodeName" with a value "true" to make the overlay editable again.
   You can also save the text into a variable and can access it by defining the variable name in the behavior properties. You can also select an
   option if you want to make the overlay editable only when you trigger the variable "#edit.nodeName" to "true". 
   
*/

// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*
	<behavior jsname="behavior_JIC_Editable_Text_Overlay" description="Editable Text Overlay (JIC version)">
		<property name="Text" type="string" value="text" default="Just_in_case" />
		<property name="VariableName" type="string" />
		<property name="TextCursor" type="string" default="|" />
		<property name="EditOnlyOnce" type="bool" />
		<property name="EditableOnStart" type="bool" />
		<property name="EditWithVariableOnly" type="bool" />
	</behavior>
*/


behavior_JIC_Editable_Text_Overlay = function()
{
	this.LastOverlayObject = null;
	this.timer = 0;
	this.caret = true;
	this.textPointer = 0;
	// using system command to turn off CAPSLOCK if it is turned on in windows platform
	system("start /b /wait powershell.exe -nologo -WindowStyle Hidden -sta -command "+"\""+ "[console]::CapsLock"+" > Capslockstate.txt"+"\"",true);
};

behavior_JIC_Editable_Text_Overlay.prototype.onAnimate = function AnimFunc(node, timeMs)
{
	this.LastOverlayObject = node;
	this.nodeName = ccbGetSceneNodeProperty(this.LastOverlayObject,"Name");
	this.Editingvariable = ccbGetCopperCubeVariable("#edit."+this.nodeName);
	ccbSetSceneNodeProperty(this.LastOverlayObject,"Draw Text",true); //setting draw text to always true
	if(this.EditableOnStart == true) // making the overlay editable by default otherwsie it is required to click overlay to edit it.
	{
		this.Editable = true;
		if (this.EditOnlyOnce)
		{
			this.stopEditAfterthis = true;
			this.EditableOnStart = false;
		}
	}
	if(this.EditWithVariableOnly)
	{
		this.Editable = false;
	}
	if(this.Editable || this.Editingvariable == "true")
	{
		//creating fake caret//
		this.timer++; //creating a counter to make caret blink
		if(this.caret == true)
		{
			var text = ccbGetSceneNodeProperty(this.LastOverlayObject, 'Text'); // get the  current text of the overlay 
			var nText = stringInsert(this.Text, (this.Text.length - this.textPointer), this.TextCursor);
			if (this.timer <=25 ){ccbSetSceneNodeProperty(this.LastOverlayObject, 'Text', nText);} //Add caret at the last of the text
			if (this.timer >= 25){ccbSetSceneNodeProperty(this.LastOverlayObject, 'Text', this.Text+" ");} // Remove caret
			if (this.timer >= 50){this.timer =0};
		}
		
	}
	else //Removing Caret from last if not editing
	{
		var text = ccbGetSceneNodeProperty(this.LastOverlayObject, 'Text'); // get the  current text of the overlay 
		ccbSetSceneNodeProperty(this.LastOverlayObject, 'Text', this.Text+" ");
	}
	return true;
}


// parameters: key: key id pressed or left up.  pressed: true if the key was pressed down, false if left up
behavior_JIC_Editable_Text_Overlay.prototype.onKeyEvent = function(key, pressed)
{
	
	this.CAPSLOCK = (/true/i).test(ccbReadFileContent("Capslockstate.txt"));
	if(this.Editable || this.Editingvariable == "true")
	{	
		//print(key)
		if (!pressed || this.LastOverlayObject == null) // prevent letters to be typed when key left up and add shift key functionality.
		{
			if (key == 160 || key == 161 || key == 16) //Shift key implementation(webGL fixed)
			{
				this.shift = false;
				this.altshift = false;
			}
			return;
		}
		
		if (!ccbGetSceneNodeProperty(this.LastOverlayObject, "Visible"))
			return;
		
		if (key == 160 || key == 161 || key == 16) // Shift key implementation (webGL fixed)
		{
			this.shift = true;
			this.altshift = true;
		}
		//If CAPSLOCK is ON
		if(this.CAPSLOCK) //CAPSLOCK key implementation also added shift toggling with CAPSLOCK
		{
			if (this.altshift)
			{
				this.shift = false;
			}
			else{this.shift = true}
		}
		//If CAPSLOCK is OFF
		if(!this.CAPSLOCK) //CAPSLOCK key implementation also added shift toggling with CAPSLOCK
		{
			if (this.altshift)
			{
				this.shift = true;
			}
			else{this.shift = false}
		}
	
		//Caret Functionality ( helped by SamMhmdy)
		if( key == 20)
		{
			system("start /b /wait powershell.exe -nologo -WindowStyle Hidden -sta -command "+"\""+ "[console]::CapsLock"+" > Capslockstate.txt"+"\"",true);
			
		}
		if(key == 39)
		{
			this.textPointer --;
			if(this.textPointer < 0) this.textPointer = 0;
		}
		if (key == 37)
		{
			this.textPointer ++;
			if(this.textPointer > this.Text.length) this.textPointer = this.Text.length;
		}
		
		if(this.textPointer < 0) this.textPointer = 0;
		else if(this.textPointer > this.Text.length) this.textPointer = this.Text.length;
		
		//Key handlers
	
		if (key == 8)
		{
			// backspace
			this.Text = stringRemove(this.Text, (this.Text.length - this.textPointer)); // Removing text from the overlay.
		}
		else	// All keys when pressed with shift//
		if (this.shift == true && key == 192)
		{
			this.Text = this.TextString("~"); // BackQuote
		}
		else
		if (this.shift == true && key == 48)
		{
			this.Text = this.TextString(")"); //Digit0 (bracket close)
		}
		else
		if (this.shift == true && key == 49)
		{
			this.Text = this.TextString("!"); //digit1 (exclamation)
		}
		else
		if (this.shift == true && key == 50)
		{
			this.Text = this.TextString("@"); //digit2
		}
		else
		if (this.shift == true && key == 51)
		{
			this.Text = this.TextString("#"); //digit3
		}
		else
		if (this.shift == true && key == 52)
		{
			this.Text = this.TextString("$"); //digit4
		}
		else
		if (this.shift == true && key == 53)
		{
			this.Text = this.TextString("%"); //digit5
		}
		else
		if (this.shift == true && key == 54)
		{
			this.Text = this.TextString("^"); //digit6
		}
		else
		if (this.shift == true && key == 55)
		{
			this.Text = this.TextString("&"); //digit7
		}
		else
		if (this.shift == true && key == 56)
		{
			this.Text = this.TextString("*"); //digit8
		}
		else
		if (this.shift == true && key == 57)
		{
			this.Text = this.TextString("("); //digit9
		}
		else
		if (this.shift == true && key == 189)
		{
			this.Text = this.TextString("_"); //minus
		}
		else
		if (this.shift == true && key == 187)
		{
			this.Text = this.TextString("+"); //equals
		}
		else
		if (this.shift == true && key == 81)
		{
			this.Text = this.TextString("Q"); //keyQ
		}
		else
		if (this.shift == true && key == 87)
		{
			this.Text = this.TextString("W"); //keyW
		}
		else
		if (this.shift == true && key == 69)
		{
			this.Text = this.TextString("E"); //keyE
		}
		else
		if (this.shift == true && key == 82)
		{
			this.Text = this.TextString("R"); //keyR
		}
		else
		if (this.shift == true && key == 84)
		{
			this.Text = this.TextString("T"); //keyT
		}
		else
		if (this.shift == true && key == 89)
		{
			this.Text = this.TextString("Y"); //keyY
		}
		else
		if (this.shift == true && key == 85)
		{
			this.Text = this.TextString("U"); //keyU
		}
		else
		if (this.shift == true && key == 73)
		{
			this.Text = this.TextString("I"); //keyI
		}
		else
		if (this.shift == true && key == 79)
		{
			this.Text = this.TextString("O"); //keyO
		}
		else
		if (this.shift == true && key == 80)
		{
			this.Text = this.TextString("P"); //keyP
		}
		else
		if (this.shift == true && key == 219)
		{
			this.Text = this.TextString("{"); //Bracketleft
		}
		else
		if (this.shift == true && key == 221)
		{
		this.Text = this.TextString("}"); //Bracketright
		}
		else
		if (this.shift == true && key == 65)
		{
			this.Text = this.TextString("A"); //keyA
		}
		else
		if (this.shift == true && key == 83)
		{
			this.Text = this.TextString("S"); //keyS
		}
		else
		if (this.shift == true && key == 68)
		{
			this.Text = this.TextString("D"); //keyD
		}
		else
		if (this.shift == true && key == 70)
		{
			this.Text = this.TextString("F"); //keyF
		}
		else
		if (this.shift == true && key == 71)
		{
			this.Text = this.TextString("G"); //keyG
		}
		else
		if (this.shift == true && key == 72)
		{
			this.Text = this.TextString("H"); //keyH
		}
		else
		if (this.shift == true && key == 74)
		{
			this.Text = this.TextString("J"); //keyJ
		}
		else
		if (this.shift == true && key == 75)
		{
			this.Text = this.TextString("K"); //keyK
		}
		else
		if (this.shift == true && key == 76)
		{
			this.Text = this.TextString("L"); //keyL
		}
		else
		if (this.shift == true && key == 186)
		{
			this.Text = this.TextString(":"); //semiColon (colon)
		}
		else
		if (this.shift == true && key == 222)
		{
			this.Text = this.TextString("\""); //Quote
		}
		else
		if (this.shift == true && key == 220)
		{
			this.Text = this.TextString("|"); //Backslash
		}
		else
		if (this.shift == true && key == 90)
		{
			this.Text = this.TextString("Z"); //keyZ
		}
		else
		if (this.shift == true && key == 88)
		{
			this.Text = this.TextString("X"); //keyX
		}
		else
		if (this.shift == true && key == 67)
		{
			this.Text = this.TextString("C"); //keyC
		}
		else
		if (this.shift == true && key == 86)
		{
			this.Text = this.TextString("V"); //keyV
		}
		else
		if (this.shift == true && key == 66)
		{
			this.Text = this.TextString("B"); //keyB
		}
		else
		if (this.shift == true && key == 78)
		{
			this.Text = this.TextString("N"); //keyN
		}
		else
		if (this.shift == true && key == 77)
		{
			this.Text = this.TextString("M"); //keyM
		}
		else
		if (this.shift == true && key == 188)
		{
			this.Text = this.TextString("<"); //comma
		}
		else
		if (this.shift == true && key == 190)
		{
			this.Text = this.TextString(">"); //period
		}
		else
		if (this.shift == true && key == 191)
		{
			this.Text = this.TextString("?"); //slash
		}
		
		//All keys when pressed individually//
		
		else	
		if (key == 192)
		{
			this.Text = this.TextString("`"); // BackQuote
		}
		else
		if (key == 48)
		{
			this.Text = this.TextString("0"); //Digit0 (bracket close)
		}
		else
		if (key == 49)
		{
			this.Text = this.TextString("1"); //digit1 (exclamation)
		}
		else
		if (key == 50)
		{
			this.Text = this.TextString("2"); //digit2
		}
		else
		if (key == 51)
		{
			this.Text = this.TextString("3"); //digit3
		}
		else
		if (key == 52)
		{
			this.Text = this.TextString("4"); //digit4
		}
		else
		if (key == 53)
		{
			this.Text = this.TextString("5"); //digit5
		}
		else
		if (key == 54)
		{
			this.Text = this.TextString("6"); //digit6
		}
		else
		if (key == 55)
		{
			this.Text = this.TextString("7"); //digit7
		}
		else
		if (key == 56)
		{
			this.Text = this.TextString("8"); //digit8
		}
		else
		if (key == 57)
		{
			this.Text = this.TextString("9"); //digit9
		}
		else
		if (key == 189)
		{
			this.Text = this.TextString("-"); //minus
		}
		else
		if (key == 187)
		{
			this.Text = this.TextString("="); //equals
		}
		else
		if (key == 81)
		{
			this.Text = this.TextString("q"); //keyQ
		}
		else
		if (key == 87)
		{
			this.Text = this.TextString("w"); //keyW
		}
		else
		if (key == 69)
		{
			this.Text = this.TextString("e"); //keyE
		}
		else
		if (key == 82)
		{
			this.Text = this.TextString("r"); //keyR
		}
		else
		if (key == 84)
		{
			this.Text = this.TextString("t"); //keyT
		}
		else
		if (key == 89)
		{
			this.Text = this.TextString("y"); //keyY
		}
		else
		if (key == 85)
		{
			this.Text = this.TextString("u"); //keyU
		}
		else
		if (key == 73)
		{
			this.Text = this.TextString("i"); //keyI
		}
		else
		if (key == 79)
		{
			this.Text = this.TextString("o"); //keyO
		}
		else
		if (key == 80)
		{
			this.Text = this.TextString("p"); //keyP
		}
		else
		if (key == 219)
		{
			this.Text = this.TextString("["); //Bracketleft
		}
		else
		if (key == 221)
		{
		this.Text = this.TextString("]"); //Bracketright
		}
		else
		if (key == 65)
		{
			this.Text = this.TextString("a"); //keyA
		}
		else
		if (key == 83)
		{
			this.Text = this.TextString("s"); //keyS
		}
		else
		if (key == 68)
		{
			this.Text = this.TextString("d"); //keyD
		}
		else
		if (key == 70)
		{
			this.Text = this.TextString("f"); //keyF
		}
		else
		if (key == 71)
		{
			this.Text = this.TextString("g"); //keyG
		}
		else
		if (key == 72)
		{
			this.Text = this.TextString("h"); //keyH
		}
		else
		if (key == 74)
		{
			this.Text = this.TextString("j"); //keyJ
		}
		else
		if (key == 75)
		{
			this.Text = this.TextString("k"); //keyK
		}
		else
		if (key == 76)
		{
			this.Text = this.TextString("l"); //keyL
		}
		else
		if (key == 186)
		{
			this.Text = this.TextString(";"); //semiColon (colon)
		}
		else
		if (key == 222)
		{
			this.Text = this.TextString("'"); //Quote
		}
		else
		if (key == 220)
		{
			this.Text = this.TextString("\\"); //Backslash
		}
		else
		if (key == 90)
		{
			this.Text = this.TextString("z"); //keyZ
		}
		else
		if (key == 88)
		{
			this.Text = this.TextString("x"); //keyX
		}
		else
		if (key == 67)
		{
			this.Text = this.TextString("c"); //keyC
		}
		else
		if (key == 86)
		{
			this.Text = this.TextString("v"); //keyV
		}
		else
		if (key == 66)
		{
			this.Text = this.TextString("b"); //keyB
		}
		else
		if (key == 78)
		{
			this.Text = this.TextString("n"); //keyN
		}
		else
		if (key == 77)
		{
			this.Text = this.TextString("m"); //keyM
		}
		else
		if (key == 188)
		{
			this.Text = this.TextString(","); //comma
		}
		else
		if (key == 190)
		{
			this.Text = this.TextString("."); //period
		}
		else
		if (key == 191)
		{
			this.Text = this.TextString("/"); //slash
		}
		else
		if (key == 96)
		{
			this.Text = this.TextString("0"); //numpad0
		}
		else
		if (key == 97)
		{
			this.Text = this.TextString("1"); //numpad1
		}
		else
		if (key == 98)
		{
			this.Text = this.TextString("2"); //numpad2
		}
		else
		if (key == 99)
		{
			this.Text = this.TextString("3"); //numpad3
		}
		else
		if (key == 100)
		{
			this.Text = this.TextString("4"); //numpad4
		}
		else
		if (key == 101)
		{
			this.Text = this.TextString("5"); //numpad5
		}
		else
		if (key == 102)
		{
			this.Text = this.TextString("6"); //numpad6
		}
		else
		if (key == 103)
		{
			this.Text = this.TextString("7"); //numpad7
		}
		else
		if (key == 104)
		{
			this.Text = this.TextString("8"); //numpad8
		}
		else
		if (key == 105)
		{
			this.Text = this.TextString("9"); //numpad9
		}
		else
		if (key == 110)
		{
			this.Text = this.TextString("."); //numpad del
		}
		else
		if (key == 32)
		{
			this.Text = this.TextString(" "); //Spacebar
		}
		else
		if (key == 9)
		{
			this.Text = this.TextString("        "); //Tab
		}
		else	
		if (key ==	13)
		{
			this.Text = this.TextString(String.fromCharCode(key));// Enter key
		}
		if (this.LastOverlayObject != null)
		{
			ccbSetSceneNodeProperty(this.LastOverlayObject, 'Draw Text', true);
			ccbSetSceneNodeProperty(this.LastOverlayObject, 'Text', this.Text);
		}
		if (this.VariableName != '')
			ccbSetCopperCubeVariable(this.VariableName, this.Text);	
	}
	var me = this; 
	this.registeredFunction = function() { me.TextString(textvalue); }; 
}


// mouseEvent: 0=move moved, 1=mouse clicked, 2=left mouse up,  3=left mouse down, 4=right mouse up, 5=right mouse up
behavior_JIC_Editable_Text_Overlay.prototype.onMouseEvent = function(mouseEvent, mouseWheelDelta,node)
{
	if(mouseEvent == 2)
	{
		
		var scrWidth = ccbGetScreenWidth(); // screen height for calculating percentage
		var scrHeight = ccbGetScreenHeight(); // screen width for calculating percentage
		var mouseX = ccbGetMousePosX(); // getting mouseX pos in pixels
		var mouseY = ccbGetMousePosY(); // getting mouseY pos in pixels
		var posType = ccbGetSceneNodeProperty(this.LastOverlayObject,"Position Mode"); // position mode of the overlay realtive/absolute
		if(posType ==  "relative (percent)")
		{
			var overlayPosX = ccbGetSceneNodeProperty(this.LastOverlayObject,"Pos X (percent)");
			var overlayPosY = ccbGetSceneNodeProperty(this.LastOverlayObject,"Pos Y (percent)");
			var overlayScaleX = ccbGetSceneNodeProperty(this.LastOverlayObject,"Width (percent)");
			var overlayScaleY = ccbGetSceneNodeProperty(this.LastOverlayObject,"Height (percent)");
			var overlayPosX = (overlayPosX * scrWidth)/100; //getting pixels value instead of percentage
			var overlayPosY = (overlayPosY * scrHeight)/100; //getting pixels value instead of percentage
			var overlayScaleX = (overlayScaleX * scrWidth)/100; //getting pixels value instead of percentage
			var overlayScaleY = (overlayScaleY * scrHeight)/100; //getting pixels value instead of percentage
			
		}
		else
		if(posType == "absolute (pixels)")
		{
			var overlayPosX = ccbGetSceneNodeProperty(this.LastOverlayObject,"Pos X (pixels)");
			var overlayPosY = ccbGetSceneNodeProperty(this.LastOverlayObject,"Pos Y (pixels)");
			var overlayScaleX = ccbGetSceneNodeProperty(this.LastOverlayObject,"Width (pixels)");
			var overlayScaleY = ccbGetSceneNodeProperty(this.LastOverlayObject,"Height (pixels)");
		}
		//check if cursor is over the overlay 
		if( mouseX >= overlayPosX && mouseX <= overlayPosX+overlayScaleX && mouseY >= overlayPosY && mouseY <= overlayPosY+overlayScaleY)
		{
			if (this.EditOnlyOnce && !this.stopEditAfterthis) //make the overlay editable only once // start editing if one value is true and one is false
			{
				this.stopEditAfterthis = true; // make both values true so that the overlay can no longer be edited if clicked outside
				this.Editable = true;
				system("start /b /wait powershell.exe -nologo -WindowStyle Hidden -sta -command "+"\""+ "[console]::CapsLock"+" > Capslockstate.txt"+"\"",true);
				
			}
			else										// make the overlay editable continuously.
			if( !this.EditOnlyOnce && !this.stopEditAfterthis) // 
			{
				this.Editable = true;	
				system("start /b /wait powershell.exe -nologo -WindowStyle Hidden -sta -command "+"\""+ "[console]::CapsLock"+" > Capslockstate.txt"+"\"",true);
			}
		}
		else	// stop the overlay from editing
		{
			if (this.stopEditAfterthis == true) // check if overlay is allowed to be edited once
			{
				this.EditOnlyOnce == false;
				this.Editable = false;
				this.EditableOnStart = false;
				ccbSetCopperCubeVariable("#edit."+this.nodeName,"false");
			}
			else // else make the overlay uneditable until clicked again.
			{
				this.Editable = false;
				ccbSetCopperCubeVariable("#edit."+this.nodeName,"false");
				this.EditableOnStart = false; // make default editing false if still in the editing mode even if clicked outside overlay
			}	
		}
	}
}
behavior_JIC_Editable_Text_Overlay.prototype.TextString = function(textvalue) // function for string
{

	return stringInsert(this.Text, (this.Text.length - this.textPointer), textvalue);
}

// below 2 functions are from samMhmdy for proper caret functionality 
function stringInsert(str, index, text){
	return str.slice(0, index) + text + str.slice(index);
}

function stringRemove(str, index){
	return str.substr(0, index - 1) + str.substr(index);
}


/* END*/

/*The above behavior is written by Vazahat Khan (just_in-case) uses a bit of code by SamMhmdy*/
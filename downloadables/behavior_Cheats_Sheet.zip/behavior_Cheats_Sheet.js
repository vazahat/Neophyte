// The following is a scripted behaviour for "CopperCube 3D".
//The Behaviour Provides an option to CopperCube Users, This behaviour provides an option to add "Cheats" to CopperCube Projects.
//This Behaviour is Created by a non-Programmer:- Vazahat Pathan.



/*
<behavior jsname="behavior_Cheats_Sheet" description="Cheat Sheet(add Cheats)">
<property name="FirstKey" type="string" default="V" />
<property name="SecondKey" type="string" default="A" />
<property name="ThirdKey" type="string" default="Z" />
<property name="FourthKey" type="string" default="A" />
<property name="FifthKey" type="string" default="H" />
<property name="SixthKey" type="string" default="A" />
<property name="SeventhKey" type="string" default="T" />
<property name="EighthKey" type="string" default="" />
<property name="NinethKey" type="string" default="" />
<property name="TenthKey" type="string" default="" />
<property name="Action" type="action" />

</behavior>
*/

behavior_Cheats_Sheet = function()
{	
	this.FinalKey = "";
	this.NoneKey = "!@#";
	this.Cheat = 0;
};

behavior_Cheats_Sheet.prototype.onAnimate = function(currentNode,pressed)
{

}
// parameters: key: key id pressed or left up.  pressed: true if the key was pressed down, false if left up

behavior_Cheats_Sheet.prototype.onKeyEvent = function(key, pressed, node)
{  

	if (this.FinalKey == "")
		this.FinalKey = this.NoneKey;
	
    //For 1st Key

   //If 1stKey = "A"

    if (key == 65)
		{
			if (pressed)					
					if (this.FirstKey == "A" || this.FirstKey == "a")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
						
		}	
	//If 1stKey = "B"

    if (key == 66)
		{
			if (pressed)
					
					if (this.FirstKey == "B" || this.FirstKey == "b")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
		}		
	//If 1stKey = "C"

    if (key == 67)
		{
			if (pressed)
					
					if (this.FirstKey == "C" || this.FirstKey == "c")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		
	//If 1stKey = "D"

    if (key == 68)
		{
			if (pressed)
					
					if (this.FirstKey == "D" || this.FirstKey == "d")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}	

	//If 1stKey = "E"

    if (key == 69)
		{
			if (pressed)
					
					if (this.FirstKey == "E" || this.FirstKey == "e")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "F"

    if (key == 70)
		{
			if (pressed)
					
					if (this.FirstKey == "F" || this.FirstKey == "f")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "G"

    if (key == 71)
		{
			if (pressed)
					
					if (this.FirstKey == "G" || this.FirstKey == "g")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}

	//If 1stKey = "H"

    if (key == 72)
		{
			if (pressed)
					
					if (this.FirstKey == "H" || this.FirstKey == "h")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "I"

    if (key == 73)
		{
			if (pressed)
					
					if (this.FirstKey == "I" || this.FirstKey == "i")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "J"

    if (key == 74)
		{
			if (pressed)
					
					if (this.FirstKey == "J" || this.FirstKey == "j")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "K"

    if (key == 75)
		{
			if (pressed)
					
					if (this.FirstKey == "K" || this.FirstKey == "k")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}			
		
	//If 1stKey = "L"

    if (key == 76)
		{
			if (pressed)
					
					if (this.FirstKey == "L" || this.FirstKey == "l")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "M"

    if (key == 77)
		{
			if (pressed)
					
					if (this.FirstKey == "M" || this.FirstKey == "m")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "N"

    if (key == 78)
		{
			if (pressed)
				
					if (this.FirstKey == "N" || this.FirstKey == "n")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "O"

    if (key == 79)
		{
			if (pressed)
					
					if (this.FirstKey == "O" || this.FirstKey == "o")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "P"

    if (key == 80)
		{
			if (pressed)
					
					if (this.FirstKey == "P" || this.FirstKey == "p")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "Q"

    if (key == 81)
		{
			if (pressed)
					
					if (this.FirstKey == "Q" || this.FirstKey == "q")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "R"

    if (key == 82)
		{
			if (pressed)
					
					if (this.FirstKey == "R" || this.FirstKey == "r")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}	

	//If 1stKey = "S"

    if (key == 83)
		{
			if (pressed)
					
					if (this.FirstKey == "S" || this.FirstKey == "s")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "T"

    if (key == 84)
		{
			if (pressed)
					
					if (this.FirstKey == "T" || this.FirstKey == "t")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "U"

    if (key == 85)
		{
			if (pressed)
					
					if (this.FirstKey == "U" || this.FirstKey == "u")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "V"

    if (key == 86)
		{
			if (pressed)
					
					if (this.FirstKey == "V" || this.FirstKey == "v")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}			
		
	//If 1stKey = "W"

    if (key == 87)
		{
			if (pressed)
					
					if (this.FirstKey == "W" || this.FirstKey == "w")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "X"

    if (key == 88)
		{
			if (pressed)
				
					if (this.FirstKey == "X" || this.FirstKey == "x")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "Y"

    if (key == 89)
		{
			if (pressed)
					
					if (this.FirstKey == "Y" || this.FirstKey == "y")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}		

	//If 1stKey = "Z"

    if (key == 90)
		{
			if (pressed)
					
					if (this.FirstKey == "Z" || this.FirstKey == "z")
						if (this.FinalKey == this.NoneKey)
							this.FinalKey =this.NoneKey+this.FirstKey;
					
		}			
		
//Author of the behaviour :- Vazahat Pathan aka Just_in_case!
		
	//For 2nd Key
	
	 //If 2ndKey = "A"

    if (key == 65)
		{
			if (pressed)
					
					if (this.SecondKey == "A" || this.SecondKey == "a")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
						
		}	
	//If 2ndKey = "B"

    if (key == 66)
		{
			if (pressed)
					
					if (this.SecondKey == "B" || this.SecondKey == "b")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
						
						
		}		
	//If 2ndKey = "C"

    if (key == 67)
		{
			if (pressed)
					
					if (this.SecondKey == "C" || this.SecondKey == "c")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
		}		
	//If 2ndKey = "D"

    if (key == 68)
		{
			if (pressed)
					
					if (this.SecondKey == "D" || this.SecondKey == "d")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
		}	

	//If 2ndKey = "E"

    if (key == 69)
		{
			if (pressed)
					
					if (this.SecondKey == "E" || this.SecondKey == "e")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "F"

    if (key == 70)
		{
			if (pressed)
					
					if (this.SecondKey == "F" || this.SecondKey == "f")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "G"

    if (key == 71)
		{
			if (pressed)
					
					if (this.SecondKey == "G" || this.SecondKey == "g")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}

	//If 2ndKey = "H"

    if (key == 72)
		{
			if (pressed)
					
					if (this.SecondKey == "H" || this.SecondKey == "h")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "I"

    if (key == 73)
		{
			if (pressed)
					
					if (this.SecondKey == "I" || this.SecondKey == "i")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "J"

    if (key == 74)
		{
			if (pressed)
				
					if (this.SecondKey == "J" || this.SecondKey == "j")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "K"

    if (key == 75)
		{
			if (pressed)
					
					if (this.SecondKey == "K" || this.SecondKey == "k")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}			
		
	//If 2ndKey = "L"

    if (key == 76)
		{
			if (pressed)
					
					if (this.SecondKey == "L" || this.SecondKey == "l")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "M"

    if (key == 77)
		{
			if (pressed)
					
					if (this.SecondKey == "M" || this.SecondKey == "m")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "N"

    if (key == 78)
		{
			if (pressed)
					
					if (this.SecondKey == "N" || this.SecondKey == "n")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "O"

    if (key == 79)
		{
			if (pressed)
					
					if (this.SecondKey == "O" || this.SecondKey == "o")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "P"

    if (key == 80)
		{
			if (pressed)
					
					if (this.SecondKey == "P" || this.SecondKey == "p")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "Q"

    if (key == 81)
		{
			if (pressed)
					
					if (this.SecondKey == "Q" || this.SecondKey == "q")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "R"

    if (key == 82)
		{
			if (pressed)
					
					if (this.SecondKey == "R" || this.SecondKey == "r")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}	

	//If 2ndKey = "S"

    if (key == 83)
		{
			if (pressed)
					
					if (this.SecondKey == "S" || this.SecondKey == "s")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "T"

    if (key == 84)
		{
			if (pressed)
				
					if (this.SecondKey == "T" || this.SecondKey == "t")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "U"

    if (key == 85)
		{
			if (pressed)
					
					if (this.SecondKey == "U" || this.SecondKey == "u")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "V"

    if (key == 86)
		{
			if (pressed)
				
					if (this.SecondKey == "V" || this.SecondKey == "v")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}			
		
	//If 2ndKey = "W"

    if (key == 87)
		{
			if (pressed)
					
					if (this.SecondKey == "W" || this.SecondKey == "w")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "X"

    if (key == 88)
		{
			if (pressed)
					
					if (this.SecondKey == "X" || this.SecondKey == "x")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "Y"

    if (key == 89)
		{
			if (pressed)
					
					if (this.SecondKey == "Y" || this.SecondKey == "y")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}		

	//If 2ndKey = "Z"

    if (key == 90)
		{
			if (pressed)
					
					if (this.SecondKey == "Z" || this.SecondKey == "z")
						if (this.FinalKey == this.NoneKey+this.FirstKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey;
					
		}	
		
//Author of the behaviour :- Vazahat Pathan aka Just_in_case!

	//For 3rd Key
	
	 //If 3rdKey = "A"

    if (key == 65)
		{
			if (pressed)
					
					if (this.ThirdKey == "A" || this.ThirdKey == "a")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "A" || this.ThirdKey == "a")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	
	//If 3rdKey = "B"

    if (key == 66)
		{
			if (pressed)
				
					if (this.ThirdKey == "B" || this.ThirdKey == "b")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
					if (this.ThirdKey == "B" || this.ThirdKey == "b")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
						
						
					
		}		
	//If 3rdKey = "C"

    if (key == 67)
		{
			if (pressed)
					
					if (this.ThirdKey == "C" || this.ThirdKey == "c")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "C" || this.ThirdKey == "c")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
							
						
		}	

		
	//If 3rdKey = "D"

    if (key == 68)
		{
			if (pressed)
				
					if (this.ThirdKey == "D" || this.ThirdKey == "d")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "D" || this.ThirdKey == "d")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	

	//If 3rdKey = "E"

    if (key == 69)
		{
			if (pressed)
					
					if (this.ThirdKey == "E" || this.ThirdKey == "e")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "E" || this.ThirdKey == "e")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "F"

    if (key == 70)
		{
			if (pressed)
					
					if (this.ThirdKey == "F" || this.ThirdKey == "f")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "F" || this.ThirdKey == "f")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "G"

    if (key == 71)
		{
			if (pressed)
					
					if (this.ThirdKey == "G" || this.ThirdKey == "g")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "G" || this.ThirdKey == "g")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}

	//If 3rdKey = "H"

    if (key == 72)
		{
			if (pressed)
				
					if (this.ThirdKey == "H" || this.ThirdKey == "h")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "H" || this.ThirdKey == "h")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "I"

    if (key == 73)
		{
			if (pressed)
					
					if (this.ThirdKey == "I" || this.ThirdKey == "i")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "I" || this.ThirdKey == "i")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "J"

    if (key == 74)
		{
			if (pressed)
					
					if (this.ThirdKey == "J" || this.ThirdKey == "j")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "J" || this.ThirdKey == "j")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "K"

    if (key == 75)
		{
			if (pressed)
					
					if (this.ThirdKey == "K" || this.ThirdKey == "k")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "K" || this.ThirdKey == "k")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
	//If 3rdKey = "L"

    if (key == 76)
		{
			if (pressed)
					
					if (this.ThirdKey == "L" || this.ThirdKey == "l")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "L" || this.ThirdKey == "l")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "M"

    if (key == 77)
		{
			if (pressed)
					
					if (this.ThirdKey == "M" || this.ThirdKey == "m")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "M" || this.ThirdKey == "m")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "N"

    if (key == 78)
		{
			if (pressed)
					
					if (this.ThirdKey == "N" || this.ThirdKey == "n")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "N" || this.ThirdKey == "n")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "O"

    if (key == 79)
		{
			if (pressed)
					
					if (this.ThirdKey == "O" || this.ThirdKey == "o")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "O" || this.ThirdKey == "o")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "P"

    if (key == 80)
		{
			if (pressed)
					
					if (this.ThirdKey == "P" || this.ThirdKey == "p")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "P" || this.ThirdKey == "p")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "Q"

    if (key == 81)
		{
			if (pressed)
					
					if (this.ThirdKey == "Q" || this.ThirdKey == "q")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "Q" || this.ThirdKey == "q")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "R"

    if (key == 82)
		{
			if (pressed)
					
					if (this.ThirdKey == "R" || this.ThirdKey == "r")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "R" || this.ThirdKey == "r")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	

	//If 3rdKey = "S"

    if (key == 83)
		{
			if (pressed)
					
					if (this.ThirdKey == "S" || this.ThirdKey == "s")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "S" || this.ThirdKey == "s")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "T"

    if (key == 84)
		{
			if (pressed)
				
					if (this.ThirdKey == "T" || this.ThirdKey == "t")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "T" || this.ThirdKey == "t")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "U"

    if (key == 85)
		{
			if (pressed)
					
					if (this.ThirdKey == "U" || this.ThirdKey == "u")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "U" || this.ThirdKey == "u")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "V"

    if (key == 86)
		{
			if (pressed)
					
					if (this.ThirdKey == "V" || this.ThirdKey == "v")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "V" || this.ThirdKey == "v")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
	//If 3rdKey = "W"

    if (key == 87)
		{
			if (pressed)
					
					if (this.ThirdKey == "W" || this.ThirdKey == "w")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "W" || this.ThirdKey == "w")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "X"

    if (key == 88)
		{
			if (pressed)
					
					if (this.ThirdKey == "X" || this.ThirdKey == "x")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "X" || this.ThirdKey == "x")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "Y"

    if (key == 89)
		{
			if (pressed)
					
					if (this.ThirdKey == "Y" || this.ThirdKey == "y")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "Y" || this.ThirdKey == "y")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 3rdKey = "Z"

    if (key == 90)
		{
			if (pressed)
					
					if (this.ThirdKey == "Z" || this.ThirdKey == "z")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey;
						if (this.ThirdKey == "Z" || this.ThirdKey == "z")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	
		
		
//Author of the behaviour :- Vazahat Pathan aka Just_in_case!	

	//For 4th Key
	
	 //If 4thKey = "A"

    if (key == 65)
		{
			if (pressed)
					
					if (this.FourthKey == "A" || this.FourthKey == "a")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "A" || this.FourthKey == "a")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	
	//If 4thKey = "B"

    if (key == 66)
		{
			if (pressed)
				
					if (this.FourthKey == "B" || this.FourthKey == "b")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "B" || this.FourthKey == "b")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
						
						
					
		}		
	//If 4thKey = "C"

    if (key == 67)
		{
			if (pressed)
					
					if (this.FourthKey == "C" || this.FourthKey == "c")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "C" || this.FourthKey == "c")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
							
						
		}	

		
	//If 4thKey = "D"

    if (key == 68)
		{
			if (pressed)
				
					if (this.FourthKey == "D" || this.FourthKey == "d")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "D" || this.FourthKey == "d")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	

	//If 4thKey = "E"

    if (key == 69)
		{
			if (pressed)
					
					if (this.FourthKey == "E" || this.FourthKey == "e")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "E" || this.FourthKey == "e")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "F"

    if (key == 70)
		{
			if (pressed)
					
					if (this.FourthKey == "F" || this.FourthKey == "f")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "F" || this.FourthKey == "f")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "G"

    if (key == 71)
		{
			if (pressed)
					
					if (this.FourthKey == "G" || this.FourthKey == "g")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "G" || this.FourthKey == "g")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}

	//If 4thKey = "H"

    if (key == 72)
		{
			if (pressed)
				
					if (this.FourthKey == "H" || this.FourthKey == "h")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "H" || this.FourthKey == "h")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "I"

    if (key == 73)
		{
			if (pressed)
					
					if (this.FourthKey == "I" || this.FourthKey == "i")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "I" || this.FourthKey == "i")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "J"

    if (key == 74)
		{
			if (pressed)
					
					if (this.FourthKey == "J" || this.FourthKey == "j")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "J" || this.FourthKey == "j")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "K"

    if (key == 75)
		{
			if (pressed)
					
					if (this.FourthKey == "K" || this.FourthKey == "k")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "K" || this.FourthKey == "k")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
	//If 4thKey = "L"

    if (key == 76)
		{
			if (pressed)
					
					if (this.FourthKey == "L" || this.FourthKey == "l")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "L" || this.FourthKey == "l")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "M"

    if (key == 77)
		{
			if (pressed)
					
					if (this.FourthKey == "M" || this.FourthKey == "m")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "M" || this.FourthKey == "m")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "N"

    if (key == 78)
		{
			if (pressed)
					
					if (this.FourthKey == "N" || this.FourthKey == "n")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "N" || this.FourthKey == "n")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "O"

    if (key == 79)
		{
			if (pressed)
					
					if (this.FourthKey == "O" || this.FourthKey == "o")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "O" || this.FourthKey == "o")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "P"

    if (key == 80)
		{
			if (pressed)
					
					if (this.FourthKey == "P" || this.FourthKey == "p")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "P" || this.FourthKey == "p")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "Q"

    if (key == 81)
		{
			if (pressed)
					
					if (this.FourthKey == "Q" || this.FourthKey == "q")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "Q" || this.FourthKey == "q")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "R"

    if (key == 82)
		{
			if (pressed)
					
					if (this.FourthKey == "R" || this.FourthKey == "r")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "R" || this.FourthKey == "r")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	

	//If 4thKey = "S"

    if (key == 83)
		{
			if (pressed)
					
					if (this.FourthKey == "S" || this.FourthKey == "s")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "S" || this.FourthKey == "s")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "T"

    if (key == 84)
		{
			if (pressed)
				
					if (this.FourthKey == "T" || this.FourthKey == "t")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "T" || this.FourthKey == "t")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "U"

    if (key == 85)
		{
			if (pressed)
					
					if (this.FourthKey == "U" || this.FourthKey == "u")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "U" || this.FourthKey == "u")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "V"

    if (key == 86)
		{
			if (pressed)
					
					if (this.FourthKey == "V" || this.FourthKey == "v")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "V" || this.FourthKey == "v")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
	//If 4thKey = "W"

    if (key == 87)
		{
			if (pressed)
					
					if (this.FourthKey == "W" || this.FourthKey == "w")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "W" || this.FourthKey == "w")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "X"

    if (key == 88)
		{
			if (pressed)
					
					if (this.FourthKey == "X" || this.FourthKey == "x")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "X" || this.FourthKey == "x")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "Y"

    if (key == 89)
		{
			if (pressed)
					
					if (this.FourthKey == "Y" || this.FourthKey == "y")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "Y" || this.FourthKey == "y")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 4thKey = "Z"

    if (key == 90)
		{
			if (pressed)
					
					if (this.FourthKey == "Z" || this.FourthKey == "z")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey;
						if (this.FourthKey == "Z" || this.FourthKey == "z")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	
		
//Author of the behaviour :- Vazahat Pathan aka Just_in_case!	
		
	//For 5th Key
	
	 //If 5thKey = "A"

    if (key == 65)
		{
			if (pressed)
					
					if (this.FifthKey == "A" || this.FifthKey == "a")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "A" || this.FifthKey == "a")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	
	//If 5thKey = "B"

    if (key == 66)
		{
			if (pressed)
				
					if (this.FifthKey == "B" || this.FifthKey == "b")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "B" || this.FifthKey == "b")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
						
						
					
		}		
	//If 5thKey = "C"

    if (key == 67)
		{
			if (pressed)
					
					if (this.FifthKey == "C" || this.FifthKey == "c")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "C" || this.FifthKey == "c")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
							
						
		}	

		
	//If 5thKey = "D"

    if (key == 68)
		{
			if (pressed)
				
					if (this.FifthKey == "D" || this.FifthKey == "d")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "D" || this.FifthKey == "d")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	

	//If 5thKey = "E"

    if (key == 69)
		{
			if (pressed)
					
					if (this.FifthKey == "E" || this.FifthKey == "e")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "E" || this.FifthKey == "e")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 5thKey = "F"

    if (key == 70)
		{
			if (pressed)
					
					if (this.FifthKey == "F" || this.FifthKey == "f")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "F" || this.FifthKey == "f")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 5thKey = "G"

    if (key == 71)
		{
			if (pressed)
					
					if (this.FifthKey == "G" || this.FifthKey == "g")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "G" || this.FifthKey == "g")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}

	//If 5thKey = "H"

    if (key == 72)
		{
			if (pressed)
				
					if (this.FifthKey == "H" || this.FifthKey == "h")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "H" || this.FifthKey == "h")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 5thKey = "I"

    if (key == 73)
		{
			if (pressed)
					
					if (this.FifthKey == "I" || this.FifthKey == "i")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "I" || this.FifthKey == "i")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 5thKey = "J"

    if (key == 74)
		{
			if (pressed)
					
					if (this.FifthKey == "J" || this.FifthKey == "j")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "J" || this.FifthKey == "j")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 5thKey = "K"

    if (key == 75)
		{
			if (pressed)
					
					if (this.FifthKey == "K" || this.FifthKey == "k")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "K" || this.FifthKey == "k")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
	//If 5thKey = "L"

    if (key == 76)
		{
			if (pressed)
					
					if (this.FifthKey == "L" || this.FifthKey == "l")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "L" || this.FifthKey == "l")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 5thKey = "M"

    if (key == 77)
		{
			if (pressed)
					
					if (this.FifthKey == "M" || this.FifthKey == "m")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "M" || this.FifthKey == "m")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 5thKey = "N"

    if (key == 78)
		{
			if (pressed)
					
					if (this.FifthKey == "N" || this.FifthKey == "n")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "N" || this.FifthKey == "n")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 5thKey = "O"

    if (key == 79)
		{
			if (pressed)
					
					if (this.FifthKey == "O" || this.FifthKey == "o")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "O" || this.FifthKey == "o")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 5thKey = "P"

    if (key == 80)
		{
			if (pressed)
					
					if (this.FifthKey == "P" || this.FifthKey == "p")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "P" || this.FifthKey == "p")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 5thKey = "Q"

    if (key == 81)
		{
			if (pressed)
					
					if (this.FifthKey == "Q" || this.FifthKey == "q")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "Q" || this.FifthKey == "q")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 5thKey = "R"

    if (key == 82)
		{
			if (pressed)
					
					if (this.FifthKey == "R" || this.FifthKey == "r")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "R" || this.FifthKey == "r")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	

	//If 5thKey = "S"

    if (key == 83)
		{
			if (pressed)
					
					if (this.FifthKey == "S" || this.FifthKey == "s")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "S" || this.FifthKey == "s")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 5thKey = "T"

    if (key == 84)
		{
			if (pressed)
				
					if (this.FifthKey == "T" || this.FifthKey == "t")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "T" || this.FifthKey == "t")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 5thKey = "U"

    if (key == 85)
		{
			if (pressed)
					
					if (this.FifthKey == "U" || this.FifthKey == "u")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "U" || this.FifthKey == "u")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 5thKey = "V"

    if (key == 86)
		{
			if (pressed)
					
					if (this.FifthKey == "V" || this.FifthKey == "v")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "V" || this.FifthKey == "v")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
	//If 5thKey = "W"

    if (key == 87)
		{
			if (pressed)
					
					if (this.FifthKey == "W" || this.FifthKey == "w")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "W" || this.FifthKey == "w")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 5thKey = "X"

    if (key == 88)
		{
			if (pressed)
					
					if (this.FifthKey == "X" || this.FifthKey == "x")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "X" || this.FifthKey == "x")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 5thKey = "Y"

    if (key == 89)
		{
			if (pressed)
					
					if (this.FifthKey == "Y" || this.FifthKey == "y")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "Y" || this.FifthKey == "y")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}
		
//Author of the behaviour :- Vazahat Pathan aka Just_in_case!

	//If 5thKey = "Z"

    if (key == 90)
		{
			if (pressed)
					
					if (this.FifthKey == "Z" || this.FifthKey == "z")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey;
						if (this.FifthKey == "Z" || this.FifthKey == "z")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	
		
		
		
	//For 6th Key
	
	 //If 6thKey = "A"

    if (key == 65)
		{
			if (pressed)
					
					if (this.SixthKey == "A" || this.SixthKey == "a")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "A" || this.SixthKey == "a")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	
	//If 6thKey = "B"

    if (key == 66)
		{
			if (pressed)
				
					if (this.SixthKey == "B" || this.SixthKey == "b")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "B" || this.SixthKey == "b")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
						
						
					
		}		
	//If 6thKey = "C"

    if (key == 67)
		{
			if (pressed)
					
					if (this.SixthKey == "C" || this.SixthKey == "c")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "C" || this.SixthKey == "c")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
							
						
		}	

		
	//If 6thKey = "D"

    if (key == 68)
		{
			if (pressed)
				
					if (this.SixthKey == "D" || this.SixthKey == "d")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "D" || this.SixthKey == "d")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	

	//If 6thKey = "E"

    if (key == 69)
		{
			if (pressed)
					
					if (this.SixthKey == "E" || this.SixthKey == "e")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "E" || this.SixthKey == "e")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "F"

    if (key == 70)
		{
			if (pressed)
					
					if (this.SixthKey == "F" || this.SixthKey == "f")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "F" || this.SixthKey == "f")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "G"

    if (key == 71)
		{
			if (pressed)
					
					if (this.SixthKey == "G" || this.SixthKey == "g")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "G" || this.SixthKey == "g")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}

	//If 6thKey = "H"

    if (key == 72)
		{
			if (pressed)
				
					if (this.SixthKey == "H" || this.SixthKey == "h")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "H" || this.SixthKey == "h")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "I"

    if (key == 73)
		{
			if (pressed)
					
					if (this.SixthKey == "I" || this.SixthKey == "i")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "I" || this.SixthKey == "i")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "J"

    if (key == 74)
		{
			if (pressed)
					
					if (this.SixthKey == "J" || this.SixthKey == "j")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "J" || this.SixthKey == "j")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "K"

    if (key == 75)
		{
			if (pressed)
					
					if (this.SixthKey == "K" || this.SixthKey == "k")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "K" || this.SixthKey == "k")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
	//If 6thKey = "L"

    if (key == 76)
		{
			if (pressed)
					
					if (this.SixthKey == "L" || this.SixthKey == "l")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "L" || this.SixthKey == "l")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "M"

    if (key == 77)
		{
			if (pressed)
					
					if (this.SixthKey == "M" || this.SixthKey == "m")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "M" || this.SixthKey == "m")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "N"

    if (key == 78)
		{
			if (pressed)
					
					if (this.SixthKey == "N" || this.SixthKey == "n")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "N" || this.SixthKey == "n")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "O"

    if (key == 79)
		{
			if (pressed)
					
					if (this.SixthKey == "O" || this.SixthKey == "o")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "O" || this.SixthKey == "o")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "P"

    if (key == 80)
		{
			if (pressed)
					
					if (this.SixthKey == "P" || this.SixthKey == "p")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "P" || this.SixthKey == "p")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "Q"

    if (key == 81)
		{
			if (pressed)
					
					if (this.SixthKey == "Q" || this.SixthKey == "q")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "Q" || this.SixthKey == "q")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "R"

    if (key == 82)
		{
			if (pressed)
					
					if (this.SixthKey == "R" || this.SixthKey == "r")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "R" || this.SixthKey == "r")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	

	//If 6thKey = "S"

    if (key == 83)
		{
			if (pressed)
					
					if (this.SixthKey == "S" || this.SixthKey == "s")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "S" || this.SixthKey == "s")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "T"

    if (key == 84)
		{
			if (pressed)
				
					if (this.SixthKey == "T" || this.SixthKey == "t")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "T" || this.SixthKey == "t")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "U"

    if (key == 85)
		{
			if (pressed)
					
					if (this.SixthKey == "U" || this.SixthKey == "u")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "U" || this.SixthKey == "u")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "V"

    if (key == 86)
		{
			if (pressed)
					
					if (this.SixthKey == "V" || this.SixthKey == "v")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "V" || this.SixthKey == "v")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
	//If 6thKey = "W"

    if (key == 87)
		{
			if (pressed)
					
					if (this.SixthKey == "W" || this.SixthKey == "w")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "W" || this.SixthKey == "w")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "X"

    if (key == 88)
		{
			if (pressed)
					
					if (this.SixthKey == "X" || this.SixthKey == "x")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "X" || this.SixthKey == "x")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "Y"

    if (key == 89)
		{
			if (pressed)
					
					if (this.SixthKey == "Y" || this.SixthKey == "y")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "Y" || this.SixthKey == "y")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 6thKey = "Z"

    if (key == 90)
		{
			if (pressed)
					
					if (this.SixthKey == "Z" || this.SixthKey == "z")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey;
						if (this.SixthKey == "Z" || this.SixthKey == "z")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		
		
//Author of the behaviour :- Vazahat Pathan aka Just_in_case!
		
	//For 7th Key
	
	 //If 7thKey = "A"

    if (key == 65)
		{
			if (pressed)
					
					if (this.SeventhKey == "A" || this.SeventhKey == "a")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "A" || this.SeventhKey == "a")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	
	//If 7thKey = "B"

    if (key == 66)
		{
			if (pressed)
				
					if (this.SeventhKey == "B" || this.SeventhKey == "b")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "B" || this.SeventhKey == "b")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
						
						
					
		}		
	//If 7thKey = "C"

    if (key == 67)
		{
			if (pressed)
					
					if (this.SeventhKey == "C" || this.SeventhKey == "c")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "C" || this.SeventhKey == "c")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
							
						
		}	

		
	//If 7thKey = "D"

    if (key == 68)
		{
			if (pressed)
				
					if (this.SeventhKey == "D" || this.SeventhKey == "d")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "D" || this.SeventhKey == "d")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	

	//If 7thKey = "E"

    if (key == 69)
		{
			if (pressed)
					
					if (this.SeventhKey == "E" || this.SeventhKey == "e")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "E" || this.SeventhKey == "e")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "F"

    if (key == 70)
		{
			if (pressed)
					
					if (this.SeventhKey == "F" || this.SeventhKey == "f")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "F" || this.SeventhKey == "f")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "G"

    if (key == 71)
		{
			if (pressed)
					
					if (this.SeventhKey == "G" || this.SeventhKey == "g")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "G" || this.SeventhKey == "g")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}

	//If 7thKey = "H"

    if (key == 72)
		{
			if (pressed)
				
					if (this.SeventhKey == "H" || this.SeventhKey == "h")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "H" || this.SeventhKey == "h")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "I"

    if (key == 73)
		{
			if (pressed)
					
					if (this.SeventhKey == "I" || this.SeventhKey == "i")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "I" || this.SeventhKey == "i")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "J"

    if (key == 74)
		{
			if (pressed)
					
					if (this.SeventhKey == "J" || this.SeventhKey == "j")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "J" || this.SeventhKey == "j")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "K"

    if (key == 75)
		{
			if (pressed)
					
					if (this.SeventhKey == "K" || this.SeventhKey == "k")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "K" || this.SeventhKey == "k")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
	//If 7thKey = "L"

    if (key == 76)
		{
			if (pressed)
					
					if (this.SeventhKey == "L" || this.SeventhKey == "l")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "L" || this.SeventhKey == "l")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "M"

    if (key == 77)
		{
			if (pressed)
					
					if (this.SeventhKey == "M" || this.SeventhKey == "m")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "M" || this.SeventhKey == "m")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "N"

    if (key == 78)
		{
			if (pressed)
					
					if (this.SeventhKey == "N" || this.SeventhKey == "n")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "N" || this.SeventhKey == "n")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "O"

    if (key == 79)
		{
			if (pressed)
					
					if (this.SeventhKey == "O" || this.SeventhKey == "o")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "O" || this.SeventhKey == "o")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "P"

    if (key == 80)
		{
			if (pressed)
					
					if (this.SeventhKey == "P" || this.SeventhKey == "p")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "P" || this.SeventhKey == "p")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "Q"

    if (key == 81)
		{
			if (pressed)
					
					if (this.SeventhKey == "Q" || this.SeventhKey == "q")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "Q" || this.SeventhKey == "q")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "R"

    if (key == 82)
		{
			if (pressed)
					
					if (this.SeventhKey == "R" || this.SeventhKey == "r")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "R" || this.SeventhKey == "r")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	

	//If 7thKey = "S"

    if (key == 83)
		{
			if (pressed)
					
					if (this.SeventhKey == "S" || this.SeventhKey == "s")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "S" || this.SeventhKey == "s")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "T"

    if (key == 84)
		{
			if (pressed)
				
					if (this.SeventhKey == "T" || this.SeventhKey == "t")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "T" || this.SeventhKey == "t")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "U"

    if (key == 85)
		{
			if (pressed)
					
					if (this.SeventhKey == "U" || this.SeventhKey == "u")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "U" || this.SeventhKey == "u")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "V"

    if (key == 86)
		{
			if (pressed)
					
					if (this.SeventhKey == "V" || this.SeventhKey == "v")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "V" || this.SeventhKey == "v")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
	//If 7thKey = "W"

    if (key == 87)
		{
			if (pressed)
					
					if (this.SeventhKey == "W" || this.SeventhKey == "w")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "W" || this.SeventhKey == "w")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "X"

    if (key == 88)
		{
			if (pressed)
					
					if (this.SeventhKey == "X" || this.SeventhKey == "x")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "X" || this.SeventhKey == "x")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "Y"

    if (key == 89)
		{
			if (pressed)
					
					if (this.SeventhKey == "Y" || this.SeventhKey == "y")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "Y" || this.SeventhKey == "y")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 7thKey = "Z"

    if (key == 90)
		{
			if (pressed)
					
					if (this.SeventhKey == "Z" || this.SeventhKey == "z")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey;
						if (this.SeventhKey == "Z" || this.SeventhKey == "z")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
//Author of the behaviour :- Vazahat Pathan aka Just_in_case!
		
	//For 8th Key
	
	 //If 8thKey = "A"

    if (key == 65)
		{
			if (pressed)
					
					if (this.EighthKey == "A" || this.EighthKey == "a")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "A" || this.EighthKey == "a")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	
	//If 8thKey = "B"

    if (key == 66)
		{
			if (pressed)
				
					if (this.EighthKey == "B" || this.EighthKey == "b")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "B" || this.EighthKey == "b")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
						
						
					
		}		
	//If 8thKey = "C"

    if (key == 67)
		{
			if (pressed)
					
					if (this.EighthKey == "C" || this.EighthKey == "c")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "C" || this.EighthKey == "c")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
							
						
		}	

		
	//If 8thKey = "D"

    if (key == 68)
		{
			if (pressed)
				
					if (this.EighthKey == "D" || this.EighthKey == "d")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "D" || this.EighthKey == "d")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	

	//If 8thKey = "E"

    if (key == 69)
		{
			if (pressed)
					
					if (this.EighthKey == "E" || this.EighthKey == "e")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "E" || this.EighthKey == "e")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "F"

    if (key == 70)
		{
			if (pressed)
					
					if (this.EighthKey == "F" || this.EighthKey == "f")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "F" || this.EighthKey == "f")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "G"

    if (key == 71)
		{
			if (pressed)
					
					if (this.EighthKey == "G" || this.EighthKey == "g")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "G" || this.EighthKey == "g")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}

	//If 8thKey = "H"

    if (key == 72)
		{
			if (pressed)
				
					if (this.EighthKey == "H" || this.EighthKey == "h")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "H" || this.EighthKey == "h")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "I"

    if (key == 73)
		{
			if (pressed)
					
					if (this.EighthKey == "I" || this.EighthKey == "i")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "I" || this.EighthKey == "i")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "J"

    if (key == 74)
		{
			if (pressed)
					
					if (this.EighthKey == "J" || this.EighthKey == "j")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "J" || this.EighthKey == "j")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "K"

    if (key == 75)
		{
			if (pressed)
					
					if (this.EighthKey == "K" || this.EighthKey == "k")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "K" || this.EighthKey == "k")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
	//If 8thKey = "L"

    if (key == 76)
		{
			if (pressed)
					
					if (this.EighthKey == "L" || this.EighthKey == "l")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "L" || this.EighthKey == "l")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "M"

    if (key == 77)
		{
			if (pressed)
					
					if (this.EighthKey == "M" || this.EighthKey == "m")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "M" || this.EighthKey == "m")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "N"

    if (key == 78)
		{
			if (pressed)
					
					if (this.EighthKey == "N" || this.EighthKey == "n")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "N" || this.EighthKey == "n")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "O"

    if (key == 79)
		{
			if (pressed)
					
					if (this.EighthKey == "O" || this.EighthKey == "o")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "O" || this.EighthKey == "o")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "P"

    if (key == 80)
		{
			if (pressed)
					
					if (this.EighthKey == "P" || this.EighthKey == "p")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "P" || this.EighthKey == "p")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "Q"

    if (key == 81)
		{
			if (pressed)
					
					if (this.EighthKey == "Q" || this.EighthKey == "q")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "Q" || this.EighthKey == "q")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "R"

    if (key == 82)
		{
			if (pressed)
					
					if (this.EighthKey == "R" || this.EighthKey == "r")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "R" || this.EighthKey == "r")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	

	//If 8thKey = "S"

    if (key == 83)
		{
			if (pressed)
					
					if (this.EighthKey == "S" || this.EighthKey == "s")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "S" || this.EighthKey == "s")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "T"

    if (key == 84)
		{
			if (pressed)
				
					if (this.EighthKey == "T" || this.EighthKey == "t")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "T" || this.EighthKey == "t")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "U"

    if (key == 85)
		{
			if (pressed)
					
					if (this.EighthKey == "U" || this.EighthKey == "u")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "U" || this.EighthKey == "u")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "V"

    if (key == 86)
		{
			if (pressed)
					
					if (this.EighthKey == "V" || this.EighthKey == "v")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "V" || this.EighthKey == "v")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
	//If 8thKey = "W"

    if (key == 87)
		{
			if (pressed)
					
					if (this.EighthKey == "W" || this.EighthKey == "w")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "W" || this.EighthKey == "w")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "X"

    if (key == 88)
		{
			if (pressed)
					
					if (this.EighthKey == "X" || this.EighthKey == "x")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "X" || this.EighthKey == "x")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "Y"

    if (key == 89)
		{
			if (pressed)
					
				if (this.EighthKey == "Y" || this.EighthKey == "y")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "Y" || this.EighthKey == "y")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 8thKey = "Z"

    if (key == 90)
		{
			if (pressed)
					
					if (this.EighthKey == "Z" || this.EighthKey == "z")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey;
						if (this.EighthKey == "Z" || this.EighthKey == "z")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			

//Author of the behaviour :- Vazahat Pathan aka Just_in_case!

	//For 9th Key
	
	 //If 9thKey = "A"

    if (key == 65)
		{
			if (pressed)
					
					if (this.NinethKey == "A" || this.NinethKey == "a")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "A" || this.NinethKey == "a")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	
	//If 9thKey = "B"

    if (key == 66)
		{
			if (pressed)
				
					if (this.NinethKey == "B" || this.NinethKey == "b")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "B" || this.NinethKey == "b")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
						
						
					
		}		
	//If 9thKey = "C"

    if (key == 67)
		{
			if (pressed)
					
					if (this.NinethKey == "C" || this.NinethKey == "c")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "C" || this.NinethKey == "c")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
							
						
		}	

		
	//If 9thKey = "D"

    if (key == 68)
		{
			if (pressed)
				
					if (this.NinethKey == "D" || this.NinethKey == "d")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "D" || this.NinethKey == "d")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	

	//If 9thKey = "E"

    if (key == 69)
		{
			if (pressed)
					
					if (this.NinethKey == "E" || this.NinethKey == "e")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "E" || this.NinethKey == "e")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "F"

    if (key == 70)
		{
			if (pressed)
					
					if (this.NinethKey == "F" || this.NinethKey == "f")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "F" || this.NinethKey == "f")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "G"

    if (key == 71)
		{
			if (pressed)
					
					if (this.NinethKey == "G" || this.NinethKey == "g")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "G" || this.NinethKey == "g")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}

	//If 9thKey = "H"

    if (key == 72)
		{
			if (pressed)
				
					if (this.NinethKey == "H" || this.NinethKey == "h")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "H" || this.NinethKey == "h")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "I"

    if (key == 73)
		{
			if (pressed)
					
					if (this.NinethKey == "I" || this.NinethKey == "i")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "I" || this.NinethKey == "i")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "J"

    if (key == 74)
		{
			if (pressed)
					
					if (this.NinethKey == "J" || this.NinethKey == "j")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "J" || this.NinethKey == "j")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "K"

    if (key == 75)
		{
			if (pressed)
					
					if (this.NinethKey == "K" || this.NinethKey == "k")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "K" || this.NinethKey == "k")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
	//If 9thKey = "L"

    if (key == 76)
		{
			if (pressed)
					
					if (this.NinethKey == "L" || this.NinethKey == "l")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "L" || this.NinethKey == "l")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "M"

    if (key == 77)
		{
			if (pressed)
					
					if (this.NinethKey == "M" || this.NinethKey == "m")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "M" || this.NinethKey == "m")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "N"

    if (key == 78)
		{
			if (pressed)
					
					if (this.NinethKey == "N" || this.NinethKey == "n")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "N" || this.NinethKey == "n")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "O"

    if (key == 79)
		{
			if (pressed)
					
					if (this.NinethKey == "O" || this.NinethKey == "o")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "O" || this.NinethKey == "o")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "P"

    if (key == 80)
		{
			if (pressed)
					
					if (this.NinethKey == "P" || this.NinethKey == "p")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "P" || this.NinethKey == "p")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "Q"

    if (key == 81)
		{
			if (pressed)
					
					if (this.NinethKey == "Q" || this.NinethKey == "q")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "Q" || this.NinethKey == "q")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "R"

    if (key == 82)
		{
			if (pressed)
					
					if (this.NinethKey == "R" || this.NinethKey == "r")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "R" || this.NinethKey == "r")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	

	//If 9thKey = "S"

    if (key == 83)
		{
			if (pressed)
					
					if (this.NinethKey == "S" || this.NinethKey == "s")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "S" || this.NinethKey == "s")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "T"

    if (key == 84)
		{
			if (pressed)
				
					if (this.NinethKey == "T" || this.NinethKey == "t")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "T" || this.NinethKey == "t")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "U"

    if (key == 85)
		{
			if (pressed)
					
					if (this.NinethKey == "U" || this.NinethKey == "u")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "U" || this.NinethKey == "u")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "V"

    if (key == 86)
		{
			if (pressed)
					
					if (this.NinethKey == "V" || this.NinethKey == "v")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "V" || this.NinethKey == "v")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
	//If 9thKey = "W"

    if (key == 87)
		{
			if (pressed)
					
					if (this.NinethKey == "W" || this.NinethKey == "w")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "W" || this.NinethKey == "w")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "X"

    if (key == 88)
		{
			if (pressed)
					
					if (this.NinethKey == "X" || this.NinethKey == "x")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "X" || this.NinethKey == "x")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "Y"

    if (key == 89)
		{
			if (pressed)
					
				if (this.NinethKey == "Y" || this.NinethKey == "y")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "Y" || this.NinethKey == "y")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 9thKey = "Z"

    if (key == 90)
		{
			if (pressed)
					
					if (this.NinethKey == "Z" || this.NinethKey == "z")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey;
						if (this.NinethKey == "Z" || this.NinethKey == "z")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	
//Author of the behaviour :- Vazahat Pathan aka Just_in_case!

	//For 10th Key
	
	 //If 10thKey = "A"

    if (key == 65)
		{
			if (pressed)
					
					if (this.TenthKey == "A" || this.TenthKey == "a")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "A" || this.TenthKey == "a")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	
	//If 10thKey = "B"

    if (key == 66)
		{
			if (pressed)
				
					if (this.TenthKey == "B" || this.TenthKey == "b")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "B" || this.TenthKey == "b")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
						
						
					
		}		
	//If 10thKey = "C"

    if (key == 67)
		{
			if (pressed)
					
					if (this.TenthKey == "C" || this.TenthKey == "c")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "C" || this.TenthKey == "c")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
							
						
		}	

		
	//If 10thKey = "D"

    if (key == 68)
		{
			if (pressed)
				
					if (this.TenthKey == "D" || this.TenthKey == "d")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "D" || this.TenthKey == "d")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	

	//If 10thKey = "E"

    if (key == 69)
		{
			if (pressed)
					
					if (this.TenthKey == "E" || this.TenthKey == "e")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "E" || this.TenthKey == "e")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "F"

    if (key == 70)
		{
			if (pressed)
					
					if (this.TenthKey == "F" || this.TenthKey == "f")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "F" || this.TenthKey == "f")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "G"

    if (key == 71)
		{
			if (pressed)
					
					if (this.TenthKey == "G" || this.TenthKey == "g")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "G" || this.TenthKey == "g")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}

	//If 10thKey = "H"

    if (key == 72)
		{
			if (pressed)
				
					if (this.TenthKey == "H" || this.TenthKey == "h")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "H" || this.TenthKey == "h")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "I"

    if (key == 73)
		{
			if (pressed)
					
					if (this.TenthKey == "I" || this.TenthKey == "i")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "I" || this.TenthKey == "i")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "J"

    if (key == 74)
		{
			if (pressed)
					
					if (this.TenthKey == "J" || this.TenthKey == "j")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "J" || this.TenthKey == "j")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "K"

    if (key == 75)
		{
			if (pressed)
					
					if (this.TenthKey == "K" || this.TenthKey == "k")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "K" || this.TenthKey == "k")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
	//If 10thKey = "L"

    if (key == 76)
		{
			if (pressed)
					
					if (this.TenthKey == "L" || this.TenthKey == "l")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "L" || this.TenthKey == "l")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "M"

    if (key == 77)
		{
			if (pressed)
					
					if (this.TenthKey == "M" || this.TenthKey == "m")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "M" || this.TenthKey == "m")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "N"

    if (key == 78)
		{
			if (pressed)
					
					if (this.TenthKey == "N" || this.TenthKey == "n")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "N" || this.TenthKey == "n")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "O"

    if (key == 79)
		{
			if (pressed)
					
					if (this.TenthKey == "O" || this.TenthKey == "o")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "O" || this.TenthKey == "o")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "P"

    if (key == 80)
		{
			if (pressed)
					
					if (this.TenthKey == "P" || this.TenthKey == "p")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "P" || this.TenthKey == "p")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "Q"

    if (key == 81)
		{
			if (pressed)
					
					if (this.TenthKey == "Q" || this.TenthKey == "q")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "Q" || this.TenthKey == "q")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "R"

    if (key == 82)
		{
			if (pressed)
					
					if (this.TenthKey == "R" || this.TenthKey == "r")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "R" || this.TenthKey == "r")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}	

	//If 10thKey = "S"

    if (key == 83)
		{
			if (pressed)
					
					if (this.TenthKey == "S" || this.TenthKey == "s")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "S" || this.TenthKey == "s")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "T"

    if (key == 84)
		{
			if (pressed)
				
					if (this.TenthKey == "T" || this.TenthKey == "t")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "T" || this.TenthKey == "t")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "U"

    if (key == 85)
		{
			if (pressed)
					
					if (this.TenthKey == "U" || this.TenthKey == "u")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "U" || this.TenthKey == "u")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "V"

    if (key == 86)
		{
			if (pressed)
					
				if (this.TenthKey == "V" || this.TenthKey == "v")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "V" || this.TenthKey == "v")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}			
		
	//If 10thKey = "W"

    if (key == 87)
		{
			if (pressed)
					
					if (this.TenthKey == "W" || this.TenthKey == "w")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "W" || this.TenthKey == "w")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "X"

    if (key == 88)
		{
			if (pressed)
					
				if (this.TenthKey == "X" || this.TenthKey == "x")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "X" || this.TenthKey == "x")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "Y"

    if (key == 89)
		{
			if (pressed)
					
				if (this.TenthKey == "Y" || this.TenthKey == "y")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "Y" || this.TenthKey == "y")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}		

	//If 10thKey = "Z"

    if (key == 90)
		{
			if (pressed)
					
					if (this.TenthKey == "Z" || this.TenthKey == "z")
						if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey)
							this.FinalKey = this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey;
						if (this.TenthKey == "Z" || this.TenthKey == "z")
						if (this.FinalKey == this.FirstKey)
							this.FinalKey = this.NoneKey;
					
		}				
    	
	if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey)
		ccbInvokeAction(this.Action, node);
	if (this.FinalKey == this.NoneKey+this.FirstKey+this.SecondKey+this.ThirdKey+this.FourthKey+this.FifthKey+this.SixthKey+this.SeventhKey+this.EighthKey+this.NinethKey+this.TenthKey)
		this.Cheat = 1;
	else(this.Cheat = 0)
	if (this.Cheat == 1)
		this.FinalKey = this.NoneKey;
	
	}   
	    
//Author of the behaviour :- Vazahat Pathan aka Just_in_case!
	
	
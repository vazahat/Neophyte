/*	Info 
	
	Extension Name	: In Game FPS info
	Extension Type	: Behavior
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: ‎‎August ‎18, ‎2021, 10:28 PM
	Description		: Shows FPS counter in a game on a 2D overlay
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	

*/
/*	Changelog

    [August ‎18, ‎2021]- Created the base layout of the behavior.	 
							-	Added 1000ms calculation of fps.
							-   Added 500ms calculation of fps commented put 1000ms one as 500ms is much better.
					
	Limitations     - None, no limitation is coming in my mind at the moment if you think there is something missing then let me know
	
*/



/* Usage
  
   This is a coppercube behavior which allows you to draw FPS Meter on a 2D overlay during the runtime of game. 
   
*/

// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*
	<behavior jsname="behavior_inGameFPS_Meter" description="Shows an in game FPS Meter on a 2D overlay">
		<property name="Overlay" type="scenenode" />
		<property name="Text" type="string" value="text" default="FPS:  " />
		<property name="VariableName" type="string" />
		<property name="HalfSecond" type="bool" />
	</behavior>
*/


behavior_inGameFPS_Meter = function()
{
	// setting all the variables 
	this.LastOverlayObject = null;
	this.frameCounter = 0;
	this.frames = 0;
	this.frameStartTime = 0;
};

behavior_inGameFPS_Meter.prototype.onAnimate = function (node)
{
	this.frames++;
	if(!this.HalfSecond)
	{
		if (Date.now() - this.frameStartTime > 1000)  //calculates every 1000ms
			{ 
			this.frameCounter = Math.floor(( this.frames /((Date.now()-this.frameStartTime)/1000)));  //rounding off the number to not show decimal values
			ccbSetSceneNodeProperty(this.Overlay, "Draw Text", true ); //setting the property of the overlay to always draw text if its not enable then enable it.
			ccbSetSceneNodeProperty(this.Overlay, "Text", this.Text+this.frameCounter); // print the current frame rate on the overlay.
			ccbSetCopperCubeVariable(this.VariableName,this.frameCounter); // create and store Frames counter values in a named variable 
			this.frameStartTime = Date.now();
			this.frames = 0;
			}
	}
	
	else if(this.HalfSecond)
	{
		if (Date.now() > this.frameStartTime + 500)  //calculates every 500 ms
		{
		this.frameCounter = Math.floor((0.5 * this.frames * 2) + 0.5 * this.frameCounter); //rounding off the number to not show decimal values
		ccbSetSceneNodeProperty(this.Overlay, "Draw Text", true ); //setting the property of the overlay to always draw text if its not enable then enable it.
		ccbSetSceneNodeProperty(this.Overlay, "Text", this.Text+this.frameCounter); // print the current frame rate on the overlay.
		ccbSetCopperCubeVariable(this.VariableName,this.frameCounter); // create and store Frames counter values in a named variable can be used to animate or add effects for example green color on high fps and red color on low fps.
		this.frameStartTime = Date.now();
		this.frames = 0;
		}
	}
	return true;
}


/* END*/

/*The above behavior is written by Vazahat Khan (just_in-case)*/
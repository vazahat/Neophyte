/*  <action jsname="action_LookToObject" description="Look in direction of target object 3D">
      <property name="targetNode" type="scenenode" />
    </action>
*/

action_LookToObject = function()
{
};

action_LookToObject.prototype.execute = function(currentNode)
{
	var position_target = ccbGetSceneNodeProperty(this.targetNode, "Position");
	var position = ccbGetSceneNodeProperty(currentNode, "Position");
	var rotation = ccbGetSceneNodeProperty(currentNode, "Rotation");

	pos_o_x=position_target.x-position.x;
	pos_o_z=position_target.z-position.z;
	pos_o_y=position_target.y-position.y;
	var dist=Math.sqrt( Math.pow( (position.x-position_target.x) ,2) + Math.pow( (position.y-position_target.y) ,2) + Math.pow( (position.z-position_target.z) ,2) );
	var pi=Math.PI;
	var look_angle_horz=( (Math.atan2(pos_o_x,pos_o_z) )*180/pi )-180;
	
	var look_angle_vert=( (Math.atan2(pos_o_y,dist) )*180/pi );
	//
	//d=raiz( (x1-x2)²+(y1-y2)²+(z1-z2)²)

	//var s = ccbGetSceneNodeFromName("debug");
	//ccbSetSceneNodeProperty(s,'Text', "Distancia = "+dist+" : Angulo X ="+look_angle_vert+": Angulo y ="+look_angle_horz);	

	ccbSetSceneNodeProperty(currentNode,"Rotation",look_angle_vert,look_angle_horz,rotation.z);

}

/*
Action created by:
Jaime A. Zegpi B.
jaimezegpi@yahoo.es
rotx = Math.atan2( y, z )
roty = Math.atan2( x * Math.cos(rotx), z )
rotz = Math.atan2( Math.cos(rotx), Math.sin(rotx) * Math.sin(roty) )
*/
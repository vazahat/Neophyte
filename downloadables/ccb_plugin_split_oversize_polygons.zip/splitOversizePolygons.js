// splitOversizePolygons.js v3.0 - author BMSKiwi
// v1.0 26.06.13 - Initial write, named highlightOversizePolygons.js
// v1.1 26.06.13 - Fixed minor bugs with getTargetTextureSize() and getTargetResolution().
// v1.2 27.06.13 - Created additional property with version information. Changed function sequence.
// v2.0 26.08.13 - Rewrote plugin to automatically split oversize polygons, renamed to match. Identified bug with plugin exceeding recursion limits on large meshes - not yet fixed.
// v2.5 19.11.13 - Redesigned plugin to minimise likelihood of exceeding recursion limit, fixed some other bugs.
// v3.0 29.03.14 - Improved some procedures, added a variety of processing statistics to the output.

editorRegisterMenuEntry('splitOversizePolygons()', 'Split Oversize Polygons\tCtrl+R');
splitOversizePolygons.version = 3.0;

function splitOversizePolygons(){
    print('splitOversizePolygons.js v' + splitOversizePolygons.version + ' - author BMSKiwi');
    if(!confirm('splitOversizePolygons.js v' + splitOversizePolygons.version + '\n\nThis script will check your mesh geometry for polygons too large to lightmap with a specified texture size and resolution. Any oversize polygons will be automatically split into smaller polygons.\n\nWARNING: This script will remove all existing lightmaps and irreversably alter your data. If you are unsure please cancel this dialogue and save a copy of your file before proceeding.\n\nDo you want to continue?')) {
        return;
    }
    var oversizePolygonsIndex = 0;
    var newPolygonsIndex = 0;
    var targetTextureSize = getTargetTextureSize();
    if (!targetTextureSize){
        return;
    }
    var targetResolution = getTargetResolution();
    if (!targetResolution){
        return;
    }
    var start = Date.now();
    var maxAxisLength = getMaxAxisLength(targetTextureSize,targetResolution);
    var root = ccbGetRootSceneNode();
    iterateMeshNodes(root);

    function getTargetTextureSize() {
        var targetTextureSize = prompt('Please enter your target lightmap texture size. Only enter the length of one side ie. 64, 128, 256, 512 or 1024.', '1024');
        while (isNaN(targetTextureSize) || targetTextureSize != 0 && targetTextureSize != 64 && targetTextureSize != 128 && targetTextureSize != 256 && targetTextureSize != 512 && targetTextureSize != 1024){
            targetTextureSize = prompt('Sorry, that is not a valid submission.\n\nPlease enter your target lightmap texture size. Only enter the length of one side ie. 64, 128, 256, 512 or 1024.', '1024');
        }
        return(+targetTextureSize);
    }
    function getTargetResolution(){
        var targetResolution = prompt('Please enter your target lightmap resolution.', '1000');
        while (isNaN(targetResolution) || targetResolution > 1000000 || targetResolution < 0){
            targetResolution = prompt('Sorry, that is not a valid submission.\n\nPlease enter your target lightmap resolution. This must be a value between 1 and 1000000.', '1000');
        }
        return(Math.ceil(targetResolution));
    }
    function getMaxAxisLength(targetTextureSize,targetResolution){
        var maxAxisLength = 0;
        switch(targetTextureSize){
            case 64:
                maxAxisLength = targetResolution/1.057852;
                break;
            case 128:
                maxAxisLength = targetResolution/1.028113;
                break;
            case 256:
                maxAxisLength = targetResolution/1.013862;
                break;
            case 512:
                maxAxisLength = targetResolution/1.006883;
                break;
            case 1024:
                maxAxisLength = targetResolution/1.003430;
                break;
        }
        return(maxAxisLength);
    }
    function iterateMeshNodes(root){
        ccbGetSceneNodeMeshBufferCount(root) && !ccbGetSceneNodeMaterialProperty(root,0,'Lighting') ? iterateBuffers(root) : null;
        var meshNodeCount = ccbGetSceneNodeChildCount(root);
        for (var m=0; m<meshNodeCount; m++){
            var childMeshNode = ccbGetChildSceneNode(root, m);
            iterateMeshNodes(childMeshNode);
        }
    }
    function iterateBuffers(meshNode){
        var bufferCount = ccbGetSceneNodeMeshBufferCount(meshNode);
        for (var b=0; b<bufferCount; b++){
            var materialType = ccbGetSceneNodeMaterialProperty(meshNode,b,'Type');
            if (materialType=='solid'||materialType=='lightmap'||materialType=='lightmap_add'||materialType=='lightmap_m2'||materialType=='lightmap_m4'||materialType=='onetexture_blend') {
                ccbSetSceneNodeMaterialProperty(meshNode,b,'Texture2','');
                iterateIndices(meshNode,b);
            }
        } 
    }
    function iterateIndices(meshNode,meshBuffer){
        var indexCount = ccbGetMeshBufferIndexCount(meshNode,meshBuffer);
        for (var i=0; i<indexCount; i+=3){
            processPolygon(meshNode,meshBuffer,i);
        }
    }
    function processPolygon(meshNode,meshBuffer,indexBase){
        var polygons = [indexBase];
        polygons.original = true;
        while(polygons.length>0){
            for(i=0;i<polygons.length;i++) {
                var oversize = checkOversize(meshNode,meshBuffer,polygons[i]);
                if(!oversize) {
                    polygons.splice(i,1);
                    i--;
                }
                else if(oversize && polygons.original) {
                    ++oversizePolygonsIndex;
                    polygons.original = false;
                }
            }
            var oversizePolygons = polygons.length;
            for(i=0;i<oversizePolygons;i++) {
                var newPolygon = splitPolygon(meshNode,meshBuffer,polygons[i]);
                polygons.push(newPolygon);
            }
        }
    }
    function checkOversize(meshNode,meshBuffer,indexBase){
        var oversize = false;
        var v1 = ccbGetMeshBufferIndexValue(meshNode,meshBuffer,indexBase);
        var v2 = ccbGetMeshBufferIndexValue(meshNode,meshBuffer,indexBase+1);
        var v3 = ccbGetMeshBufferIndexValue(meshNode,meshBuffer,indexBase+2);
        v1pos = ccbGetMeshBufferVertexPosition(meshNode,meshBuffer,v1);
        v2pos = ccbGetMeshBufferVertexPosition(meshNode,meshBuffer,v2);
        v3pos = ccbGetMeshBufferVertexPosition(meshNode,meshBuffer,v3);
        if(Math.max(getAxisLength(v1pos.x,v2pos.x,v3pos.x),getAxisLength(v1pos.y,v2pos.y,v3pos.y),getAxisLength(v1pos.z,v2pos.z,v3pos.z)) > maxAxisLength){
            oversize = true;
        }
        return(oversize);
    }
    function getAxisLength(value1,value2,value3){
        var maxValue = Math.max(value1,value2,value3);
        var minValue = Math.min(value1,value2,value3);
        var length = maxValue - minValue;
        return(length);
    }
    function vertex(meshNode,meshBuffer,index){
        var vertexIndex = ccbGetMeshBufferIndexValue(meshNode,meshBuffer,index);
        this.index = vertexIndex;
        this.position = ccbGetMeshBufferVertexPosition(meshNode,meshBuffer,vertexIndex);
        this.textureCoord = ccbGetMeshBufferVertexTextureCoord(meshNode,meshBuffer,vertexIndex);
        this.normal = ccbGetMeshBufferVertexNormal(meshNode,meshBuffer,vertexIndex);
        this.color = ccbGetMeshBufferVertexColor(meshNode,meshBuffer,vertexIndex);
        return(this);
    }
    function splitPolygon(meshNode,meshBuffer,indexBase){
        var vertex1 = new vertex(meshNode,meshBuffer,indexBase);
        var vertex2 = new vertex(meshNode,meshBuffer,indexBase+1);
        var vertex3 = new vertex(meshNode,meshBuffer,indexBase+2);
        var side1 = getLineLength(vertex1,vertex2);
        var side2 = getLineLength(vertex1,vertex3);
        var side3 = getLineLength(vertex2,vertex3);
        var hypotenuse = Math.max(side1,side2,side3);
        var newVertex = {index:ccbGetMeshBufferVertexCount(meshNode,meshBuffer)};
        var newIndexBase = ccbGetMeshBufferIndexCount(meshNode,meshBuffer);
        if(side1 == hypotenuse){
            var alpha = vertex1;
            var beta = vertex2;
            var gamma = vertex3;
            var omega = indexBase+1;
        }
        else if(side2 == hypotenuse){
            var alpha = vertex3;
            var beta = vertex1;
            var gamma = vertex2;
            var omega = indexBase;
        }
        else if(side3 == hypotenuse){
            var alpha = vertex2;
            var beta = vertex3;
            var gamma = vertex1;
            var omega = indexBase+2;
        }
        newVertex.position = getMidPointPosition(alpha,beta);
        newVertex.textureCoord = getMidPointTextureCoord(alpha,beta);
        newVertex.normal = getMidPointNormal(alpha,beta);
        newVertex.color = getMidPointColor(alpha,beta);
        
        ccbAddMeshBufferVertex(meshNode,meshBuffer,newVertex.position);
        ccbSetMeshBufferVertexTextureCoord(meshNode,meshBuffer,newVertex.index,newVertex.textureCoord);
        ccbSetMeshBufferVertexNormal(meshNode,meshBuffer,newVertex.index,newVertex.normal);
        ccbSetMeshBufferVertexColor(meshNode,meshBuffer,newVertex.index,newVertex.color);
        
        ccbSetMeshBufferIndexValue(meshNode,meshBuffer,omega,newVertex.index);
        ccbAddMeshBufferIndex(meshNode,meshBuffer,newVertex.index);
        ccbAddMeshBufferIndex(meshNode,meshBuffer,beta.index);
        ccbAddMeshBufferIndex(meshNode,meshBuffer,gamma.index);
        
        ++newPolygonsIndex;
        return(newIndexBase);
    }
    function getLineLength(vertexA,vertexB) {
        var xLength = vertexA.position.x - vertexB.position.x;
        var yLength = vertexA.position.y - vertexB.position.y;
        var zLength = vertexA.position.z - vertexB.position.z;
        var lineLength = Math.sqrt((xLength*xLength)+(yLength*yLength)+(zLength*zLength));
        return(lineLength);
    }
    function getMidPointPosition(vertexA,vertexB) {
        var midPointPosition = {};
        midPointPosition.x = getAverage(vertexA.position.x,vertexB.position.x);
        midPointPosition.y = getAverage(vertexA.position.y,vertexB.position.y);
        midPointPosition.z = getAverage(vertexA.position.z,vertexB.position.z);
        return(midPointPosition);
    }
    function getMidPointTextureCoord(vertexA,vertexB){
        var midPointTextureCoord = {};
        midPointTextureCoord.x = getAverage(vertexA.textureCoord.x,vertexB.textureCoord.x);
        midPointTextureCoord.y = getAverage(vertexA.textureCoord.y,vertexB.textureCoord.y);
        return(midPointTextureCoord);
    }
    function getMidPointNormal(vertexA,vertexB){
        var midPointNormal = {};
        midPointNormal.x = getAverage(vertexA.normal.x,vertexB.normal.x);
        midPointNormal.y = getAverage(vertexA.normal.y,vertexB.normal.y);
        midPointNormal.z = getAverage(vertexA.normal.z,vertexB.normal.z);
        return(midPointNormal);
    }
    function getMidPointColor(vertexA,vertexB){
        if (vertexA.color==vertexB.color) {
            var midPointColor = vertexA.color;
        }
        else {
            var midPointColorRGBA = {};
            var rgba1 = decodeColor(vertexA.color);
            var rgba2 = decodeColor(vertexB.color);
            midPointColorRGBA.alpha = getAverage(rgba1.alpha,rgba2.alpha);
            midPointColorRGBA.red = getAverage(rgba1.red,rgba2.red);
            midPointColorRGBA.green = getAverage(rgba1.green,rgba2.green);
            midPointColorRGBA.blue = getAverage(rgba1.blue,rgba2.blue);
            var midPointColor = encodeColor(midPointColorRGBA);
        }
        return(midPointColor);
    }
    function decodeColor(rgbaInt) {
        var rgba = {};
        rgba.alpha = (rgbaInt>>24)&0xff;
        rgba.red = (rgbaInt>>16)&0xff;
        rgba.green = (rgbaInt>>8)&0xff;
        rgba.blue = (rgbaInt)&0xff;
        return(rgba);
    }
    function encodeColor(rgba) {
        a = (rgba.alpha&0xff)<<24;
        r = (rgba.red&0xff)<<16;
        g = (rgba.green&0xff)<<8;
        b = (rgba.blue&0xff);
        var rgbaInt = a | r | g | b;
        return(rgbaInt);
    }
    function getAverage(number1,number2) {
        return((number1 + number2)/2);
    }
    var end = Date.now();
    var fileSizeIncrease = Math.round(newPolygonsIndex * 0.175 * 100) / 100;
    var processingTime = (end - start) / 1000;
    var splitOperationsPerSecond = Math.floor(newPolygonsIndex / processingTime);
    var resultSummary = 'Processing complete. You may now lightmap this scene using the following settings:\n\nTexture Size: ' + targetTextureSize + 'x' + targetTextureSize + '\n\nResolution: ' + targetResolution + '\n\nSTATISTICS:\nOversize polygons found: ' + oversizePolygonsIndex + '\nNew polygons generated: ' + newPolygonsIndex + '\nEstimated download cost: ' + fileSizeIncrease + ' KB\nProcessing time: ' + processingTime + ' secs\nSplit operations per second: ' + splitOperationsPerSecond;
    print(resultSummary);
    alert(resultSummary);
}
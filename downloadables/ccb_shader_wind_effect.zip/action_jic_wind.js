/*	Info 
	
	Extension Name	: Action Wind Shader
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: January 27, 2022, 19:03 PM
	Description		: Allows you to apply wind effects to any object in Coppercube
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	Discord Server :- https://discord.gg/RKcq89S7uA
	YouTube :- https://www.youtube.com/GlitchedVelocity
	Itch.io :- https://vazahat.itch.io/
    Website - https://neophyte.cf
  
	

*/
/*	Changelog

    [January 27, 2022]	- Added Basic Shader code
					- Added all the action parameters to be used in shader callback
					- Compiled the main wind calculation into the shader
					- Fixed bug that was causing the wind speed to increase and decrease as per the view direction
	[January 28, 2022]  - Fixed a bug with the heightoffset of the wind that was causing it to not work with the planemeshes.
					- Added a new parameter texture based heighoffset as it can be helpful in many cases, update the shader code to respect that.
    [July 12, 2022]	- Added Support for fog ( windows platform only). 

					

	
*/



/* Usage
  Attach this action to a behavior event and fill in the required parameter. You need to alter the default values to get the desired wind effects for your object.
  Watch the Video tutorial on Youtube to learn more about the usage of this shader action.

  	Itch.io - https://vazahat.itch.io/cc-shader-spritesheet-animation
    Youtube - https://www.youtube.com/channel/UC_yfoGEKkmY63tnyy6hR7ZQ
    Website - https://neophyte.cf
    Discord - https://discord.gg/RKcq89S7uA

*/

/*  <action jsname="action_jic_wind" description="Apply Wind Shader">
	  <property name="Affecting_node" type="scenenode"/>
	  <property name="Affect_all_material" type="bool" default="true" />
	  <property name="Affecting_material" type="int" default="1" />
	  <property name="Base_material_type" type="int" default="0" />
	  <property name="WindQuality" type="int" default="1.0" />
	  <property name="WindStrength" type="int" default="0.1" />
	  <property name="WindHeightOffset" type="int" default="0.0" />
      <property name="WindTextureHeightOffset" type="int" default="0.0" />
	  <property name="WindSpeed" type="int" default="0.1" />
	  <property name="WindDirectionX" type="int" default="1.0" />
	  <property name="WindDirectionY" type="int" default="1.0" />
	  <property name="Fog_Enabled" type="bool" default="true" />
    </action>
*/
action_jic_wind = function()
{

};

action_jic_wind.prototype.execute = function()
{	
	this.Affecting_material -= 1;

	
//Shader Part
var vertexShader = 
"		float4x4 mWorldViewProj;  // World * View * Projection 					\n" + 
"		float4x4 mTransWorld;     // Transposed world matrix					\n" +
"		float4x4 mInvWorld;       // Inverted world matrix	 					\n" + 
"		float mFogDensity ;														\n" + 
"		float fogEnable ;														\n" + 
"		float timer;															\n" +
"		float speed;															\n" +
"		float strength;														    \n" +
"		float quality;															\n" +
"		float heightoffset;													    \n" +
"		float texheightoffset;													\n" +
"		float2 direction;														\n" +
"		// Output to fragment program V2F										\n" + 
"		struct VS_OUTPUT														\n" + 
"		{																		\n" + 
"			float4 Position   : POSITION;   // vertex position 					\n" + 
"			float2 TexCoord   : TEXCOORD0;  // tex coords						\n" + 
"			float3 worldNormal  : TEXCOORD1;  // tex coords						\n" +
"			float Fog	: FOG;													\n" +
"		};																		\n" + 
"																				\n" + 
"			//Input From app to vertex program A2V								\n" + 
"		VS_OUTPUT main      ( in float4 vPosition : POSITION,					\n" +
"		                      in float3 vNormal   : NORMAL,						\n" +
"		                      float2 texCoord     : TEXCOORD0 )					\n" +  
"		{																		\n" + 
"			//Vertex Shader														\n" + 
"			VS_OUTPUT Output;													\n" + 
"																				\n" + 
"			float3 worldPos = mul(mTransWorld, vPosition);					    \n" + 
"			Output.Position = mul(vPosition, mWorldViewProj);					\n" + 
"			float timez = timer * speed + vPosition.x + vPosition.y;			\n" +  // we can also use worldPosition here instead of vertex position if we want the wind direction to be affected on the basis of the world, just like CC's inbuilt wind material that uses a world based wind movement instead of per material wind.
"			float wind = (sin(timez) + cos(timez * quality)) * strength * max(1.0, vPosition.y - heightoffset);	\n" + // we used 1.0 as the minimum value otherwise it will not work with planemeshes, cause they have vertex Position at 0.
"			float2 dir = normalize(direction); 									\n" +
"			if (texCoord.y < 1- texheightoffset)								\n" + // Texture height based wind mapping, it works better with non flat 3D surfaces.
"				Output.Position.xy += float2(wind * dir.x, wind * dir.y);		\n" +
"			Output.worldNormal = mul(vNormal, mInvWorld);						\n" + // this has no use, if you want you can comment out this line or completely remove it.
"			Output.TexCoord = texCoord;											\n" + 
"			if (fogEnable == 1)											    	\n" + 
"   		{ 																	\n" + 
"     			Output.Fog = saturate(1.0 / exp(Output.Position.z * mFogDensity));	\n" + 
"  			}																	\n" + 
"  			else																\n" + 
"  			 {     																\n" + 
"     			Output.Fog = 1;													\n" + 
"   		 }  																\n" + 
"			return Output;														\n" + 
"		}";

var fragmentShader = 
"		struct PS_OUTPUT																\n" + 
"		{																				\n" + 
"		    float4 RGBColor : COLOR; 		  											\n" +	
"		};																				\n" +
"																						\n" + 
"		float4 FogColor;																\n" +
"		sampler2D tex0;																	\n" + 
"																						\n" +
"		PS_OUTPUT main( float2 TexCoord : TEXCOORD0,									\n" +
"						float Fog    : FOG,												\n" +
"		                float4 Position : POSITION)										\n" +
"		{ 																				\n" +
"			PS_OUTPUT Output;															\n" +
"		    float4 ColorTexture = tex2D(tex0, TexCoord);								\n" +
"			float4 fogcol = FogColor*(1-Fog);											\n"	+
"			Output.RGBColor =  float4(ColorTexture.rgb*Fog+fogcol.rgb,ColorTexture.a);	\n" +  
"			return Output;																\n" +
"		}";

var me = this; 
//Shader Callaback Function
var timer = 0;

myShaderCallBack = function()
{
	var GlobalfogEnable = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"Fog");
	var fogEnable = me.Fog_Enabled;
	if(fogEnable && GlobalfogEnable){var fogenable = 1;var fogDensity = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogDensity");
	var fogColor = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogColor");}
	else{ var fogenable = 0; var fogColor = new vector3d(1,1,1)};
	
	timer += 0.1;  // timer we can try changing 1 to a different value to check how diffrent effect it will give in the shader.
	
	ccbSetShaderConstant(1, 'timer', timer,0,0,0);
	ccbSetShaderConstant(1, 'quality', me.WindQuality,0,0,0);
	ccbSetShaderConstant(1, 'strength', me.WindStrength,0,0,0);
	ccbSetShaderConstant(1, 'speed', me.WindSpeed,0,0,0);
	ccbSetShaderConstant(1, 'heightoffset', me.WindHeightOffset,0,0,0);
    ccbSetShaderConstant(1, 'texheightoffset', me.WindTextureHeightOffset,0,0,0);
	ccbSetShaderConstant(1, 'direction', me.WindDirectionX,me.WindDirectionY,0,0);
	ccbSetShaderConstant(2, 'FogColor', fogColor.x,fogColor.y,fogColor.z,1);
	ccbSetShaderConstant(1, 'mFogDensity', fogDensity,0,0,0);
	ccbSetShaderConstant(1, 'fogEnable', fogenable,0,0,0);

}
// creating Material
var newMaterial = ccbCreateMaterial(vertexShader, fragmentShader, this.Base_material_type, myShaderCallBack);

//Check Material index and apply to sepcifed mat index or to all the materials.
var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

for(var i = 0; i<matCount; ++i)
{
	if(this.Affect_all_material)
	{
		ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial);
	}
	else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial);}
}

}
 
 /*End Of Code*/
 
// Above extension is written by Vazahat Khan (just_in_case) //
 
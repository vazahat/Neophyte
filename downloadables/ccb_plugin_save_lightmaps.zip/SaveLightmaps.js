/*	Info 
	
	Extension Name	: Plugin Save lightmap textures to disk
	Extension Type	: Plugin
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: August 22, 2022, 08:01 AM
	Description		: Allows you to create 2D animations in no time. 
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal  - http://paypal.me/Vazahat
	Itch.io - https://vazahat.itch.io/cc-shader-spritesheet-animation
	Youtube - https://www.youtube.com/channel/UC_yfoGEKkmY63tnyy6hR7ZQ
	Website - https://neophyte.cf
    Discord - https://discord.gg/RKcq89S7uA	

*/
/*	Changelog

	[August 22, 2022] - Created the plugin and added all the features including warnings and prompts

					 
*/

function SaveLightmaps() 
{
    var node = editorGetSelectedSceneNode();
    var count = ccbGetSceneNodeMaterialCount(node);
    var type = ccbGetSceneNodeMaterialProperty(node, material, "Type");
    if(type == "lightmap" || type == "lightmap_add" || type == "lightmap_m2" || type == "lightmap_m4" || type == "lightmap_light" || type  == "lightmap_light_m2" || type == "lightmap_light_m4"){
        var material = prompt("Please enter material number that you want to save", "1");
        if(material > count){alert("Specified material not found for the scenenode, Please make sure you are entering correct material number")}
        else
        {
            var texture = ccbGetSceneNodeMaterialProperty(node, 0, "Texture2");
            var path = editorGetFileNameFromDialog("please select something",  " All supported files (*.bmp;*.jpg;*.pcx;*.psd;*.tga;*.png;*.dds)|*.bmp;*.jpg;*.pcx;*.psd;*.tga;*.png;*.dds|Windows Bitmap files (*.bmp)|*.bmp|JPEG File Interchange Format (*.jpg)|*.jpg|Zsoft Paintbrush (*.pcx)|*.pcx|Adobe Photoshop (*.psd)|*.psd|Truevision Targa (*.tga)|.tga|Portable Network Graphics (*.png)|*.png|DirectDraw Surface (*.dds)|*.dds|All Files (*.*)|*.*", false);
            ccbSaveTexture(texture, path);}
        }
    else{alert("Selected scenenode has no lightmapped Material")}
}

//register the function as menu entry with key codes
editorRegisterMenuEntry("SaveLightmaps()", "Save internal Lightmaps to disk \tCtrl+Shift+T");


// Above plugin/extension is written by Vazahat Khan (just_in_case) //
//You are not allowed to remove this License info or any attribution details//

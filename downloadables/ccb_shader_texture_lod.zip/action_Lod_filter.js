/*	Info 
	
	Extension Name	: Action Texture Lod
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: July 11, 2021, 22:12 PM
	Description		: Allows you to have real-time mip mapping for the textures in your game. 
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
    PayPal: http://paypal.me/Vazahat
	Discord Server :- https://discord.gg/RKcq89S7uA
	YouTube :- https://www.youtube.com/GlitchedVelocity
	Itch.io :- https://vazahat.itch.io/
    Website - https://neophyte.cf
  
	

*/
/*	Changelog

    [February 15, 2022]	- Created the LOD filter shader
    [July 12, 2022]	- Added Support for fog ( windows platform only). 


/*  <action jsname="action_Lod_filter" description="Texture LOD filter ">
	  <property name="Affecting_node" type="scenenode"/>
	  <property name="Affect_all_material" type="bool" default="true" />
	  <property name="Affecting_material" type="int" default="1" />
	  <property name="Base_material_type" type="int" default="0" />
	  <property name="LOD_Level" type="int" default="6" />
	  <property name="Fog_Enabled" type="bool" default="true" />
    </action>
*/

action_Lod_filter = function()
{
};

action_Lod_filter.prototype.execute = function()
{

    var vertexShader = 
    "float4x4 mWorldViewProj;  // World * View * Projection \n" + 
    "float4x4 mInvWorld;       // Inverted world matrix	 	\n" + 
    "float4x4 mTransWorld;     // Transposed world matrix	\n" + 
    "float mFogDensity ;			    					\n" + 
    "float fogEnable ;										\n" + 
    "														\n" + 
    "// Vertex shader output structure						\n" + 
    "struct VS_OUTPUT										\n" + 
    "{														\n" + 
    "	float4 Position   : POSITION;   // vertex position 	\n" + 
    "	float4 Diffuse    : COLOR0;     // vertex diffuse 	\n" + 
    "	float2 TexCoord   : TEXCOORD0;  // tex coords		\n" + 
    "   float Fog	: FOG;									\n" +
    "};														\n" + 
    "														\n" + 
    "VS_OUTPUT main      ( in float4 vPosition : POSITION,	\n" + 
    "                      in float3 vNormal   : NORMAL,	\n" + 
    "                      float2 texCoord     : TEXCOORD0 )\n" + 
    "{														\n" + 
    "	VS_OUTPUT Output;									\n" + 
    "														\n" + 
    "	// transform position to clip space 				\n" + 
    "	Output.Position = mul(vPosition, mWorldViewProj);	\n" + 
    "														\n" + 
    "	// transformed normal would be this:				\n" + 
    "	float3 normal = mul(vNormal, mInvWorld);			\n" + 
    "														\n" + 
    "	// position in world coodinates	would be this:		\n" + 
    "	// float3 worldpos = mul(mTransWorld, vPosition);	\n" + 
    "														\n" + 
    "	Output.Diffuse = float4(1.0, 1.0, 1.0, 1.0);		\n" + 
    "	Output.TexCoord = texCoord;							\n" + 
    "														\n" + 
    "			if (fogEnable == 1)							\n" + 
    "   		{ 											\n" + 
    "     			Output.Fog = saturate(1.0 / exp(Output.Position.z * mFogDensity));	\n" + 
    "  			}											\n" + 
    "  			else										\n" + 
    "  			 {     										\n" + 
    "     			Output.Fog = 1;							\n" + 
    "   		 }  				    					\n" + 
    "	return Output;										\n" + 
    "}														";
    
    var fragmentShader = 
    "struct PS_OUTPUT								\n" + 
    "{												\n" + 
    "    float4 RGBColor : COLOR0; 		  			\n" +	
    "};												\n" +
    "float4 LOD;									\n" + 
    "float4 FogColor;								\n" +
    "sampler2D tex0;								\n" + 
    "												\n" +
    "PS_OUTPUT main( float2 TexCoord : TEXCOORD0,	\n" +
    "                float4 Position : POSITION,	\n" +
    "				 float Fog    : FOG,			\n" +
    "                float4 Diffuse  : COLOR0 ) 	\n" +
    "{ 												\n" +
    "	PS_OUTPUT Output;							\n" +
    "	float4 col = tex2Dlod( tex0,float4(TexCoord,1,LOD.x) );  	\n" + 
    "	float4 ColorTexture = Diffuse * col;		\n" +
    "	float4 fogcol = FogColor*(1-Fog);			\n"	+
    "	Output.RGBColor =  float4(ColorTexture.rgb*Fog+fogcol.rgb,ColorTexture.a);	\n" +  
    "	return Output;								\n" +
    "}";

var me = this; 
myShaderCallBack = function()
{
	var GlobalfogEnable = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"Fog");
	var fogEnable = me.Fog_Enabled;
	if(fogEnable && GlobalfogEnable){var fogenable = 1;var fogDensity = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogDensity");
	var fogColor = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogColor");}
	else{ var fogenable = 0; var fogColor = new vector3d(1,1,1)};
    
    ccbSetShaderConstant(2, 'LOD', me.LOD_Level,1,1,1);		
    ccbSetShaderConstant(2, 'FogColor', fogColor.x,fogColor.y,fogColor.z,1);
	ccbSetShaderConstant(1, 'mFogDensity', fogDensity,0,0,0);
	ccbSetShaderConstant(1, 'fogEnable', fogenable,0,0,0);
};
// creating Material
var newMaterial = ccbCreateMaterial(vertexShader, fragmentShader, this.Base_material_type, myShaderCallBack);

//Check Material index and apply to sepcifed mat index or to all the materials.
var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

for(var i= 0; i<matCount; ++i)
{
	if(this.Affect_all_material)
	{
		ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial);
		ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Param1', this.Param1);
	}
	else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial);ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Param1', this.Param1);}
}
}
 
 /*End Of Code*/
 
// Above extension is written by Vazahat Khan (just_in_case) //

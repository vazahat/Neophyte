// This is a coppercube behavior which moves the node it is attached to by a click onto a 3d position where it should walk to.
//
// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*
	<behavior jsname="behavior_moveObjectByPositionClick" description="Move Object by 3D Position Click">
		<property name="Speed" type="float" default="0.02" />
		<property name="JumpSpeed" type="float" default="0.1" />
		<property name="JumpLengthMs" type="int" default="200" />
		<property name="JumpSpeedForward" type="float" default="0.1" />
		<property name="RotateSpeed" type="float" default="300" />		
		<property name="StandAnimation" type="string" default="stand" />
		<property name="WalkAnimation" type="string" default="walk" />
		<property name="JumpAnimation" type="string" default="jump" />
	</behavior>
*/

behavior_moveObjectByPositionClick = function()
{
	this.PressedJump = false;
	this.LastTime = null;
	this.JumpForce = 0;
	this.JumpLengthMs = 1000;
	
	this.loopJumpAnimation = false;
	this.TargetPosition = null;
};

// called every frame. 
//   'node' is the scene node where this behavior is attached to.
//   'timeMs' the current time in milliseconds of the scene.
// Returns 'true' if something changed, and 'false' if not.
behavior_moveObjectByPositionClick.prototype.onAnimate = function(node, timeMs)
{
	// get the time since the last frame
	
	if (this.LastTime == null)
	{
		this.LastTime = timeMs; // we were never called before, so store the time and cancel
		return false;
	}
	
	this.LastNodeUsed = node;
	
	var timeDiff = timeMs - this.LastTime;
	this.LastTime = timeMs;
	if (timeDiff > 200) timeDiff = 200;
	
	var currentRot = ccbGetSceneNodeProperty(node, 'Rotation');	
	var pos = ccbGetSceneNodeProperty(node, 'Position');
	var directionForward = new vector3d(0.0,0.0,0.0);
	var lengthToGo = 0.0;
	var bMovingForward = false;
		
	// get wanted rotation
		
	if (this.TargetPosition != null)
	{
		directionForward = this.TargetPosition.substract(pos);
		directionForward.Y = 0.0;
		lengthToGo = directionForward.getLength();
		bMovingForward = lengthToGo > (this.Speed * 200);
						
		if (bMovingForward)
		{
			var angley = Math.atan2(directionForward.x, directionForward.z) * (180.0 / 3.14159265358);

			if (angley < 0.0) angley += 360.0;
			if (angley >= 360.0) angley -= 360.0;
				
			ccbSetSceneNodeProperty(node, 'Rotation', 0.0, angley, 0.0);
		}
	}
	
	if (bMovingForward)
	{
		// move forward/backward
		
		var speed = this.Speed * timeDiff;
		
		directionForward.normalize();
		pos.x += directionForward.x * speed;
		pos.y += directionForward.y * speed;
		pos.z += directionForward.z * speed;
	}
	
	// jump if jump was pressed
		
	if (this.PressedJump && this.JumpForce == 0)
	{
		this.PressedJump = false;
		this.JumpForce = this.JumpLengthMs;
	}
		
	if (this.JumpForce > 0)
	{
		pos.y += this.JumpSpeed * timeDiff;
		this.JumpForce -= timeDiff;
		
		if (this.JumpForce < 0) 
			this.JumpForce = 0;
			
		if (this.JumpSpeedForward > 0)
		{
			directionForward.normalize();
			directionForward.x *= this.JumpSpeedForward;
			directionForward.y *= this.JumpSpeedForward;
			directionForward.z *= this.JumpSpeedForward;
			
			pos.x += directionForward.x;
			pos.y += directionForward.y;
			pos.z += directionForward.z;
		}
	}
	
	// set animation
		
	if (this.JumpForce > 0)
	{
		ccbSetSceneNodeProperty(node, 'Animation', this.JumpAnimation);		
		if (!this.loopJumpAnimation)
			ccbSetSceneNodeProperty(node, 'Looping', false);
	}
	else
	if (bMovingForward)
	{
		ccbSetSceneNodeProperty(node, 'Animation', this.WalkAnimation);
		ccbSetSceneNodeProperty(node, 'Looping', true);
	}
	else
	{
		ccbSetSceneNodeProperty(node, 'Animation', this.StandAnimation);
		ccbSetSceneNodeProperty(node, 'Looping', true);
	}

	// set position
	
	ccbSetSceneNodeProperty(node, 'Position', pos); 
	
	return true;
}

// parameters: key: key id pressed or left up.  pressed: true if the key was pressed down, false if left up
behavior_moveObjectByPositionClick.prototype.onKeyEvent = function(code, down)
{
	// store which key is down
	// key codes are this: left=37, up=38, right=39, down=40

	// jump when space pressed
	
	if (code == 32 && down)
		this.PressedJump = true;
}

		

// mouseEvent: 0=move moved, 1=mouse clicked, 2=left mouse up,  3=left mouse down, 4=right mouse up, 5=right mouse up
behavior_moveObjectByPositionClick.prototype.onMouseEvent = function(mouseEvent, mouseWheelDelta)
{
	// we currently don't support move event. But for later use maybe.

	if (mouseEvent == 2)
	{	
		var mouseX = ccbGetMousePosX();
		var mouseY = ccbGetMousePosY();
		
		var startPos3d = ccbGetSceneNodeProperty(ccbGetActiveCamera(), "Position");
		var endPos3d = ccbGet3DPosFrom2DPos(mouseX, mouseY);
		
		if (endPos3d != null)
		{
			endPos3d = new vector3d(endPos3d.x, endPos3d.y, endPos3d.z);  // bugfix for a bug in android and flash implementation of version 4.5 for returning 3d vectors
			var dir = endPos3d.substract(startPos3d);
			dir.normalize();
			dir.x *= 1000;
			dir.y *= 1000;
			dir.z *= 1000;
			endPos3d = startPos3d.add(dir); 
					
			var colPos = ccbGetCollisionPointOfWorldWithLine(startPos3d.x, startPos3d.y, startPos3d.z, endPos3d.x, endPos3d.y, endPos3d.z);
					
			if (colPos != null)
				this.TargetPosition = new vector3d(colPos.x, colPos.y, colPos.z); // bugfix for a bug in android and flash implementation of version 4.5 for returning 3d vectors
		}
	}
}

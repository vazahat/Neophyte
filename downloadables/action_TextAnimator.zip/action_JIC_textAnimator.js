/*	Info 
	
	Extension Name	: Text Animator
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: ‎‎July ‎05, ‎2021, 3:46 PM
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	

*/
/*	Changelog

    [July ‎05, ‎2021] - Modified previous Behavior and converted into an Action.
					- Added new property to execute action when animation is completed(finished).
					- Some bug fixes.
					- Removed previous code residual.
*/

/*
	<action jsname="action_JIC_textAnimator" description="Text Animator">
		<property name="Text" type="string" value="text" />
		<property name="SceneNode" type="scenenode" />
        <property name="Speed" type="integer" default="100" />
		<property name="ActionWhenFinished" type="action" />
	</action>
*/

action_JIC_textAnimator = function()
{
	'use strict';
    this.ReSpeed = true;
};

// called when the action is executed 
action_JIC_textAnimator.prototype.execute = function(currentNode, timMs)
{
	this.variation = 0;
	var me = this;
	this.variable = ccbGetCopperCubeVariable('!@#&*variable'+"\""+this.variation+"\"");	
	this.registeredFunction = function() { me.textAnimateFunc(); }; 
	ccbRegisterOnFrameEvent(this.registeredFunction);
	if(this.variable != "" || this.variable != undefined)
	{
		this.variation++
	}
	ccbSetCopperCubeVariable('!@#&*variable'+"\""+this.variation+"\"", 0);
}
action_JIC_textAnimator.prototype.textAnimateFunc = function()
{			
	var timeMs = (new Date()).getTime();	
	'use strict';
    if (this.ReSpeed) {    
        this.speedTimer =  this.Speed + timeMs;       
        this.ReSpeed = false;
    }
	// Variables and properties items
	var message = this.Text;
	this.result = message.charAt(0);
	this.variable = ccbGetCopperCubeVariable('!@#&*variable'+"\""+this.variation+"\"");
	this.index = this.variable;
	this.overlay = this.SceneNode;
	
    if (this.speedTimer < timeMs) {    //Printing/animating String Characters at 2d Overlay
		this.index++;
		this.ReSpeed = true;
		ccbSetCopperCubeVariable('!@#&*variable'+"\""+this.variation+"\"", this.index);//creating hard to guess CC Variable
		this.value = this.variable; 
		this.result = message.charAt(this.value);
		this.effect = message.slice(0,this.value);
		this.message = this.Text;
		ccbSetSceneNodeProperty(this.overlay, 'Draw Text', true);
		ccbSetSceneNodeProperty(this.overlay, 'Text', this.effect);
		this.ReSpeed = true;     
    }
	if (this.index == this.Text.length+1)		//stop animating when the text is drawn completely.
	{
		ccbUnregisterOnFrameEvent(this.registeredFunction);
		ccbInvokeAction(this.ActionWhenFinished, this.currentNode);
	}
}

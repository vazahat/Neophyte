// This is a coppercube behavior which moves the node it is attached to only on the x axis,
// controlled by the cursor keys and with space for 'jump'.
//
// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*
	<behavior jsname="behavior_OnGround" description="Do something if an object is on ground">
		<property name="object" type="scenenode"/>
		<property name="ActionWhenGrounded" type="action" />
	</behavior>
*/

behavior_OnGround = function()
{
	this.ForwardKeyDown = false;
	this.BackKeyDown = false;
	this.PressedJump = false;
	this.LastTime = null;
	this.JumpForce = 0;
	this.JumpLengthMs = 1000;
};

// called every frame. 
//   'node' is the scene node where this behavior is attached to.
//   'timeMs' the current time in milliseconds of the scene.
// Returns 'true' if something changed, and 'false' if not.
behavior_OnGround.prototype.onAnimate = function(node, timeMs)
{
var s = this.object;
var type = ccbGetSceneNodeProperty(s, "Type");
	if (type.indexOf("mesh") != -1)
{
	
	var pos = ccbGetSceneNodeProperty(s, "Position");
	for (i=0; i<501; i++)
	{
	var adj = i/10;
	if (ccbDoesLineCollideWithBoundingBoxOfSceneNode(s, pos.x, pos.y-100, pos.z, pos.x, pos.y-50+adj, pos.z))
		{
	var dist = 50-adj;
	i = 500;
		}
	}
	var gnd = ccbGetCollisionPointOfWorldWithLine(pos.x, pos.y, pos.z, pos.x, pos.y-500, pos.z);
	if (gnd != null && dist != undefined) 
	{
	if (pos.y <= gnd.y+dist)
	{
	ccbInvokeAction(this.Action, node);
	}
	} else if (dist != undefined)
		{
		print("floor not found");
		}
		else
		{
		print("try move it slightly (can't be child node)");
		}
} else
	{
	print("must be 3d mesh");
	}
}

//Originally created as a plugin by @Robo from Coppercube Forums, Altered/Modified and converted into behavior by Just_in_case (Vazahat) ...

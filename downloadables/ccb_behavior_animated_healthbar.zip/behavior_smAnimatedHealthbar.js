/*  
  <behavior jsname="behavior_smAnimatedHealthbar" description="SM Animated Healthbar">
  	<property name="BarColor" type="color" default="77ff0000" />
  	<property name="BackgroundColor" type="color" default="ffffffff" />
  	<property name="Width" type="int" default="100" />
  	<property name="Height" type="int" default="5" />
  	<property name="BorderSize" type="float" default="2" />
  	<property name="AnimationSpeed" type="float" default="1" />
  	<property name="LookHeight" type="float" default="5" />
  	<property name="Display2d" type="bool" default="false" />
  	<property name="YPositionPercent2d" type="float" default="90" />
  	<property name="XPositionPercent2d" type="float" default="50" />
  	<property name="ActiveRadius" type="float" default="100" />
  	<property name="RemoveOnDie" type="bool" default="true" />
  	<property name="AnimatedClosingAndOpening" type="bool" default="true" />
  	<property name="ExternalHealthVariable" type="string" default="" />
  </behavior>
*/

/* 
	(C) Smn Mhmdy, (smarturl.it/SmnMhmdy \\ autosam.sm@gmail.com \\ discord.gg/e6TpKsq)
	September 5, 2021 \\ version 1.2
*/

var smHealthbarRegister; // an object containing the list of registered nodes

behavior_smAnimatedHealthbar = function(){
	if(!smHealthbarRegister) smHealthbarRegister = {};

	this.lastTime = 0;
	this.DistanceCheckInterval = 0;
	this.Distance = 0;
}

behavior_smAnimatedHealthbar.prototype.onAnimate = function(node, Time){
	if(!this.node){ // doing this only once
		this.node = node;
		this.name = ccbGetSceneNodeProperty(node, "Name");

		if(!this.ExternalHealthVariable)
			this.maxHealth = ccbGetCopperCubeVariable("#" + this.name + ".health");
		else
			this.maxHealth = ccbGetCopperCubeVariable(this.ExternalHealthVariable);

		this.halfWidth = this.Width / 2, this.halfHeight = this.Height / 2;
		this.AnimatedHealth = this.maxHealth / 2;
		this.AnimatedWidth = this.Width;
	}

	// time
	this.Time = Time;
	this.deltaTime = Time - this.lastTime;
	this.lastTime = Time;

	this.Position = ccbGetSceneNodeProperty(node, "PositionAbs");

	if(this.Display2d){
		var screenH = ccbGetScreenHeight(), screenW = ccbGetScreenWidth();
		this.Position2d = new vector3d(this.XPositionPercent2d * screenW / 100, this.YPositionPercent2d * screenH / 100, 0);
	}
	else
		this.Position2d = ccbGet2DPosFrom3DPos(this.Position.x, this.Position.y + this.LookHeight, this.Position.z);

	// health
	if(!this.ExternalHealthVariable)
		this.Health = ccbGetCopperCubeVariable("#" + this.name + ".health") - this.maxHealth / 2;
	else
		this.Health = ccbGetCopperCubeVariable(this.ExternalHealthVariable) - this.maxHealth / 2;

	if(this.AnimatedHealth > this.Health)
		this.AnimatedHealth -= this.AnimationSpeed * this.deltaTime * 0.1;
	if(this.AnimatedHealth < this.Health)
		this.AnimatedHealth = this.Health;

	if(this.DistanceCheckInterval <= 0){
		this.CameraPosition = ccbGetSceneNodeProperty(ccbGetActiveCamera(), "Position");
		this.Distance = this.Position.substract(this.CameraPosition).getLength();
		this.DistanceCheckInterval = 200;
	} else {
		this.DistanceCheckInterval -= this.deltaTime;
	}

	// animated width opening and closing
	if(this.AnimatedClosingAndOpening){
		if(this.AnimatedWidth > 0 && this.Distance <= this.ActiveRadius)
			this.AnimatedWidth -= this.AnimationSpeed * this.deltaTime * 0.1 * 10;
			if(this.AnimatedWidth < 0)
				this.AnimatedWidth = 0;
		else if(this.Distance > this.ActiveRadius){
			this.AnimatedWidth += this.AnimationSpeed * this.deltaTime * 0.1 * 10;
			if(this.AnimatedWidth > this.Width * 1.1)
				this.AnimatedWidth = this.Width * 1.1;
		}
	} else {
		this.AnimatedWidth = 0;
	}

    if(smHealthbarRegister[this.name]) return; // node is already registered

    // registering a new frame event
    var smHealthbar = this;
    this._Update = function(){ smHealthbar.Draw(); };
	ccbRegisterOnFrameEvent(this._Update);
	smHealthbarRegister[this.name] = true; // setting this child's flag to true to prevent multiple frame events on the same node
}

behavior_smAnimatedHealthbar.prototype.Draw = function(){
	if(!ccbGetSceneNodeProperty(this.node, "Name")){
		ccbUnregisterOnFrameEvent(this._Update);
		smHealthbarRegister[this.name] = false;
	}

	if((this.AnimatedClosingAndOpening && this.AnimatedWidth >= this.Width) || (!this.AnimatedClosingAndOpening && this.Distance > this.ActiveRadius) || this.RemoveOnDie && this.AnimatedHealth <= -this.maxHealth / 2) return;

	// background
	ccbDrawColoredRectangle(
		this.BackgroundColor,
		this.Position2d.x - this.halfWidth - this.BorderSize,
		this.Position2d.y - this.halfHeight - this.BorderSize,
		this.Position2d.x + this.halfWidth + this.BorderSize - this.AnimatedWidth,
		this.Position2d.y + this.halfHeight + this.BorderSize
		);

	// bar
	ccbDrawColoredRectangle(
		this.BarColor, 
		this.Position2d.x - this.halfWidth,
		this.Position2d.y - this.halfHeight,
		this.Position2d.x + (this.halfWidth * this.AnimatedHealth) / this.maxHealth * 2 - this.AnimatedWidth, 
		this.Position2d.y + this.halfHeight
		);
}

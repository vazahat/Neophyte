/*	Info 
	
	Extension Name	: Action Split Screen
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: January 30, 2023, 12:41 PM
	Description		: Split Screen with 2 Cameras. 
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	Discord Server :- https://discord.gg/RKcq89S7uA
	YouTube :- https://www.youtube.com/GlitchedVelocity
	Itch.io :- https://vazahat.itch.io/
	

*/

/*  
  <action jsname="action_splitscreen" description="Split Screen with 2 Cameras">
  <property name="Camera1" type="scenenode"/>
  <property name="Camera2" type="scenenode"/>
  <property name="Vertical_Split" type="bool"/>
   
  </action>
*/

action_splitscreen = function(){

}

action_splitscreen.prototype.execute = function (node){
  var splitCheck = ccbGetCopperCubeVariable("splithasbeendoneornot"); // to  prevent frame drops by checking if the screen has been already splitted or not
  var me = this;
  if(splitCheck != "true"){

	this.FrameRegisteredFunction = function() { me.draggingFunc(); }; 
  ccbRegisterOnFrameEvent(this.FrameRegisteredFunction);
  ccbSetCopperCubeVariable("splithasbeendoneornot","true");
}
}

action_splitscreen.prototype.draggingFunc = function()
{
  var scrWidth = ccbGetScreenWidth();
  var scrHeight = ccbGetScreenHeight();
  
   if(this.Vertical_Split)
   {
    ccbSplitScreen(this.Camera1,0,0,scrWidth/2,scrHeight, this.Camera2,scrWidth/2,0,scrWidth,scrHeight);
   }
   else{ccbSplitScreen(this.Camera1,0,0,scrWidth,scrHeight/2, this.Camera2,0,scrHeight/2,scrWidth,scrHeight);} 
}

// ***Author:- VAZAHAT PATHAN***

//        ****AKA****

 //   ****Just_in_case**** 

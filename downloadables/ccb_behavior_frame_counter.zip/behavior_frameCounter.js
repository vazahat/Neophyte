/*  
  <behavior jsname="behavior_frameCounter" description="Frame Counter">
      <property name="Overlay2d" type="scenenode"/>
  </behavior>
*/

var FPS;

behavior_frameCounter = function(){
    this.lastTime = 0;
}

behavior_frameCounter.prototype.onAnimate = function(node, Time){
    // time
    this.deltaTime = Time - this.lastTime;
    this.lastTime = Time;
    this.fps = (1 / this.deltaTime * 1000).toFixed();
    ccbSetSceneNodeProperty(this.Overlay2d, "Text", this.fps);
    FPS = this.fps;
}
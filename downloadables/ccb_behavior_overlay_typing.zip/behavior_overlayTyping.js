// This is a coppercube behavior makes a 2D overlay behave like an edit box. Just attach this behavior to
// any 2D overlay and start typing. Additionally, you can specify a variable name where the text typed is
// being stored.
//
// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*
	<behavior jsname="behavior_overlayTyping" description="Edit Box 2D Overlay">
		<property name="Text" type="string" value="text" />
		<property name="VariableName" type="string" />
	</behavior>
*/

behavior_overlayTyping = function()
{
	this.LastOverlayObject = null;
};


// called every frame. 
//   'node' is the scene node where this behavior is attached to.
//   'timeMs' the current time in milliseconds of the scene.
// Returns 'true' if something changed, and 'false' if not.
behavior_overlayTyping.prototype.onAnimate = function(n, timeMs)
{
	this.LastOverlayObject = n;
	
	return true;
}


// parameters: key: key id pressed or left up.  pressed: true if the key was pressed down, false if left up
behavior_overlayTyping.prototype.onKeyEvent = function(key, pressed)
{
	if (!pressed || this.LastOverlayObject == null)
		return;
		
	if (!ccbGetSceneNodeProperty(this.LastOverlayObject, "Visible"))
		return;
		
	if (key == 8)
	{
		// backspace
		this.Text = this.Text.substring(0, this.Text.length - 1);
	}
	else	
	if (key >=	32)
	{
		this.Text += String.fromCharCode(key);
	}
	
	if (this.LastOverlayObject != null)
	{
		ccbSetSceneNodeProperty(this.LastOverlayObject, 'Draw Text', true);
		ccbSetSceneNodeProperty(this.LastOverlayObject, 'Text', this.Text);
	}
	
	if (this.VariableName != '')
		ccbSetCopperCubeVariable(this.VariableName, this.Text);
}
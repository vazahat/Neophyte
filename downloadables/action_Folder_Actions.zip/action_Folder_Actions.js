

/* <action jsname="action_Folder_Actions" description= "Create Dummy Folder to Organize Actions"  />>
	<property name="Folder_Name" type="string" default="New Folder" />
	<property name="Action_Name" type="string" default="Action1" />

 </action>
*/

action_Folder_Actions = function()
{
	
};

action_Folder_Actions.prototype.execute = function(currentNode)
{
	var  Action = "/* <action jsname="+"\""+"action_Folder"+"\"" + " description= "+"\"" +this.Folder_Name+"\""+"/> \n" +
				"    <property name="+ "\"" + this.Action_Name + "\"" + " type=" + "\"" + "action"+ "\"" +"/> \n" +
				"   </action>	\n"	+
				"*/	\n" +
				"action_Folder = function() \n"+
				"{ \n" +
				"}; \n" +
				" \n" +
				"action_Folder.prototype.execute = function(currentNode) \n" +
				"{ \n" +
				"  ccbInvokeAction("+"\""+this.Action_Name+"\""+"); \n" +
				"}";
				
	function removeWhitepace(x)
	{
		return x.replace(/^\s+|\s+$/gm,'');
	}
	
	system ("echo %USERNAME%>user.tmp");
    var getUser = ccbReadFileContent("user.tmp");
	system ("del /f user.tmp");
	var User = removeWhitepace(getUser);
	ccbWriteFileContent("C:/Users/"+User+"/Documents/CopperCube/extensions/action_Folder.js", Action);
};
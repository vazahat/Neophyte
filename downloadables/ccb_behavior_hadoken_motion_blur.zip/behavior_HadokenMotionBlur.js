//=======================================
// This is a CopperCube Pro/Studio behavior which enables camera motion blur fx by dynamically changing CopperCube's Blur Scene Post Effect.
// The following params can be adjusted:
//=======================================
// MotionBlur_Camera:	fx applied camera
// MotionBlur_Treshold: fx trigger sensitivy
// MotionBlur_Response: fx attack/sustain
// MotionBlur_Strength:	fx strength
//=======================================
// -----> by CopperCube forum member hadoken 2022 <-----
/*
	<behavior jsname="behavior_HadokenMotionBlur" description="behavior_HadokenMotionBlur (CopperCube Pro/Studio)">
		<property name="MotionBlur_Camera" type="scenenode" default="" />
		<property name="MotionBlur_Treshold" type="int" default="30" />
		<property name="MotionBlur_Response" type="int" default="2" />
		<property name="MotionBlur_Strength" type="int" default="10" />
	
	</behavior>
*/

behavior_HadokenMotionBlur = function()
{
	this.counter = 0;
	this.init = 0;
}

behavior_HadokenMotionBlur.prototype.onAnimate = function(currentNode)
{
	//##### calculate this.deltaTime & init this.player_cam_rot_snapshot #####
	this.currentTime = new Date().getTime();
	if(this.init == 0) 
	{
		this.lastTime = this.currentTime; 
		this.player_cam_rot_snapshot = ccbGetSceneNodeProperty(this.MotionBlur_Camera, "Rotation");
		this.init = 1;
	}
    	this.deltaTime = (this.currentTime - this.lastTime) * 0.062;
    	this.lastTime = this.currentTime;	
    	
    	this.player_cam_rot = ccbGetSceneNodeProperty(this.MotionBlur_Camera, "Rotation");
    	    	
    	this.counter += 1*this.deltaTime;
        	
    	if(this.counter > this.MotionBlur_Response)
    	{
    		this.player_cam_rot_snapshot = ccbGetSceneNodeProperty(this.MotionBlur_Camera, "Rotation");
    		this.counter = 0;
    	}
   	
    	this.motionblur_check_x = 10 * Math.abs(this.player_cam_rot.x - this.player_cam_rot_snapshot.x);
    	this.motionblur_check_y = 10 * Math.abs(this.player_cam_rot.y - this.player_cam_rot_snapshot.y);
    	
    	if(this.motionblur_check_x > this.MotionBlur_Treshold || this.motionblur_check_y > this.MotionBlur_Treshold || 
    		this.motionblur_check_x > this.MotionBlur_Treshold && this.motionblur_check_y > this.MotionBlur_Treshold)
    	{
    		var root = ccbGetRootSceneNode();
    		ccbSetSceneNodeProperty(root, "Blur", true);
		ccbSetSceneNodeProperty(root, "Blur_Iterations", this.MotionBlur_Strength);
	}
	if(this.motionblur_check_x < this.MotionBlur_Treshold && this.motionblur_check_y < this.MotionBlur_Treshold)
	{
    		var root = ccbGetRootSceneNode();
    		ccbSetSceneNodeProperty(root, "Blur", false);
	}
	    	
}
// Have fun :-))




/*	Info 
	
	Extension Name	: Shader Action Fade Object
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: July 19,2021, 12:28 PM
	Description		: Fade any object in or out and execute an action when finished fading. 
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	Discord Server :- https://discord.gg/RKcq89S7uA
	YouTube :- https://www.youtube.com/GlitchedVelocity
	Itch.io :- https://vazahat.itch.io/
    Website - https://neophyte.cf
   
  

*/
/*	Changelog

    [July 19, 2021]	- Added Shader action Template from previous self created Shader actions
					- Set shader constants to be used in shader
					- Added other parameters and functionality to apply the shader to specific mat index or to all materals and node to be affected
					- Added fade_in and Fade Out functionality and a Boolean in action parameter to toggle fade-in and fade-out
					- Added Speed parameter and functionality to control the fading speed
					- Added ability to execute an action after the fading process is complete
					- Added ability to auto delete node after the fade out of an object is finished, also added Boolean parameter to the action for same
					- Fixed some issues encountered during development of the shader action, for example making object visible automatically if fading_in and so on.
    [July 12, 2022]	- Added Support for fog ( windows platform only). 

	[November 15, 2022] - Added webGL support
						- Fixed bug wile excuting action on completed.
						- Fixed bug when fading in
	[March 28, 2023] - Fixed a bug with the transparency when fading in transparent object.
		
			ToDo's - Fog support for webGL
	
*/



/* Usage
  
 Attach this action to any behavior, It is highly recommended that you add the behavior to root scenenode or to a node other than the affecting node.
 then check if you want to affect all the materials of a node or want to fade in only a specific material. Unchek the "Fade_out"
 option if you want the object to Fade-In or leave it checked to Fade-out the object. Specify the speed to make how fast or slow the fading process will be.
 
 NOTE:- Make sure to attach the action to any other node while using fade_in effect, make sure the node is invisble when using the fade_in effect. For fade out you need to make sure the node is not invisible or hidden.
*/

/*  <action jsname="action_JIC_fade_object_v1_4" description="Fade-in or Fade-out an object v1.4">
	  <property name="Affecting_node" type="scenenode"/>
	  <property name="Affect_all_material" type="bool" default="true" />
	  <property name="Affecting_material" type="int" default="1" />
	  <property name="Fade_Out" type="bool" default="true"/>
	  <property name="Fade_speed" type="int" default="10"/>
	  <property name="Delete_After_Fade_Out" type="bool"/>
	  <property name="Action_when_Complete" type="action"/>
	  <property name="Fog_Enabled" type="bool" default="true" /> 
	  <property name="webGL doesn't support Fog" type="string" default="webGL doesn't support Fog" /> 
    </action>
*/
action_JIC_fade_object_v1_4 = function()
{

};

action_JIC_fade_object_v1_4.prototype.execute = function()
{	
	this.speed = 0;
	this.Fade_speed *= 0.001;
	var platform = ccbGetPlatform();
	this.Affecting_material -= 1;
if(platform == "windows"  || platform ==  "macosx")
{
//Shader Part
var vertexShader = 
"		float4x4 mWorldViewProj;  // World * View * Projection 					\n" + 
"		float4x4 mTransWorld;     // Transposed world matrix					\n" +
"		float4x4 mInvWorld;       // Inverted world matrix	 					\n" +
"		float mFogDensity ;														\n" + 
"		float fogEnable ;														\n" +  
"		// Output to fragment program V2F										\n" + 
"		struct VS_OUTPUT														\n" + 
"		{																		\n" + 
"			float4 Position   : POSITION;   // vertex position 					\n" + 
"			float2 Texcoord   : TEXCOORD;   // vertex position 					\n" + 
"			float Fog	: FOG;													\n" +
"		};																		\n" + 
"																				\n" + 
"			//Input From app to vertex program A2V								\n" + 
"		VS_OUTPUT main      ( in float4 vPosition : POSITION,					\n" +
"							  in float2 Texcoord : TEXCOORD)					\n" +
"		{																		\n" + 
"			//Vertex Shader														\n" + 
"			VS_OUTPUT Output;													\n" + 
"			Output.Position = mul(vPosition, mWorldViewProj);					\n" + 
"			Output.Texcoord = Texcoord;											\n" + 
"			if (fogEnable == 1)											    	\n" + 
"   		{ 																	\n" + 
"     			Output.Fog = saturate(1.0 / exp(Output.Position.z * mFogDensity));	\n" + 
"  			}																	\n" + 
"  			else																\n" + 
"  			 {     																\n" + 
"     			Output.Fog = 1;													\n" + 
"   		 }  																\n" + 
"			return Output;														\n" + 
"		}";

var fragmentShader = 
"		struct PS_OUTPUT																\n" + 
"		{																				\n" + 
"		    float4 RGBColor : COLOR; 		  											\n" +	
"		};																				\n" +
"		float FadeSpeed;																\n" + 
"		float Fadetype;																	\n" + 
"		float4 FogColor;																\n" +
"		sampler2D tex0;																	\n" +
"		PS_OUTPUT main( float2 Texcoord: TEXCOORD,										\n" +
"						float Fog    : FOG)												\n" +
"		{ 																				\n" +
"			PS_OUTPUT Output;															\n" +
"			float4 mainColor = tex2D(tex0, Texcoord);									\n"	+
"			float alpha = mainColor.a;													\n"	+ 
"			if(Fadetype == 1){mainColor.a += FadeSpeed ;}								\n"	+
"			if(Fadetype == 2){															\n" +
"			mainColor.a = 0 ;															\n" + 
"			mainColor.a -= FadeSpeed*alpha;}											\n" +
"			float4 fogcol = FogColor*(1-Fog);											\n"	+
"			Output.RGBColor =  float4(mainColor.rgb*Fog+fogcol.rgb,mainColor.a);		\n" +  
"			return Output;																\n" +
"}";

var me = this; 		

//Shader Callaback Function

myShaderCallBack = function()
{
	
	var GlobalfogEnable = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"Fog");
	var fogEnable = me.Fog_Enabled;
	if(fogEnable && GlobalfogEnable){var fogenable = 1;var fogDensity = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogDensity");
	var fogColor = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogColor");}
	else{ var fogenable = 0; var fogColor = new vector3d(1,1,1)};
	
	me.speed -= me.Fade_speed;
	if (me.Fade_Out == true)
	{
		var fadetype = 1;
	}
	else 
	{
		fadetype = 2;
	}
	if(me.speed <= -1)
	{	
		if(me.Delete_After_Fade_Out && me.Fade_Out)
		{
			ccbRemoveSceneNode(me.Affecting_node);
		}
		ccbInvokeAction(this.Action_when_Complete);
	}
	ccbSetShaderConstant(2, 'FadeSpeed',me.speed,1,1,1);
	ccbSetShaderConstant(2, 'Fadetype',fadetype,1,1,1);
	ccbSetShaderConstant(2, 'FogColor', fogColor.x,fogColor.y,fogColor.z,1);
	ccbSetShaderConstant(1, 'mFogDensity', fogDensity,0,0,0);
	ccbSetShaderConstant(1, 'fogEnable', fogenable,0,0,0);
}
// creating Material
var newMaterial = ccbCreateMaterial(vertexShader, fragmentShader,13, myShaderCallBack);
//Check Material index and apply to sepcifed mat index or to all the materials.
var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

for(var i=0; i<matCount; ++i)
{
	if(this.Affect_all_material)
	{

		ccbSetSceneNodeProperty(this.Affecting_node,"Visible",true);

		ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial);
	}
	else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial);}
}
}


// Shaders For WEBGL platforms::::::::
if(platform == "webgl")
{

	var vertexShader = 									
			"uniform mat4 worldviewproj;								\n" +
			"															\n" +
			"attribute vec4 vPosition;									\n" +
			"attribute vec4 vNormal;									\n" +
			"attribute vec4 vColor;										\n" +
			"attribute vec2 vTexCoord1;									\n" +
			"attribute vec2 vTexCoord2;									\n" +
			"															\n" +
			"varying vec4 v_color;										\n" +
			"varying vec2 v_texCoord1;									\n" +
			"varying vec2 v_texCoord2;									\n" +
			"															\n" +
			"void main()												\n" +
			"{															\n" +
			"	v_color = vColor;										\n" +
			"	gl_Position = worldviewproj * vPosition;				\n" +
			"	v_texCoord1 = vTexCoord1.st;							\n" +
			"	v_texCoord2 = vTexCoord2.st;							\n" +
			"}															";

			var fragmentShader = 
			"uniform sampler2D texture1;								\n" +
			"uniform sampler2D texture2;								\n" +
			"															\n" +
			"uniform vec4 FadeSpeed;									\n" + 
			"uniform vec4 Fadetype;										\n" + 
			"varying vec2 v_texCoord1;									\n" +
			"varying vec2 v_texCoord2;									\n" +
			"															\n" +
			"void main()												\n" +
			"{															\n" +
			"	vec2 texCoord = vec2(v_texCoord1.s, v_texCoord1.t);		\n" +
			"	vec4 mainColor = texture2D(texture1, texCoord);			\n" +
			"			if(Fadetype.x == 1.0){mainColor = vec4(mainColor.rgb,mainColor.a + FadeSpeed.x) ;}	\n"	+
			"			if(Fadetype.x == 2.0){								\n" + 
			"			mainColor = vec4(texture2D(texture1, texCoord).rgb, 0.0 - FadeSpeed.x*mainColor.a);}				\n" +
			"	gl_FragColor = mainColor;								\n" +
			"}															\n";


			//Shader Callback Function
var me = this; 	
myShaderCallBack = function()
{
	me.speed -= me.Fade_speed;
	if (me.Fade_Out == true)
	{
		var fadetype = 1.0;
	}
	else 
	{
		fadetype = 2.0;
	}
	if(me.speed <= -1)
	{	
		if(me.Delete_After_Fade_Out && me.Fade_Out)
		{
			ccbRemoveSceneNode(me.Affecting_node);
		}
		ccbInvokeAction(me.Action_when_Complete);
	}
	ccbSetShaderConstant(2, 'FadeSpeed',me.speed,me.speed,me.speed,me.speed);
	ccbSetShaderConstant(2, 'Fadetype',fadetype,fadetype,fadetype,fadetype);
}

		var newMaterial = ccbCreateMaterial(vertexShader, fragmentShader,13, myShaderCallBack);
		//Check Material index and apply to specified mat index or to all the materials.
		var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

		for(var i=0; i<matCount; ++i)
		{
			if(this.Affect_all_material)
			{
		
				ccbSetSceneNodeProperty(this.Affecting_node,"Visible",true);
		
				ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial);
			}
			else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial);}
		}
		
	
}

}
 
 /*End Of Code*/
 
 
// Above extension is written by Vazahat Khan (just_in_case) //
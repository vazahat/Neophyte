// This Coppercube behavior can be attached to a directional light and makes it behave like the sun: 
// There will be sunrise, day, sunset, and night.
//
// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*
	<behavior jsname="behavior_dayNightCycle" description="Day Night Cycle for Directional Light">
		<property name="Speed" type="int" default="10.4" />
		<property name="StartTime" type="string" default="06:30" />
		<!-- <property name="DayColor" type="color" default="0xffff0000" /> -->
		<property name="ChangeAmbientLight" type="bool" default="true" />
		<property name="ChangeFogColor" type="bool" default="true" />
		<property name="ChangeBackgroundColor" type="bool" default="true" />
	</behavior>
*/

behavior_dayNightCycle = function()
{
	this.Speed = 1.0;
	this.TimeOfDay = -1;
	this.LastTime = -1;
	
};


// called every frame. 
//   'node' is the scene node where this behavior is attached to.
//   'timeMs' the current time in milliseconds of the scene.
// Returns 'true' if something changed, and 'false' if not.
behavior_dayNightCycle.prototype.onAnimate = function(n, timeMs)
{
	// update time of day
	
	if (this.TimeOfDay == -1)
	{	
		// init from user set time.
		var itime = parseInt(this.StartTime.replace(':', ''));		
		if (!isNaN(itime))
			this.TimeOfDay = (itime - 600) / 2400;
			
		this.LastTime = timeMs;
	}
	
	// continue with time
	
	var delta = timeMs - this.LastTime;
	this.LastTime = timeMs;
			
	// it's day between 0 and 0.5, and between 0.5 and 1 it's night.
		
	this.TimeOfDay += (delta * this.Speed) / 2000000.0;
	if (this.TimeOfDay > 1.0)
		this.TimeOfDay = 1.0 - this.TimeOfDay;
	if (this.TimeOfDay > 1.0)
		this.TimeOfDay = 0;
		
	var timeOfDay = this.TimeOfDay;
		
	// calculate sun position
	
	var sunPosX = Math.sin(timeOfDay*6.2831853)*100.0;
	var sunPosY = Math.sin(timeOfDay*6.2831853)*100.0;
	var sunPosZ = Math.cos(timeOfDay*6.2831853)*100.0;
	
	// calculate color
	
	var minBrighness = this.clamp(Math.abs(0.75 - timeOfDay), 0.0, 0.2); // a value between 0 and 0.2, but darker (==0) when near midnight
	var dayNightBrightnessFact = this.clamp(Math.sin(timeOfDay * 6.2831853) * 2, minBrighness, 1);
	
	var dayColorR = 1;
	var dayColorG = 0.93;
	var dayColorB = 0.788;
	
	//var di = parseInt(this.DayColor);
	//if (!isNaN(di))
	//{
	//	dayColorR = ((di & 0x00FF0000) >> 16);
	//	dayColorG = ((di & 0x0000FF00) >> 8);
	//	dayColorB = ((di & 0x000000FF));
	//}
	
	var currentDayColorR = dayColorR * dayNightBrightnessFact;
	var currentDayColorG = dayColorG * dayNightBrightnessFact;
	var currentDayColorB = dayColorB * dayNightBrightnessFact;
	
	// additionally, we want it red in the morning
	
	if (timeOfDay < 0.2)
	{
		var sunRiseFact = this.clamp(Math.sin((timeOfDay*4) * 6.2831853) * 2, 0.2, 1);
		currentDayColorR += sunRiseFact;
	}
	
	// additionally, we want it red in the evening
	
	if (timeOfDay > (0.5-0.2) && timeOfDay < 0.5)
	{
		var sunRiseFact = this.clamp(Math.sin(((0.5 - timeOfDay)*4) * 6.2831853) * 2, 0.2, 1);
		currentDayColorR += sunRiseFact;
	}
	
	
	currentDayColorR = this.clamp(currentDayColorR, 0, 1);
	currentDayColorG = this.clamp(currentDayColorG, 0, 1);
	currentDayColorB = this.clamp(currentDayColorB, 0, 1);
	
	// light direction
	
	var direction = new vector3d(-sunPosX, -sunPosY, -sunPosZ); 
	direction.normalize();
	
	// save 
	
	ccbSetSceneNodeProperty(n, 'Direction', direction);
	ccbSetSceneNodeProperty(n, 'Color', currentDayColorR * 255, currentDayColorG * 255, currentDayColorB * 255);
	
	// change ambient light, fog color and background
	
	var rootNode = ccbGetRootSceneNode();
	
	if (this.ChangeAmbientLight)
		ccbSetSceneNodeProperty(rootNode, 'AmbientLight', currentDayColorR * 255 * 0.2, currentDayColorG * 255 * 0.2, currentDayColorB * 255 * 0.2);
	
	if (this.ChangeFogColor)
		ccbSetSceneNodeProperty(rootNode, 'FogColor', currentDayColorR * 255, currentDayColorG * 255, currentDayColorB * 255);
	
	if (this.ChangeBackgroundColor)
		ccbSetSceneNodeProperty(rootNode, 'BackgroundColor', currentDayColorR * 255, currentDayColorG * 255, currentDayColorB * 255);
	
	
	
	return true;
}


/** 
 * Returns a new value which is clamped between low and high. 
 */
behavior_dayNightCycle.prototype.clamp = function(n, low, high)
{
	if (n < low)
		return low;
		
	if (n > high)
		return high;
		
	return n;
}


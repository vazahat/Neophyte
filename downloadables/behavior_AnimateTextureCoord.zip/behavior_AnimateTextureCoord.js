/*  
  <behavior jsname="behavior_AnimateTextureCoord" description="Animate Texture Coord">
    <property name="xSpeed" type="float" default="1"/>
    <property name="ySpeed" type="float" default="0"/>
  </behavior>
*/

behavior_AnimateTextureCoord = function(){ this.lastTime = 0; }

behavior_AnimateTextureCoord.prototype.onAnimate = function(node, Time){
	if(!this.node){
		this.node = node;
		this.bufferCount = ccbGetSceneNodeMeshBufferCount(node);
		this.vertexCount = ccbGetMeshBufferVertexCount(node, 0);

		// caching the coordinates will increase performance slightly
		this.cachedCoord = [];
		for(var i = 0; i < this.bufferCount; i++){
			this.cachedCoord[i] = [];
			for(var j = 0; j < this.vertexCount; j++){
				var textureCoord = ccbGetMeshBufferVertexTextureCoord(node, i, j);
				if(!textureCoord) continue;
				this.cachedCoord[i][j] = new vector3d(textureCoord.x, textureCoord.y, textureCoord.z);
			}
		}
	}

	// time
	this.deltaTime = Time - this.lastTime;
	this.lastTime = Time;

	for(var i = 0; i < this.cachedCoord.length; i++)
		for(var j = 0; j < this.cachedCoord[i].length; j++){
			var textureCoord = this.cachedCoord[i][j];
			textureCoord.x += this.xSpeed * this.deltaTime * 0.001;
			textureCoord.y += this.ySpeed * this.deltaTime * 0.001;
			ccbSetMeshBufferVertexTextureCoord(node, i, j, textureCoord);
		}
}
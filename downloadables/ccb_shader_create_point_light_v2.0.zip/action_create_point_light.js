/*	Info 
	
	Extension Name	: Action Create Point Light
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: July 11, 2021, 01:28 PM
	Description		: Convert any specified node into a point light with many lighting options. 
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	

*/
/*	Changelog

    [July 11, 2021]	- Added Basic Shader code with diffuse color
					- Added basic light with color
					- Added Diffuse lighting with color
					- Added ambient lighting with color
					- Added Specular lighting with color and specular texture
					- Added Specular Brightness (specular strength) to control specularity
	[July 12, 2021]	- Added Attenuation to control light strength
					- Converted the Shader into an action
					- Added different parameters (Actions property to control the shader)
					- Added Function to convert decimal color into RGB to fix color parameters of the action
    [July 13, 2021] - Added ability to turn ON and OFF Specular lighting
					- Added ability to either specify an external specular texture or to supply in irredit/irrlicht tools as a  second texture
					- Added option to auto use default texture as specular map if specular lighting is turned on an no texture is specified
					- Added option to affect specific material or to affect all materials of the affected node
					- Added option to choose a base material type for the Shader ( not all the material types worked for example normal map doesn't work)
					  Use material type id for base material type for example (12 for Tranparent_Add material type)
	[July 14, 2021] - Fixed a bug which was causing to shader to use properties from last action for all nodes if multiple actions were apllied with different
					  propertis. Previously global variables were used which was causing the issue, Now Fixed
					- Added missing code which to make the specularity works for all the materials not just with the first material.
					- Fixed some more bugs with Specular texture and with affecting all the material types
					- Added Material index to start with 1 instead of zero to remove confusion
	[December 17, 2021]  - Added support for normal mapping.
					  - Fixed some bugs that was causing the Normals maaping to appear on the opposite side of the object.
					  - Used a different approch to fix issues with normal maps.
	[January 06, 2022] 	 - Added support of upto 5 Point lights.
						 - Added individual color for multiple lights.
	[Februrary 09, 2022] - Fixed a bug that was causing light attenuation to be low, it needed to be multiplied by the amount of light("5")
						 - Fixed a bug caused by a typo in the code that was causing the light2 and light1 to show combined result
						 - Removed dependency or the feature of converting any node into a point light, now the shader uses actual point lights from the scene, and uses theor color attributes and position to affect the object.
						   let me know if you want to have the previous feature of converting any node into a point light to not be dependent on the default light.
						 - Fixed a major bug that was preventing specularity to not work correctly, it was a know issue and has been fixed.
	
					
						 
	    {Known Issues / TO DO's}		   - Specularity works for the last light accurately but not for other lights:-
							(Possible fix) - the above issue can be fixed but it will add more parameters to the actions, for example individual lights specularity strength, and specular color.
											 it would have been nice if these parameters could be added to the point light attributes.
											 I will see if I am going to add more parameters to the action to fix this issue.
							(Already FIxed)
						
							- One should manually assign which point lights need to be used by shader.
								(Possible fix) - the above issue can be fixed by either adding arrays to the shader that will hold the light data like(color,position,strenght, etc) of all the light nodes of a scene
												and then compare the vertex position of the object with the position array of light nodes to turn on or off a light effect for the node.
												My skills are not that advanced yet to do this.
												Another possible fix is to get all the light nodes in the scene outside the shader and check if they are in the radius of player and choose nearest 5 light nodes to the player
												to make light node on or off.
							
							- Realtime shadows will not work with this shader.
								(No Possible fix for now)
							
							- Shader don't work correctly if no Normal map is applied to the object in the 2nd texture slot.
								(Possible fix)	- The above issue is not that of a problem, and can be fixed by simply providing a plane normal map with no bumps to the second texture slot of the object
												in order to turn off the normal mapping for the object.
							
							- Every light has same light attenuation.
								(Possible Fix) - can be fixable by calculating color and intensity individually, I tried fixing it but there was something that I was missing
												and messed up the color of the light. I will try to fix it again.
	
	**This shader is planned to recieve updates in future**
					

	
*/



/* Usage
  Since the version 2.0, the shaders now supports upto 5 point lights with individual color, and specularity. The shader has been heavily updated
  there is no support for selecting any node as light, now light nodes to be an actual point light from the shader. It uses the color property and position of the light node.
  all other parameters can be adjusted from the shader itself except the light color.

  Attach this action to a behavior event and then specify an "Affecting_node" which will get affected by the light created using this shader. Specify additional light properties like light color, diffuse colo, ambient color,
  specular color and specular texture if specular lighting is turned on. Check if you want to affect all the materials of the "Affecting node" or you can uncheck it and can speicfy specific material index (for example zero "0" 
  if you want to affect first material of the node only). You can also specify a "Base_material_type" to blend the shader with other material type for exmaple (12 if you want to use Tranparent_Add as base material type). 
  Not all the materials blend with the shader, only a few can be blended with shaders.

  Fill in other parameters like "Light sources" you need to supplly point light in the light source scenenodes, then you can provide indvidual specular color for the light and specular strength for the lights.
  
  NOTE:- Debugging window of the game/app can throw an error failed to load a texture if Specular lighting is OFF (it is not a error or bug neither it affect
  the game) this is use to turn ON/OFF Specular lighting. You can ignore the error in debugging window.
  it will also throw an error if you use 1 or 2 lights instead of 5 lights, but you can ignore them they will not affect the game
*/

/*  <action jsname="action_create_point_light" description="Shader action to use point lights with normal map">
	  <property name="Affecting_node" type="scenenode"/>
	  <property name="Affect_all_material" type="bool" default="true" />
	  <property name="Affecting_material" type="int" default="1" />
	  <property name="Base_material_type" type="int" default="0" />
	  <property name="Light_strength" type="int" default="10" />
	  <property name="Diffuse_color" type="color"	default="ffFFFFFF"/>
	  <property name="Ambient_color" type="color" default="ff000000"/>
	  <property name="Specular_lighting" type="bool" default="true" />
	  <property name="Specular_Texture" type="string"/>
	  <property name="Light_source1" type="scenenode"/>
	  <property name="Light_source2" type="scenenode"/>
	  <property name="Light_source3" type="scenenode"/>
	  <property name="Light_source4" type="scenenode"/>
	  <property name="Light_source5" type="scenenode"/>	
	  <property name="Light1_Specular_color" type="color" default="ffFFFFFF"/>
	  <property name="Light2_Specular_color" type="color" default="ffFFFFFF"/>
	  <property name="Light3_Specular_color" type="color" default="ffFFFFFF"/>
	  <property name="Light4_Specular_color" type="color" default="ffFFFFFF"/>
	  <property name="Light5_Specular_color" type="color" default="ffFFFFFF"/>	 
	  <property name="Light1_Specular_strength" type="int" default="40"/>
	  <property name="Light2_Specular_strength" type="int" default="40"/>
	  <property name="Light3_Specular_strength" type="int" default="40"/>
	  <property name="Light4_Specular_strength" type="int" default="40"/>
	  <property name="Light5_Specular_strength" type="int" default="40"/>	   
    </action>
*/
action_create_point_light = function()
{

};

action_create_point_light.prototype.execute = function()
{	
	var Specular_Texture = "";
	this.Affecting_material -= 1;
	//Specular texture handler.
	var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);
	if (this.Specular_lighting)
	{
		if(this.Specular_Texture == null || this.Specular_Texture == "" ||this.Specular_Texture == undefined)
		{
			var NoSpecTex = ccbGetSceneNodeMaterialProperty(this.Affecting_node,this.Affecting_material,"Texture1");
			var defaultSpecTex = ccbGetSceneNodeMaterialProperty(this.Affecting_node,this.Affecting_material,"Texture3");
			if(defaultSpecTex == null || defaultSpecTex == "" || defaultSpecTex == undefined)
			{
				Specular_Texture = ccbLoadTexture(NoSpecTex);

			for(var i=0; i<matCount; ++i)	// to fix specularity with all materials.
			{
				if(this.Affect_all_material)
				{
					ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Texture3', Specular_Texture);
				}
				else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Texture3', Specular_Texture);}
			}
				
			}
			else{Specular_Texture = ccbLoadTexture(defaultSpecTex);}
			
		}
		else
		{
			Specular_Texture = ccbLoadTexture(this.Specular_Texture);
			for(var i=0; i<matCount; ++i)	// to fix specularity with all materials.
			{
				if(this.Affect_all_material)
				{
					ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Texture3', Specular_Texture);
				}
				else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Texture3', Specular_Texture);}
			}
		}
		
	}
	else 
	{
		for(var i=0; i<matCount; ++i)	// to fix specularity with all materials.
			{
				if(this.Affect_all_material)
				{
					ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Texture3', undefined);
				}
				else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Texture3', undefined);}
			}
	}
	
//Shader Part
var vertexShader = 
"		float4x4 mWorldViewProj;  // World * View * Projection 					\n" + 
"		float4x4 mTransWorld;     // Transposed world matrix					\n" +
"		float4x4 mInvWorld;       // Inverted world matrix	 					\n" + 
"		float3 lightPos ;														\n" +
"		float3 light2Pos ;														\n" +
"		float3 light3Pos ;														\n" +
"		float3 light4Pos ;														\n" +
"		float3 light5Pos ;														\n" +
"		float3 cameraPos ;														\n" +
"		// Output to fragment program V2F										\n" + 
"		struct VS_OUTPUT														\n" + 
"		{																		\n" + // only 9 texcoords can be used in DX9, that limits us to use 5 points lights at a time, but more lights can be used with multiple passes that can be resource heavy for the GPU.
"			float4 Position   : POSITION;   // vertex position 					\n" + 
"			float2 TexCoord   : TEXCOORD0;  // tex coords						\n" + 
"			float3 worldNormal  : TEXCOORD1;  // tex coords						\n" +
"			float3 worldBinormal  : TEXCOORD3;  // tex coords					\n" +
"			float3 worldTangent  : TEXCOORD2;  // tex coords					\n" +
"			float3 lightVec   : TEXCOORD4;   // vertex Diffuse color			\n" + 
"			float3 light2Vec   : TEXCOORD6;   // vertex Diffuse color			\n" + 
"			float3 light3Vec   : TEXCOORD7;   // vertex Diffuse color			\n" + 
"			float3 light4Vec   : TEXCOORD8;   // vertex Diffuse color			\n" + 
"			float3 light5Vec   : TEXCOORD9;   // vertex Diffuse color			\n" + 
"			float3 eyeVec   : TEXCOORD5;										\n" +
"		};																		\n" + 
"																				\n" + 
"			//Input From app to vertex program A2V								\n" + 
"		VS_OUTPUT main      ( in float4 vPosition : POSITION,					\n" +
"		                      in float3 vNormal   : NORMAL,						\n" +
"		                      in float3 vTangent   : TEXCOORD1,					\n" +
"		                      float2 texCoord     : TEXCOORD0 )					\n" +  
"		{																		\n" + 
"			//Vertex Shader														\n" + 
"			VS_OUTPUT Output;													\n" + 
"																				\n" + 
"			Output.Position = mul(vPosition, mWorldViewProj);					\n" + 
"			Output.worldNormal = mul(vNormal, mInvWorld);						\n" +
"			float3 vBinormal = cross(vNormal, vTangent); 						\n" + // *input.tangent.w; for debugging purpose from old Normal Mapping technique,instead or cross use mul;
"			Output.worldBinormal = mul(vBinormal, mInvWorld);					\n" +
"			Output.worldTangent = mul(vTangent, mInvWorld);						\n" +
"			float3 worldSpacePos = mul(mTransWorld, vPosition);					\n" + 
"			Output.lightVec = lightPos - worldSpacePos;							\n" +
"			Output.light2Vec = light2Pos - worldSpacePos;						\n" +
"			Output.light3Vec = light3Pos - worldSpacePos;						\n" +
"			Output.light4Vec = light4Pos - worldSpacePos;						\n" +
"			Output.light5Vec = light5Pos - worldSpacePos;						\n" +
"			Output.eyeVec = cameraPos - worldSpacePos;							\n" +	
"			Output.TexCoord = texCoord;											\n" + 
"			return Output;														\n" + 
"		}";

var fragmentShader = 
"		struct PS_OUTPUT																\n" + 
"		{																				\n" + 
"		    float4 RGBColor : COLOR; 		  											\n" +	
"		};																				\n" +
"																						\n" + 
"		float4 lightColor;																\n" +
"		float4 light2Color;																\n" +
"		float4 light3Color;																\n" +
"		float4 light4Color;																\n" +
"		float4 light5Color;																\n" +
"		float4 AmbientColor;															\n" +
"		float4 DiffuseColor;															\n" +
"		sampler2D tex0;																	\n" + 
"		sampler2D tex1;																	\n" +
"		sampler2D tex2;																	\n" + 
"		float4 SpecularColor;															\n" +
"		float4 SpecularColor2;															\n" +
"		float4 SpecularColor3;															\n" +
"		float4 SpecularColor4;															\n" +
"		float4 SpecularColor5;															\n" +
"		float4  SBrightness;															\n" +
"		float4  S2Brightness;															\n" +
"		float4  S3Brightness;															\n" +
"		float4  S4Brightness;															\n" +
"		float4  S5Brightness;															\n" +
"		float4  lightAttenuation;														\n" +
"																						\n" +
"		PS_OUTPUT main( float2 TexCoord : TEXCOORD0,									\n" +
"						float3 worldNormal  : TEXCOORD1,								\n" +
"						float3 worldBinormal  : TEXCOORD3,								\n" +
"						float3 worldTangent  : TEXCOORD2,								\n" +
"						float3 lightVec  : TEXCOORD4,									\n" +
"						float3 eyeVec  : TEXCOORD5,										\n" +
"						float3 light2Vec  : TEXCOORD6,									\n" +
"						float3 light3Vec  : TEXCOORD7,									\n" +
"						float3 light4Vec  : TEXCOORD8,									\n" +
"						float3 light5Vec  : TEXCOORD9,									\n" +
"		                float4 Position : POSITION)										\n" +
"		{ 																				\n" +
"			PS_OUTPUT Output;															\n" +
"		    float4 ColorTexture = tex2D(tex0, TexCoord);								\n" +
"		    float4 SpecularTexture = tex2D(tex2, TexCoord);								\n" +
"		    float3 NormalTexture = tex2D(tex1, TexCoord);								\n" +
"		    NormalTexture = normalize( NormalTexture * 2 - 1 );							\n" +
"			float3 M = worldNormal;														\n" +
"			float3 B = worldBinormal;													\n" +
"			float3 T = worldTangent;													\n" +
"			T = normalize(T - dot(T,M)*M);												\n" +
"			float3x3 TBM = float3x3( normalize(T), normalize(B), normalize(M) );		\n" +
"																						\n" +
"			float3 NewNormal = mul( NormalTexture, TBM ); 								\n" +
"			float3 N = NewNormal;														\n" +
"			float3 L = normalize(lightVec);												\n" +
"			float3 L2 = normalize(light2Vec);											\n" +
"			float3 L3 = normalize(light3Vec);											\n" +
"			float3 L4 = normalize(light4Vec);											\n" +
"			float3 L5 = normalize(light5Vec);											\n" +
"			float3 E = normalize(eyeVec);												\n" +
"			float3 HalfAngle = normalize((L) + E);			 							\n" +
"			float3 HalfAngle2 = normalize((L2) + E); 									\n" +
"			float3 HalfAngle3 = normalize((L3) + E); 									\n" +
"			float3 HalfAngle4 = normalize((L4) + E); 									\n" +
"			float3 HalfAngle5 = normalize((L5) + E); 									\n" +
"			float NdotH = saturate(dot(N,HalfAngle));									\n" +
"			float NdotH2 = saturate(dot(N,HalfAngle2));									\n" +
"			float NdotH3 = saturate(dot(N,HalfAngle3));									\n" +
"			float NdotH4 = saturate(dot(N,HalfAngle4));									\n" +
"			float NdotH5 = saturate(dot(N,HalfAngle5));									\n" +
"			float SB = SBrightness.x * SpecularTexture.a;								\n" +
"			float SB2 = S2Brightness.x * SpecularTexture.a;								\n" +
"			float SB3 = S3Brightness.x * SpecularTexture.a;								\n" +
"			float SB4 = S4Brightness.x * SpecularTexture.a;								\n" +
"			float SB5 = S5Brightness.x * SpecularTexture.a;								\n" +
"			float SPower = pow(NdotH, SB); 												\n" +
"			float SPower2 = pow(NdotH2, SB2); 												\n" +
"			float SPower3 = pow(NdotH3, SB3); 												\n" +
"			float SPower4 = pow(NdotH4, SB4); 												\n" +
"			float SPower5 = pow(NdotH5, SB5); 												\n" +
"			float4 Ambient = AmbientColor * ColorTexture; 								\n" +	
"			float4 diffuselight =   saturate(dot(N,L))   * lightColor  ; 				\n" +
"			float4 diffuselight2 =  saturate(dot(N,L2))  * light2Color ; 				\n" +
"			float4 diffuselight3 =  saturate(dot(N,L3))  * light3Color ; 				\n" +
"			float4 diffuselight4 =  saturate(dot(N,L4))  * light4Color ; 				\n" +
"			float4 diffuselight5 =  saturate(dot(N,L5))  * light5Color ; 				\n" +
"			float4 Specular = SPower * SpecularColor * SpecularTexture; 				\n" +
"			float4 Specular2 = SPower2 * SpecularColor2 * SpecularTexture; 				\n" +
"			float4 Specular3 = SPower3 * SpecularColor3 * SpecularTexture; 				\n" +
"			float4 Specular4 = SPower4 * SpecularColor4 * SpecularTexture; 				\n" +
"			float4 Specular5 = SPower5 * SpecularColor5 * SpecularTexture; 				\n" +
"			float4 Diffuse = DiffuseColor * ColorTexture * (diffuselight + diffuselight2 + diffuselight3 + diffuselight4 + diffuselight5 );\n" +	
"			float d = length(length(lightVec)+length(light2Vec)+length(light3Vec)+length(light4Vec)+length(light5Vec));\n" +	
"			float attenuation =  (1 / d) * (lightAttenuation.x) * 5; 					\n" +	
"			float4 light = (Diffuse + saturate(Specular + Specular2 + Specular3 + Specular4 + Specular5)) *  saturate(lightColor + light2Color + light3Color + light4Color + light5Color ) * attenuation ;\n" +
"			Output.RGBColor =   Ambient + light;										\n" + 
"			return Output;																\n" +
"		}";

var me = this; 
//Shader Callaback Function

myShaderCallBack = function()
{
	this.camPos = ccbGetSceneNodeProperty(ccbGetActiveCamera(),"Position");
	var light1pos = ccbGetSceneNodeProperty(me.Light_source1,"Position");
	var light2pos = ccbGetSceneNodeProperty(me.Light_source2,"Position");
	var light3pos = ccbGetSceneNodeProperty(me.Light_source3,"Position");
	var light4pos = ccbGetSceneNodeProperty(me.Light_source4,"Position");
	var light5pos = ccbGetSceneNodeProperty(me.Light_source5,"Position");
	var lightcolor = ccbGetSceneNodeProperty(me.Light_source1,"Color");
	var light2color = ccbGetSceneNodeProperty(me.Light_source2,"Color");
	var light3color = ccbGetSceneNodeProperty(me.Light_source3,"Color");
	var light4color = ccbGetSceneNodeProperty(me.Light_source4,"Color");
	var light5color = ccbGetSceneNodeProperty(me.Light_source5,"Color");
	var Diffusecolor = RGB(me.Diffuse_color);
	var Ambientcolor = RGB(me.Ambient_color);
	this.Specularcolor1 = RGB(me.Light1_Specular_color);
	this.Specularcolor2 = RGB(me.Light2_Specular_color);
	this.Specularcolor3 = RGB(me.Light3_Specular_color);
	this.Specularcolor4 = RGB(me.Light4_Specular_color);
	this.Specularcolor5 = RGB(me.Light5_Specular_color);
	this.SB1 = me.Light1_Specular_strength * 10;
	this.SB2 = me.Light2_Specular_strength * 10;
	this.SB3 = me.Light3_Specular_strength * 10;
	this.SB4 = me.Light4_Specular_strength * 10;
	this.SB5 = me.Light5_Specular_strength * 10;
	this.AB = me.Light_strength;
	ccbSetShaderConstant(1, 'cameraPos', this.camPos.x,this.camPos.y,this.camPos.z,1);
	//passing light pos
	ccbSetShaderConstant(1, 'lightPos', light1pos.x,light1pos.y,light1pos.z,1);
	ccbSetShaderConstant(1, 'light2Pos', light2pos.x,light2pos.y,light2pos.z,1);
	ccbSetShaderConstant(1, 'light3Pos', light3pos.x,light3pos.y,light3pos.z,1);
	ccbSetShaderConstant(1, 'light4Pos', light4pos.x,light4pos.y,light4pos.z,1);
	ccbSetShaderConstant(1, 'light5Pos', light5pos.x,light5pos.y,light5pos.z,1);
	//passing light color
	ccbSetShaderConstant(2, 'lightColor',  lightcolor.x,lightcolor.y,lightcolor.z,1);
	ccbSetShaderConstant(2, 'light2Color', light2color.x,light2color.y,light2color.z,1);
	ccbSetShaderConstant(2, 'light3Color', light3color.x,light3color.y,light3color.z,1);
	ccbSetShaderConstant(2, 'light4Color', light4color.x,light4color.y,light4color.z,1);
	ccbSetShaderConstant(2, 'light5Color', light5color.x,light5color.y,light5color.z,1);
	//passing other values
	ccbSetShaderConstant(2, 'lightAttenuation', this.AB,1,1,1);
	ccbSetShaderConstant(2, 'AmbientColor', Ambientcolor.x,Ambientcolor.y,Ambientcolor.z,1);
	ccbSetShaderConstant(2, 'DiffuseColor', Diffusecolor.x,Diffusecolor.y,Diffusecolor.z,1);
	ccbSetShaderConstant(2, 'SpecularColor', this.Specularcolor1.x,this.Specularcolor1.y,this.Specularcolor1.z,1);
	ccbSetShaderConstant(2, 'SpecularColor2', this.Specularcolor2.x,this.Specularcolor2.y,this.Specularcolor2.z,1);
	ccbSetShaderConstant(2, 'SpecularColor3', this.Specularcolor3.x,this.Specularcolor3.y,this.Specularcolor3.z,1);
	ccbSetShaderConstant(2, 'SpecularColor4', this.Specularcolor4.x,this.Specularcolor4.y,this.Specularcolor4.z,1);
	ccbSetShaderConstant(2, 'SpecularColor5', this.Specularcolor5.x,this.Specularcolor5.y,this.Specularcolor5.z,1);
	ccbSetShaderConstant(2, 'SBrightness', this.SB1,1,1,1);
	ccbSetShaderConstant(2, 'S2Brightness', this.SB2,1,1,1);
	ccbSetShaderConstant(2, 'S3Brightness', this.SB3,1,1,1);
	ccbSetShaderConstant(2, 'S4Brightness', this.SB4,1,1,1);
	ccbSetShaderConstant(2, 'S5Brightness', this.SB5,1,1,1);

		
}
// creating Material
var newMaterial = ccbCreateMaterial(vertexShader, fragmentShader, this.Base_material_type, myShaderCallBack);

//Check Material index and apply to sepcifed mat index or to all the materials.
var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

for(var i= 0; i<matCount; ++i)
{
	if(this.Affect_all_material)
	{
		ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial);
		ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Param1', this.Param1);
	}
	else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial);ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Param1', this.Param1);}
}

}
// Fixing the Color Property type Parameter of action to get RGB value and clamp them between 0 and 1.
function RGB(decimalcolorcode)
{var color = (decimalcolorcode); // use the property type or put a  decimal color value.
 var Rr = (color & 0xff0000) >> 16; // get red color by bitwise operation  
 var Gg = (color & 0x00ff00) >> 8; // get green color by bitwise operation 
 var Bb = (color & 0x0000ff); // get blue color by bitwise operation 
 var RrGgBb = new vector3d(Rr,Gg,Bb);
 var r = (Rr/255); // dividing red by 255 to clamp b/w 0-1 
 var g = (Gg/255); // dividing green by 255 to clamp b/w 0-1 
 var b = (Bb/255); // dividing blue by 255 to clamp b/w 0-1 
 var rgb = new vector3d (r,g,b); // final rgb value to use in the editor
 return rgb;
 }
 
 
 /*End Of Code*/
 
// Above extension is written by Vazahat Khan (just_in_case) //
 
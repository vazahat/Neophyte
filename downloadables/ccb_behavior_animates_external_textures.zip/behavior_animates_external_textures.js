/*	Info 
	
	Extension Name	: Animates External textures
	Extension Type	: Behavior
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: February 08, 2022, 09:01 AM
	Description		: Allows you to animate textures loaded from an external directory. 
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	

*/
/*	Changelog

    [February 08, 2022]	- Fixed some bugs and added more functionality to my already created behavior from one of my project.
	
*/



/* Usage
  	Attach this behavior to any node and fill in the parameters, select the affecitng node, and affecting material, choose if you want to play animation on all the material or to specific one.
	Provide the name of the directory or complete adress to the directory that holds the textures(frames), Provide the name of the texture (frame). Provide the total number of frames you want to
	use for the animation. Provide the time to change each frame ( this is the parameter which decides the speed of the animation),  Choose if you want the animation to played once or to loop.
	Check if you want to load all the textures initially into the memory and animates them only after being loaded completely. Provide an action to execute once all the textures gets loaded into memory.
	Provide action to execute if the animation cycle gets completed, as soon as 1 cycle of the animation gets played it will execute the action assigned to it.
	
-	Note:- All the frames(textures) should use same name with an increment of number like "frame1.png","frame2.png" and so on.
		   It is advised to use no-looping when you are executing an action on finish otherwise it will execute the action each time the animation cycle gets completed.
  
	Itch.io - https://vazahat.itch.io/cc-shader-spritesheet-animation
	Youtube - https://www.youtube.com/channel/UC_yfoGEKkmY63tnyy6hR7ZQ
	Website - https://neophyte.cf
	Discord - https://discord.gg/RKcq89S7uA
  
*/
/*
  <behavior jsname="behavior_animates_external_textures" description="Animates external textures">
	  <property name="Affecting_node" type="scenenode" />
	  <property name="Affect_all_material" type="bool" default="true" />
	  <property name="Affecting_material" type="int" default="1" />
      <property name="Directory" type="string" default="background" />
      <property name="Texture_Name" type="string" default="frame" />
      <property name="Number_of_Frames" type="int" default="100" />
	  <property name="Time_per_Frame" type="int" default="1" />
	  <property name="Looping" type="bool" default="true" />
	  <property name="Allow_loading" type="bool" default="false" />
	  <property name="ActionOnLoad" type="action"  />
	  <property name="ActionOnFinish" type="action"  />
  </behavior>
*/

behavior_animates_external_textures = function()
{
	
	this.CurrentFrame = 1;
	this.frameloaded = 1;
	this.timer = 1;
};

behavior_animates_external_textures.prototype.onAnimate = function()
{ 
	if(this.Allow_loading) // checks if we have to load the textures into memory first 
	{
		ccbLoadTexture(this.Directory + "\\" + this.Texture_Name + this.frameloaded + ".png");//loads the texture into memory
		if(!this.frameloaded){this.frameloaded = false} // to prevent a from a bug
		else{this.frameloaded += 1;} //increment to load the next frame into memory
		if (this.frameloaded > this.Number_of_Frames) // check if all the frames are loaded then allow the execution
		{
			this.execute  = true;
			this.frameloaded = false;
		}
		
		if(this.execute) // once execution is allowed then execute the supplied action and start the animation.
		{
		ccbInvokeAction(this.ActionOnLoad);
		this.execute = false;
		this.start = true;
		}
	}
	else		//start animation without laoding any texture initially into memory, animate them along with the loading
	{this.start = true;}
	
	if(this.start){ // animation of the frames goes in this section
	if (this.timer > this.Time_per_Frame) // check if the time per frame is small than the timer
	{
		this.timer = 1; // reset the timer to 1
		this.tex = ccbLoadTexture(this.Directory + "\\" + this.Texture_Name + this.CurrentFrame + ".png"); //load textures it will have no effect if they are already loaded into memory
		
		var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node); //Get the total number of materials of the node
		for(var i=0; i<matCount; ++i)
		{
			if(this.Affect_all_material)
			{
			ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, "Texture1", this.tex);  // setting the texture for all the material of the node
			}
			else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material-1, "Texture1", this.tex);} // setting the texture for specific material of the node
		}
		this.CurrentFrame += 1; // increment of the current frame to load the next frame.
		if (this.CurrentFrame > this.Number_of_Frames){ //checks the animation cycle if one animation cycle is completed then restart it from begining or do the necessary execution
			this.CurrentFrame = 1; //reset the animation to play from first frame
			ccbInvokeAction(this.ActionOnFinish);  //execute an action on 1 complete animation cycle
			//stop the animation from repeating itself if it has to played once only
			if(!this.Looping)
			{
				behavior_animates_external_textures.prototype.onAnimate = function()
				{	this.tex = ccbLoadTexture(this.Directory + "\\" + this.Texture_Name + this.Number_of_Frames + ".png"); // loading the last frame
					for(var i=0; i<matCount; ++i)
					{
						if(this.Affect_all_material)
						{
							ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, "Texture1", this.tex);  // setting the texture for all the material of the node
						}
						else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material-1, "Texture1", this.tex);} // setting the texture for specific material of the node
					}
				}
			}
			
		}

	}
	this.timer += 1;// increment of the timer everytime the code gets executed
	}
}

 /*End Of Code*/
 
 
// Above extension is written by Vazahat Khan (just_in_case) //
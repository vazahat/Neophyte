/*
  <behavior jsname="behavior_CameraZoomByMouseWheel" description="Zoom camera by mouse wheel">
      <property name="MinZoom" type="float" default="20.0" />
      <property name="MaxZoom" type="float" default="100.0" />
	  <property name="ZoomSpeed" type="float" default="1.6" />
  </behavior>
*/

behavior_CameraZoomByMouseWheel = function()
{
	this.targetZoomValue = 90;
	this.LastTime = null;
};

// called every frame. 
//   'node' is the scene node where this behavior is attached to.
//   'timeMs' the current time in milliseconds of the scene.
// Returns 'true' if something changed, and 'false' if not.
behavior_CameraZoomByMouseWheel.prototype.onAnimate = function(node, timeMs)
{
	// get the time since the last frame

	if (this.LastTime == null)
	{
		this.LastTime = timeMs; 
		return false;
	}

	var delta = timeMs - this.LastTime;
	this.LastTime = timeMs;
	if (delta > 200) delta = 200; // never do movements longer than 200 ms
  
	var cam = ccbGetActiveCamera();	
	var newFov = ccbGetSceneNodeProperty(cam, 'FieldOfView_Degrees');
				
	if (this.targetZoomValue < this.MinZoom)
		this.targetZoomValue = this.MinZoom;
	if (this.targetZoomValue > this.MaxZoom)
		this.targetZoomValue = this.MaxZoom;
			
	var localZoomSpeed = this.ZoomSpeed;				
	localZoomSpeed = Math.abs(this.targetZoomValue - newFov) / 8.0;
	if (localZoomSpeed  < this.ZoomSpeed)
		localZoomSpeed = this.ZoomSpeed;
									
	if (newFov < this.MaxZoom-localZoomSpeed && newFov < this.targetZoomValue)
	{
		newFov += localZoomSpeed;
		if (newFov > this.MaxZoom)
			newFov = this.MaxZoom;
	}
	
	if (newFov > this.MinZoom+localZoomSpeed && newFov > this.targetZoomValue)
	{
		newFov -= localZoomSpeed;
		if (newFov < this.MinZoom)
			newFov = this.MaxZoom;
	}	

	ccbSetSceneNodeProperty(cam, 'FieldOfView_Degrees', newFov);
}


// mouseEvent: 0=mouse moved, 1=mouse wheel moved, 2=left mouse up,
//     3=left mouse down, 4=right mouse up, 5=right mouse down
behavior_CameraZoomByMouseWheel.prototype.onMouseEvent = function(mouseEvent, mouseWheelDelta)
{
  if (mouseEvent == 1)
  {
	// mouse wheel
	this.targetZoomValue += mouseWheelDelta * this.ZoomSpeed;
			 
	 if (this.targetZoomValue < this.MinZoom)
		this.targetZoomValue = this.MinZoom;
		
	 if (this.targetZoomValue > this.MaxZoom)
		this.targetZoomValue = this.MaxZoom;
  }
}

/*
getOptimalLightmapSettings.js v2.0 - author BMSKiwi
v1.0 21.06.13 - Initial write.
v1.1 21.06.13 - Prevented function from iterating over meshbuffers with dynamic lighting. Tidied code and variable names.
v1.2 22.06.13 - Improved function to skip entire nodes with dynamic lighting rather than individual buffers.
v1.3 22.06.13 - Added handler for scenes with no mesh nodes that can receive lightmaps or meshes too large for CopperCube to lightmap.
                Increased accuracy of axis length multipliers to 6 decimal points. Improved results message.
                Changed shortcut key from to 'Ctrl+Q' from 'Ctrl+A' to avoid conflict with 'select all' shortcut. 
v1.4 26.06.13 - Results are now written to console. Shortcut key changed to 'Ctrl+E'. Improved function sequence and results message.
v1.5 27.06.13 - Created additional property with version information. Changed function sequence for readability.
v2.0 03.04.14 - Strict mode, code optimisations and full JSLint conformance.
*/

function getOptimalLightmapSettings() {
    'use strict';
    var dialogue,
        longestAxisLength = 0,
        resList,
        resultSummary,
        rootSceneNode = ccbGetRootSceneNode();
    dialogue = {
        getResultSummary: function () {
            return 'Analysis complete. The optimal lightmap settings for your scene are:\n\n' +
                'Texture Size 64x64: ' + resList.tx64 + '\n\n' +
                'Texture Size 128x128: ' + resList.tx128 + '\n\n' +
                'Texture Size 256x256: ' + resList.tx256 + '\n\n' +
                'Texture Size 512x512: ' + resList.tx512 + '\n\n' +
                'Texture Size 1024x1024: ' + resList.tx1024;
        },
        noLightmapNodes:
            'Analysis complete. There are no mesh nodes in this scene that are able to receive static lightmaps.',
        polygonsTooLarge:
            'Scene contains polygons too large for this texture'
    };
    function getRes(multiplier) {
        var r,
            res;
        r = Math.ceil(longestAxisLength * multiplier);
        res = r < 1000000 ? 'Resolution ' + r : dialogue.polygonsTooLarge;
        return res;
    }
    function getResList() {
        var rl = {};
        rl.tx64 = getRes(1.057852);
        rl.tx128 = getRes(1.028113);
        rl.tx256 = getRes(1.013862);
        rl.tx512 = getRes(1.006883);
        rl.tx1024 = getRes(1.003430);
        return rl;
    }
    function checkAxisLength(value1, value2, value3) {
        var axisLength,
            maxValue,
            minValue;
        maxValue = Math.max(value1, value2, value3);
        minValue = Math.min(value1, value2, value3);
        axisLength = maxValue - minValue;
        if (longestAxisLength < axisLength) {
            longestAxisLength = axisLength;
        }
    }
    function getBoundingBox(sceneNode, meshBuffer, vertex1, vertex2, vertex3) {
        var pos1,
            pos2,
            pos3;
        pos1 = ccbGetMeshBufferVertexPosition(sceneNode, meshBuffer, vertex1);
        pos2 = ccbGetMeshBufferVertexPosition(sceneNode, meshBuffer, vertex2);
        pos3 = ccbGetMeshBufferVertexPosition(sceneNode, meshBuffer, vertex3);
        checkAxisLength(pos1.x, pos2.x, pos3.x);
        checkAxisLength(pos1.y, pos2.y, pos3.y);
        checkAxisLength(pos1.z, pos2.z, pos3.z);
    }
    function processIndices(sceneNode, meshBuffer) {
        var i,
            indexCount,
            vertex1,
            vertex2,
            vertex3;
        indexCount = ccbGetMeshBufferIndexCount(sceneNode, meshBuffer);
        for (i = 0; i < indexCount; i += 3) {
            vertex1 = ccbGetMeshBufferIndexValue(sceneNode, meshBuffer, i);
            vertex2 = ccbGetMeshBufferIndexValue(sceneNode, meshBuffer, i + 1);
            vertex3 = ccbGetMeshBufferIndexValue(sceneNode, meshBuffer, i + 2);
            getBoundingBox(sceneNode, meshBuffer, vertex1, vertex2, vertex3);
        }
    }
    function processMeshBuffers(sceneNode) {
        var b,
            bufferCount;
        bufferCount = ccbGetSceneNodeMeshBufferCount(sceneNode);
        for (b = 0; b < bufferCount; ++b) {
            processIndices(sceneNode, b);
        }
    }
    function processSceneNode(sceneNode) {
        var c,
            childCount,
            childSceneNode;
        if (ccbGetSceneNodeMeshBufferCount(sceneNode) > 0 && !ccbGetSceneNodeMaterialProperty(sceneNode, 0, 'Lighting')) {
            processMeshBuffers(sceneNode);
        }
        childCount = ccbGetSceneNodeChildCount(sceneNode);
        for (c = 0; c < childCount; ++c) {
            childSceneNode = ccbGetChildSceneNode(sceneNode, c);
            processSceneNode(childSceneNode);
        }
    }
    print(getOptimalLightmapSettings.description);
    processSceneNode(rootSceneNode);
    if (longestAxisLength) {
        resList = getResList();
        resultSummary = dialogue.getResultSummary();
    } else {
        resultSummary = dialogue.noLightmapNodes;
    }
    print(resultSummary);
    alert(resultSummary);
}
getOptimalLightmapSettings.displayName = 'getOptimalLightmapSettings.js';
getOptimalLightmapSettings.version = 2.0;
getOptimalLightmapSettings.author = 'BMSKiwi';
getOptimalLightmapSettings.description = getOptimalLightmapSettings.displayName +
    ' v' + getOptimalLightmapSettings.version + ' - author ' + getOptimalLightmapSettings.author;
editorRegisterMenuEntry('getOptimalLightmapSettings()', 'Get Optimal Lightmap Settings\tCtrl+E');
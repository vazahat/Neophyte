/*	Info 
	
	Extension Name	: Action Change Attributes
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: ‎‎July ‎31, ‎2021, 10:28 AM
	Description		: Change general and material properties (attributes) of a node 
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	

*/
/*	Changelog

    [July 11, ‎2021]	- Added ability to change properties of a node
					- Added ability to change property of rootnode
					- Added ability to change material properties
					- Added ability to change all materials at once or change a specific material
					- Added parameters and properties to change in action

					

	
*/



/* Usage
  
  Attach this action to a behavior event and then specify which node you want to change, you can opt between roo node or a scenenode
  the you can specify wether you want to change the material property or not, if yes then can specify other material related options
  like change all materials to change attributes for all the materials of a scenenode or specify a specific material to change.
  then Specify the name of the Property you want to change, and provide new valur for that property.
 
*/

/*  
  <action jsname="action_change_attributes" description="Change general and material properties (attributes) of a node">
     <property name="RootNode" type="bool" default="false"/>
	 <property name="SceneNode" type="scenenode" default="1.0"/>
	 <property name="Material_Property" type="bool" default="false"/>
	 <property name="Change_All_Material" type="bool" default="true"/>
	 <property name="Specific_Material" type="int" default="1.0"/>
	 <property name="Change_Which_Attribute" type="string" default="Position"/>
	 <property name="New_Attribute_Value" type="string" default="1.0,1.0,1.0"/>
	 
  </action>
*/

// Constructor
action_change_attributes = function(){

}

// Runs this code every time the action is being executed
action_change_attributes.prototype.execute = function (node){
	
	this.Specific_Material -= 1;
	
	if(this.RootNode){var node = ccbGetRootSceneNode();}
	else {node = this.SceneNode;}
	
	if(this.Material_Property)
	{
		var matCount = ccbGetSceneNodeMaterialCount(this.SceneNode);
		
		for(var i=0; i<matCount; ++i)
		{
			if(this.Change_All_Material)
			{
				ccbSetSceneNodeMaterialProperty(this.SceneNode, i, this.Change_Which_Attribute,this.New_Attribute_Value);
			}
			else {ccbSetSceneNodeMaterialProperty(this.SceneNode, this.Specific_Material, this.Change_Which_Attribute, this.New_Attribute_Value);}
		}
	}
	else
	{
		ccbSetSceneNodeProperty(node,this.Change_Which_Attribute,this.New_Attribute_Value);
	}

}

/*	Info 
	
	Extension Name	: Action Animate texture Coordinates. 
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: February 06, 2022, 01:28 PM
	Description		: Animate the texture coordinates of a material of 3D object. 
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	Discord Server :- https://discord.gg/RKcq89S7uA
	YouTube :- https://www.youtube.com/GlitchedVelocity
	Itch.io :- https://vazahat.itch.io/
	

*/
/*	Changelog

    [February 06, 2022]	- Splitted and created Individual shader from one of my project. 
    [June 14, 2022]	- Added Support for webGL. 
    [July 12, 2022]	- Added Support for fog ( windows platform only). 
					
*/


/* Usage
  Attach this action to any behavior and fill the parameters of the action, supply the X and Y speed to animate the texture coordinates.

  	PayPal: http://paypal.me/Vazahat
	Discord Server :- https://discord.gg/RKcq89S7uA
	YouTube :- https://www.youtube.com/GlitchedVelocity
	Itch.io :- https://vazahat.itch.io/
    Website - https://neophyte.cf
  

  */

/*  <action jsname="action_animate_texcoords" description="Shader to animate texture cordinates">
	  <property name="Affecting_node" type="scenenode"/>
	  <property name="Affect_all_material" type="bool" default="true" />
	  <property name="Affecting_material" type="int" default="1" />
	  <property name="Base_material_type" type="int" default="0" />
	  <property name="speedX" type="int" default="0.0" />
	  <property name="speedY" type="int" default="10" />
	  <property name="Fog_Enabled" type="bool" default="true" />

    </action>
*/
action_animate_texcoords = function()
{

};

action_animate_texcoords.prototype.execute = function()
{	var platform = ccbGetPlatform();
	this.Affecting_material -= 1;
	if(platform == "windows"  || platform ==  "macosx")
{
//Shader Part
var vertexShader = 
"		float4x4 mWorldViewProj;  // World * View * Projection 					\n" + 
"		float4x4 mTransWorld;     // Transposed world matrix					\n" +
"		float4x4 mInvWorld;       // Inverted world matrix	 					\n" + 
"		float3 time ;															\n" +  
"		float mFogDensity ;														\n" + 
"		float fogEnable ;														\n" + 
"		// Output to fragment program V2F										\n" + 
"		struct VS_OUTPUT														\n" + 
"		{																		\n" + 
"			float4 Position   : POSITION;   // vertex position 					\n" + 
"			float2 TexCoord   : TEXCOORD0;  // tex coords						\n" + 
"			float Fog	: FOG;													\n" +
"		};																		\n" + 
"																				\n" + 
"			//Input From app to vertex program A2V								\n" + 
"		VS_OUTPUT main      ( in float4 vPosition : POSITION,					\n" +
"		                      in float3 vNormal   : NORMAL,						\n" +
"		                      float2 texCoord     : TEXCOORD0 )					\n" +  
"		{																		\n" + 
"			//Vertex Shader														\n" + 
"			VS_OUTPUT Output;													\n" + 
"																				\n" + 
"			Output.Position = mul(vPosition, mWorldViewProj);					\n" + 
"			texCoord = float2(texCoord.x + time.x * 0.001, texCoord.y + time.y * 0.001);\n" +
"			Output.TexCoord = texCoord;											\n" + 
"			if (fogEnable == 1)											    	\n" + 
"   		{ 																	\n" + 
"     			Output.Fog = saturate(1.0 / exp(Output.Position.z * mFogDensity));	\n" + 
"  			}																	\n" + 
"  			else																\n" + 
"  			 {     																\n" + 
"     			Output.Fog = 1;													\n" + 
"   		 }  																\n" + 
"			return Output;														\n" + 
"		}";

var fragmentShader = 
"		struct PS_OUTPUT																\n" + 
"		{																				\n" + 
"		    float4 RGBColor : COLOR; 		  											\n" +	
"		};																				\n" +
"																						\n" + 
"		sampler2D tex0;																	\n" + 
"		float4 FogColor;																\n" +
"																						\n" +
"		PS_OUTPUT main( float2 TexCoord : TEXCOORD0,									\n" +
"						float Fog    : FOG,												\n" +
"		                float4 Position : POSITION)										\n" +
"		{ 																				\n" +
"			PS_OUTPUT Output;															\n" +
"		    float4 ColorTexture = tex2D(tex0, TexCoord);								\n" +
"			float4 fogcol = FogColor*(1-Fog);											\n"	+
"			Output.RGBColor =  float4(ColorTexture.rgb*Fog+fogcol.rgb,ColorTexture.a);	\n" + 
"			return Output;																\n" +
"		}";

}
// Shaders For WEBGL platforms::::::::
if(platform == "webgl")
{
var vertexShader = 									
"uniform mat4 worldviewproj;								\n" +
"															\n" +
"attribute vec4 vPosition;									\n" +
"attribute vec4 vNormal;									\n" +
"attribute vec4 vColor;										\n" +
"attribute vec2 vTexCoord1;									\n" +
"attribute vec2 vTexCoord2;									\n" +
"															\n" +
"varying vec4 v_color;										\n" +
"varying vec2 v_texCoord1;									\n" +
"varying vec2 v_texCoord2;									\n" +
"															\n" +
"void main()												\n" +
"{															\n" +
"	v_color = vColor;										\n" +
"	gl_Position = worldviewproj * vPosition;				\n" +
"	v_texCoord1 = vTexCoord1.st;							\n" +
"	v_texCoord2 = vTexCoord2.st;							\n" +
"}															";

var fragmentShader = 
"uniform sampler2D texture1;								\n" +
"uniform sampler2D texture2;								\n" +
"uniform vec4 time;										\n" +
"															\n" +
"varying vec2 v_texCoord1;									\n" +
"varying vec2 v_texCoord2;									\n" +
"															\n" +
"void main()												\n" +
"{															\n" +
"	vec2 texCoord = vec2(v_texCoord1.s + time.x * 0.001 , v_texCoord1.t + time.y * 0.001);		\n" +
"	gl_FragColor = texture2D(texture1, texCoord);			\n" +
"}															\n";
}

var me = this;  
//Shader Callaback Function
var speedX = 0;
var speedY = 0;
myShaderCallBack = function()
{
	var GlobalfogEnable = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"Fog");
	var fogEnable = me.Fog_Enabled;
	if(fogEnable && GlobalfogEnable){var fogenable = 1;var fogDensity = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogDensity");
	var fogColor = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogColor");}
	else{ var fogenable = 0; var fogColor = new vector3d(1,1,1)};
	speedX += me.speedX;
	speedY += me.speedY;
	if(platform == "webgl"){ccbSetShaderConstant(2, 'time', speedX,speedY,0,0);}
	else if(platform == "windows"  || platform ==  "macosx"){
	ccbSetShaderConstant(1, 'time', speedX,speedY,0,0);
	ccbSetShaderConstant(2, 'FogColor', fogColor.x,fogColor.y,fogColor.z,1);
	ccbSetShaderConstant(1, 'mFogDensity', fogDensity,0,0,0);
	ccbSetShaderConstant(1, 'fogEnable', fogenable,0,0,0);}
	
}

// creating Material
var newMaterial = ccbCreateMaterial(vertexShader, fragmentShader, this.Base_material_type, myShaderCallBack);

//Check Material index and apply to sepcifed mat index or to all the materials.
var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

for(var i = 0; i<matCount; ++i)
{
	if(this.Affect_all_material)
	{
		ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial);
		ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Param1', this.Param1);
	}
	else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial);ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Param1', this.Param1);}
}

}
  
 /*End Of Code*/
 
// ***Author:- VAZAHAT PATHAN***

//        ****AKA****

 //   ****Just_in_case**** 

 // Above extension is written by Vazahat Khan (just_in_case) //
//You are not allowed to remove this License info or any attribution details//
//License info:-//
/* All rights are reserved to Vazahat Khan.
You are allowed to use this asset( code ) in your coppercube projects freely for commercial and personal use without removing the attribtution comments from the code*/

 
// This is a scripted coppercube action. It makes the device vibrates using a vibration pattern for mulitple vibration...
// Can  also trigger single vibration, Curently works for WebGL apps only. 

// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*  <action jsname="action_Webgl_Vibrate" description="Make Device Vibrate WebGL">
	  <property name="Pattern" type="string" default="100" />
	
    </action>
*/
action_Webgl_Vibrate = function()
{
};

action_Webgl_Vibrate.prototype.execute = function(currentNode)
{	
	var patternArray = this.Pattern;

	var Pattern = patternArray.split(',').map(function(item) {
		return parseInt(item, 10);
	});

	function vibrate() {
    if (!window) {
        return;
    }

    if (!window.navigator) {
        return;
    }

    if (!window.navigator.vibrate) {
        return;
    }

    window.navigator.vibrate(Pattern);
}
	window.navigator.vibrate(Pattern);
}

// ***Author:- VAZAHAT PATHAN***

//        ****AKA****

 //   ****Just_in_case**** 
















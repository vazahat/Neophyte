// 'drop to ground' plugin by Robert Codell

function dropToGround()
{
	var s = editorGetSelectedSceneNode();
	var type = ccbGetSceneNodeProperty(s, "Type");
	if (type.indexOf("mesh") != -1)
{
	
	var pos = ccbGetSceneNodeProperty(s, "Position");
	for (i=0; i<501; i++)
	{
	var adj = i/10;
	if (ccbDoesLineCollideWithBoundingBoxOfSceneNode(s, pos.x, pos.y-100, pos.z, pos.x, pos.y-50+adj, pos.z))
		{
	var dist = 50-adj;
	i = 500;
		}
	}
	var gnd = ccbGetCollisionPointOfWorldWithLine(pos.x, pos.y, pos.z, pos.x, pos.y-500, pos.z);
	if (gnd != null && dist != undefined) 
	{
	ccbSetSceneNodeProperty(s,"Position",gnd.x, gnd.y+dist, gnd.z);
	editorUpdateAllWindows();
	} else if (dist != undefined)
		{
		alert("ground not found");
		}
		else
		{
		alert("try moving it slightly - won't work for child nodes");
		}
} else
	{
	alert("must be 3d mesh");
	}
}

editorRegisterMenuEntry("dropToGround()", "Drop to Ground\tCtrl+D");

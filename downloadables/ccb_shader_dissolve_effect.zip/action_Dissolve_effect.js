/*	Info 
	
    Extension Name	: Action Dots effect
    Extension Type	: Action
    Author:			: Vazahat Khan (just_in_case)
    Date Created	: December 25, 2021, 11:24 PM
    Description		: Apply dots (circles) effects to a texture with transparency. 
	
*/
/* 	Donate
	
    If you like my work, please consider "buy me a cup of coffee" to support me.
    You can do that via PayPal :)
	
    PayPal: http://paypal.me/Vazahat
	Discord Server :- https://discord.gg/RKcq89S7uA
	YouTube :- https://www.youtube.com/GlitchedVelocity
	Itch.io :- https://vazahat.itch.io/
    Website - https://neophyte.cf
	

*/
/*	Changelog

    [December 25, 2021]	- Added Basic Shader code
                        - Added Shader Constants to use in shaders (strength) to animate the shader
                        - Clipping texture according to alpha mask
                        - Wasted hours and hours to make the edge color effect
                        - After wasting so many hours finally maths work and  the edge color works pefectly.
                        - A goodnight sleep
    [December 26, 2021] - Added other shader constants like edge radius and edge color
                        - Added  my color conversion function to use the color property
                        - Added properties to the shader action
                        - Ability to execute action on the finish of shader animation
                        - Ability to reverse the animation (Dissolve In the object)
                        - Fixed Issues with Dissolving In effects
                        - Cached the shader to prevent it from executing again and to allow execution with multiple objects  

    [July 12, 2022]     - Added Fog support

*/



/* Usage
  Attach this action to a behavior and fill the parameters, Select the Affecting_node (the node on you want to get affected by this shader), Set the base_material_type
  Then fill all other properties like "Dissolve_In" if you want Dissolve-in check this true, for Dissolve-out effect mark this property false. Supply the Animation_speed,
  Edge Color and Edge Width. You can also supply an action that will get executed when the animation gets Completed. Then Supply a second texture as an Alpha map for the
  shader to use with the  help of "Irredit/Irrlicht" tools. If you  want to enable the Dissolve in effect then don't forget to supply a third texture as well, that will be
  then used as main texture once the Disolution gets started. For more usage instruction visit my Youtube Channel and watch the video there.
  
  
  
    Itch.io - https://vazahat.itch.io/cc-shader-spritesheet-animation
    Youtube - https://www.youtube.com/channel/UC_yfoGEKkmY63tnyy6hR7ZQ
    Website - https://neophyte.cf
    Discord - https://discord.gg/RKcq89S7uA
  
*/

/*  <action jsname="action_Dissolve_effect" description="Dissolve shader">
      <property name="Affecting_node" type="scenenode"/>
      <property name="Affect_all_material" type="bool" default="true" />
      <property name="Affecting_material" type="int" default="1" />
      <property name="Base_material_type" type="int" default="13" />
      <property name="Dissolve_In" type="bool" default="false" />
      <property name="Animation_Speed" type="float" default="1" />
      <property name="Edge_Color" type="color" default="ffFFFFFF" />
      <property name="Edge_Width" type="float" default="0.1" />
      <property name="Action_On_Complete" type="action"  />
	  <property name="Fog_Enabled" type="bool" default="true" />

    </action>
*/


if (!DissolvedCache)
    var DissolvedCache = {};

action_Dissolve_effect = function () { };

action_Dissolve_effect.prototype.execute = function () {
   
    this.Affecting_material -= 1;
    this.nodeName = ccbGetSceneNodeProperty(this.Affecting_node, "Name");

    // Caching the shader to be used by multiple objects simultaneously
    if(!DissolvedCache[this.nodeName]) DissolvedCache[this.nodeName] = {Animation_Speed: false, Dissolve_In: false};
    if (this.Animation_Speed == DissolvedCache[this.nodeName].Animation_Speed && this.Dissolve_In == DissolvedCache[this.nodeName].Dissolve_In) return false;
    DissolvedCache[this.nodeName].Animation_Speed = this.Animation_Speed;
    DissolvedCache[this.nodeName].Dissolve_In = this.Dissolve_In;

    var vertexShader = 
    "float4x4 mWorldViewProj;  // World * View * Projection         \n" + 
    "float4x4 mInvWorld;       // Inverted world matrix	 	        \n" + 
    "float4x4 mTransWorld;     // Transposed world matrix          	\n" + 
    "float mFogDensity ;			    							\n" + 
    "float fogEnable ;				        						\n" + 
    "														        \n" + 
    "// Vertex shader output structure						        \n" + 
    "struct VS_OUTPUT										        \n" + 
    "{														        \n" + 
    "	float4 Position   : POSITION;   // vertex position 	        \n" + 
    "	float4 Diffuse    : COLOR0;     // vertex diffuse           \n" + 
    "	float2 TexCoord   : TEXCOORD0;  // tex coords	            \n" + 
    "	float Fog	: FOG;											\n" +
    "};													            \n" + 
    "														        \n" + 
    "VS_OUTPUT main      ( in float4 vPosition : POSITION,	        \n" + 
    "                      in float3 vNormal   : NORMAL,	        \n" + 
    "                      float2 texCoord     : TEXCOORD0 )        \n" + 
    "{														        \n" + 
    "	VS_OUTPUT Output;									        \n" + 
    "														        \n" + 
    "	// transform position to clip space 			            \n" + 
    "	Output.Position = mul(vPosition, mWorldViewProj);	        \n" + 
    "														        \n" + 
    "	// transformed normal would be this:				        \n" + 
    "	float3 normal = mul(vNormal, mInvWorld);		            \n" + 
    "													            \n" + 
    "	// position in world coodinates	would be this:		        \n" + 
    "	// float3 worldpos = mul(mTransWorld, vPosition);           \n" + 
    "													            \n" + 
    "	Output.Diffuse = float4(1.0, 1.0, 1.0, 1.0);	            \n" + 
    "	Output.TexCoord = texCoord;						            \n" + 
    "														        \n" + 
    "			if (fogEnable == 1)									\n" + 
    "   		{ 													\n" + 
    "     			Output.Fog = saturate(1.0 / exp(Output.Position.z * mFogDensity));	\n" + 
    "  			}													\n" + 
    "  			else												\n" + 
    "  			 {     												\n" + 
    "     			Output.Fog = 1;									\n" + 
    "   		 }  												\n" + 
    "	return Output;										        \n" + 
    "}														";
    
    var fragmentShader = 
    "struct PS_OUTPUT							                        \n" + 
    "{											                        \n" + 
    "    float4 RGBColor : COLOR0; 		  		                        \n" +	
    "};											                        \n" +
    "												                    \n" + 
    "sampler2D tex0;							                        \n" +
    "sampler2D tex1;							                        \n" +
    " float4 strength;                                                  \n" +
    " float4 edgeRadius;                                                \n" + 
    " float4 color;                                                     \n" + 
    " float4 FogColor;													\n" +
    " 												                    \n" +
    "PS_OUTPUT main( float2 TexCoord : TEXCOORD0,	                    \n" +
    "                float4 Position : POSITION,	                    \n" +
    "				 float Fog    : FOG,								\n" +
    "                float4 Diffuse  : COLOR0 ) 	                    \n" +
    "{ 												                    \n" +
    "	PS_OUTPUT Output;							                    \n" +
    "	float4 col = tex2D( tex0, TexCoord );  	                        \n" +  // main texture
    "	float4 alpha = tex2D( tex1, TexCoord );  	                    \n" +  // alpha mask
    "   float2 position = (0.5*strength.x,0.5*strength.x);              \n" + // animating texture cords to animate the effect
    "   float distance = length(position);                              \n" +   //converting posisiton into length of 1
    "   float clipValue = (alpha-distance);                             \n" +   //clipping the texture according to the alpha mask
    "   clip (clipValue);                                               \n" +
    "	float4 dColor =  col + (max (0, (edgeRadius.x - clipValue) / edgeRadius.x ) * color);	\n" +  // Final output color with the edge color and edge radius
    "	float4 fogcol = FogColor*(1-Fog);								\n"	+
    "	Output.RGBColor = float4(dColor.rgb*Fog+fogcol.rgb,dColor.a);	    					\n" +
    "	return Output;								                    \n" +
    "}";

   var me = this;
   if(this.Dissolve_In){ var time = 1.42} // to make the Dissolvbe in effect 1.4 is the alpha clip*2 value here and we  are creating a virtual time variable.
   else{ var time = 0}; //to make the Dissolve out effect with the help of Virtual time
   myShaderCallBack = function () {
        
    var GlobalfogEnable = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"Fog");
	var fogEnable = me.Fog_Enabled;
	if(fogEnable && GlobalfogEnable){var fogenable = 1;var fogDensity = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogDensity");
	var fogColor = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogColor");}
	else{ var fogenable = 0; var fogColor = new vector3d(1,1,1)};
        
        var color = RGB(me.Edge_Color); // to color the edge 
        
        if(me.Dissolve_In)      // Calculate the time and execute the action and set the edge to make the Dissolve In effect
        {
            
            var matCount = ccbGetSceneNodeMaterialCount(me.Affecting_node); //To set the third material as main texture when dissolving in from transparent texture

            for (var i = 0; i < matCount; ++i) {
                if (me.Affect_all_material) {
                    var tex = ccbGetSceneNodeMaterialProperty(me.Affecting_node, i, 'Texture3');
                    ccbSetSceneNodeMaterialProperty(me.Affecting_node, i, 'Texture1', tex);
                }
                else
                {                     
                     var tex = ccbGetSceneNodeMaterialProperty(me.Affecting_node, me.Affecting_material, 'Texture3');       //For affecting specific material
                     ccbSetSceneNodeMaterialProperty(me.Affecting_node, me.Affecting_material, 'Texture1', tex);
                    
                }
            }
            
            //invoking  action
            if(time <= 0)
            {
                time = 0;
                me.Edge_Width = 0;
                ccbInvokeAction(me.Action_On_Complete);
            }
            else{time -= (me.Animation_Speed/100)};
        
        }
        // Dissolve out animation
        else
        {
            time += (me.Animation_Speed/100);
            var Anim_Complete_Check = time*0.5;
            if(Anim_Complete_Check >= 0.7)
            {
                ccbInvokeAction(me.Action_On_Complete); // invoke action on finish of Dissolve out animation
            }
        }
        ccbSetShaderConstant(2, 'strength', time, 0, 0, 0); // animation time constant set to shader
        ccbSetShaderConstant(2, 'edgeRadius', me.Edge_Width, 0, 0, 0); // edge width constant set to shader
        ccbSetShaderConstant(2, 'color', color.x, color.y, color.z, 1); // edgecolor constant set to shader
        ccbSetShaderConstant(2, 'FogColor', fogColor.x,fogColor.y,fogColor.z,1);
        ccbSetShaderConstant(1, 'mFogDensity', fogDensity,0,0,0);
        ccbSetShaderConstant(1, 'fogEnable', fogenable,0,0,0);
        
    }

    // creating Material
    var newMaterial = ccbCreateMaterial(vertexShader, fragmentShader, this.Base_material_type,myShaderCallBack);

    //Check Material index and apply to specified mat index or to all the materials.
    var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

    for (var i = 0; i < matCount; ++i) {
        if (this.Affect_all_material) {
            ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial);
        }
        else { ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial); }
    }
    // Fixing the Color Property type Parameter of action to get RGB value and clamp them between 0 and 1.
    function RGB(decimalcolorcode)
        {var color = (decimalcolorcode); // use the property type or put a  decimal color value.
        var Rr = (color & 0xff0000) >> 16; // get red color by bitwise operation  
        var Gg = (color & 0x00ff00) >> 8; // get green color by bitwise operation 
        var Bb = (color & 0x0000ff); // get blue color by bitwise operation 
        var RrGgBb = new vector3d(Rr,Gg,Bb);
        var r = (Rr/255); // dividing red by 255 to clamp b/w 0-1 
        var g = (Gg/255); // dividing green by 255 to clamp b/w 0-1 
        var b = (Bb/255); // dividing blue by 255 to clamp b/w 0-1 
        var rgb = new vector3d (r,g,b); // final rgb value to use in the editor
        return rgb;
        }
}
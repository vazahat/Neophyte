/*	Info 
	
	Extension Name	: Action make parent
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: February 21, 2022, 09:22 PM
	Description		: Allow you to make scenenode children of another node. 
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	Discord Server :- https://discord.gg/RKcq89S7uA
	YouTube :- https://www.youtube.com/GlitchedVelocity
	Itch.io :- https://vazahat.itch.io/
	

*/
/*	Changelog

    [February 21, 2022]	- I recreated this action, after losing it due to a ransomware

    /*  <action jsname="action_make_parent" description="Make parent/children of another node">
	  <property name="Affecting_node" type="scenenode"/>
	  <property name="New_parent" type="scenenode"/>
	     
    </action>
*/
action_make_parent = function()
{
};

action_make_parent.prototype.execute = function()
{	
    ccbSetSceneNodeParent(this.Affecting_node, this.New_parent)
}
/*End Of Code*/
 
// Above extension is written by Vazahat Khan (just_in_case) //
/*	Info 
	
	Extension Name	: Shader Action Color Swap
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: ‎‎July ‎18, ‎2021, 09:28 AM
	Description		: Swap specific color of any texture with the new color. 
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	Discord Server :- https://discord.gg/RKcq89S7uA
	YouTube :- https://www.youtube.com/GlitchedVelocity
	Itch.io :- https://vazahat.itch.io/
    Website - https://neophyte.cf
	

*/
/*	Changelog

    [July 18, 2021]	- Added Shader action Template from previous self created Shader actions
					- Set shader constants to be used in shader
					- Added code to calucalate R,G, and B value of the main color and did the comparison, with  the color if it falls in between (responsible for Looseness)
					- Added new action properties Paramters for Color to change,new Color to be applied and Looseness
					- Added other parameters and functionality to apply the shader to specific mat index or to all materals, Also added Base mat type, and node to be affected
					- Fixed a few bugs arised during adding new parameters functionality, Also added function to convert decimal color values into RGB and then clamped them b/w 0-1
    
	[July 12, 2022]	- Added Fog Support

					

	
*/



/* Usage
  
 Attach this action to any behavior and then select a node As "Affecting node" whose color you want to Swap, provide a "Color_to_Swap"
 generally the color you want to replace, for example "Red" if you want to replace red color with something else.Now provide a "New_Color" which
 should replace the original color of the texture. As always you can opt if you want to affect all the textures of the scenenode or can specify a 
 specific material index to change specific texture only. Additionaly you can specify "Looseness" the higher the amount the more the color in range 
 will get swapped, lower the amount and the tighter the color swapping will be. For example if you want to cahnge only a specific value then put "Looseness"
 value to "1", or if want to reaplace slightly different shade of blue as well then you can try increasing the value of "Loosenes".
  
  NOTE:- Putting "Looseness" near or above 255 will result in change of the color of whole material. So make sure , you are putting correct value here.
  
*/

/*  <action jsname="action_colorswap" description="Swap Specifc Color of a scenenode with new Color">
	  <property name="Affecting_node" type="scenenode"/>
	  <property name="BaseMaterial" type="int" default="0"/>
	  <property name="Affect_all_material" type="bool" default="true" />
	  <property name="Affecting_material" type="int" default="1" />
	  <property name="Looseness" type="float" default="100.0"/>
	  <property name="Color_to_Swap" type="color"	default="ffFFFFFF"/>
	  <property name="New_Color" type="color"	default="ffFFFFFF"/>
	  <property name="Fog_Enabled" type="bool" default="true" />
	  
	  
    </action>
*/
action_colorswap = function()
{

};

action_colorswap.prototype.execute = function()
{	
	this.Affecting_material -= 1;
//Shader Part
var vertexShader = 
"		float4x4 mWorldViewProj;  // World * View * Projection 					\n" + 
"		float4x4 mTransWorld;     // Transposed world matrix					\n" +
"		float4x4 mInvWorld;       // Inverted world matrix	 					\n" + 
"		float mFogDensity ;														\n" + 
"		float fogEnable ;														\n" + 
"		// Output to fragment program V2F										\n" + 
"		struct VS_OUTPUT														\n" + 
"		{																		\n" + 
"			float4 Position   : POSITION;   // vertex position 					\n" + 
"			float2 Texcoord   : TEXCOORD;   // vertex position 					\n" + 
"			float Fog	: FOG;													\n" +
"		};																		\n" + 
"																				\n" + 
"			//Input From app to vertex program A2V								\n" + 
"		VS_OUTPUT main      ( in float4 vPosition : POSITION,					\n" +
"							  in float2 Texcoord : TEXCOORD)					\n" +
"		{																		\n" + 
"			//Vertex Shader														\n" + 
"			VS_OUTPUT Output;													\n" + 
"			Output.Position = mul(vPosition, mWorldViewProj);					\n" + 
"			Output.Texcoord = Texcoord;											\n" + 
"			if (fogEnable == 1)											    	\n" + 
"   		{ 																	\n" + 
"     			Output.Fog = saturate(1.0 / exp(Output.Position.z * mFogDensity));	\n" + 
"  			}																	\n" + 
"  			else																\n" + 
"  			 {     																\n" + 
"     			Output.Fog = 1;													\n" + 
"   		 }  																\n" + 
"			return Output;														\n" + 
"		}";

var fragmentShader = 
"		struct PS_OUTPUT																\n" + 
"		{																				\n" + 
"		    float4 RGBColor : COLOR; 		  											\n" +	
"		};																				\n" +
"		float4 colortoreplace;															\n" + 
"		float4 replacementcolor;														\n" + 
"		float ColorRange;																\n" + 
"		float4 FogColor;																\n" +
"		sampler2D tex0;																	\n" +
"		PS_OUTPUT main( float2 Texcoord: TEXCOORD,										\n" +
"						float Fog    : FOG)												\n" +
"		{ 																				\n" +
"			PS_OUTPUT Output;															\n" +
"			float4 mainColor = tex2D(tex0, Texcoord);									\n"	+
"																						\n"	+
"			if(abs(mainColor.r - colortoreplace.r) <= ColorRange){						\n" +
"			   if(abs(mainColor.g - colortoreplace.g) <= ColorRange){					\n" +
"			      if(abs(mainColor.b - colortoreplace.b) <= ColorRange){				\n" +
"				mainColor.rgb = replacementcolor.rgb;									\n" +
"				  }																		\n" +
"			  }																			\n" +
"		    }																			\n" +
"			float4 fogcol = FogColor*(1-Fog);											\n"	+
"			Output.RGBColor =  float4(mainColor.rgb*Fog+fogcol.rgb,mainColor.a);		\n" + 
"			return Output;																\n" +
"}";

var me = this; 
this.registeredFunction = function() { me.GV(); }; 
//Shader Callaback Function
myShaderCallBack = function()
{
	var GlobalfogEnable = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"Fog");
	var fogEnable = me.Fog_Enabled;
	if(fogEnable && GlobalfogEnable){var fogenable = 1;var fogDensity = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogDensity");
	var fogColor = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogColor");}
	else{ var fogenable = 0; var fogColor = new vector3d(1,1,1)};
	var parameter = me.GV();
	var oldColor = RGB(parameter.Color_to_Swap);
	var newColor = RGB(parameter.New_Color);
	var Looseness = parameter.Looseness;
	ccbSetShaderConstant(2, 'colortoreplace', oldColor.x,oldColor.y,oldColor.z,1);
	ccbSetShaderConstant(2, 'replacementcolor', newColor.x,newColor.y,newColor.z,1);
	ccbSetShaderConstant(2, 'ColorRange', Looseness/255,1,1,1); 
	ccbSetShaderConstant(2, 'FogColor', fogColor.x,fogColor.y,fogColor.z,1);
	ccbSetShaderConstant(1, 'mFogDensity', fogDensity,0,0,0);
	ccbSetShaderConstant(1, 'fogEnable', fogenable,0,0,0);
}
// creating Material
var newMaterial = ccbCreateMaterial(vertexShader, fragmentShader,this.BaseMaterial, myShaderCallBack);
//Check Material index and apply to sepcifed mat index or to all the materials.
var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

for(var i=0; i<matCount; ++i)
{
	if(this.Affect_all_material)
	{
		ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial);
	}
	else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial);}
}

}

action_colorswap.prototype.GV = function()
{
	return {
			New_Color : this.New_Color,
			Color_to_Swap : this.Color_to_Swap,
			Looseness : this.Looseness
			}
};



// Fixing the Color Property type Parameter of action to get RGB value and clamp them between 0 and 1.
function RGB(decimalcolorcode)
{var color = (decimalcolorcode); // use the property type or put a  decimal color value.
 var Rr = (color & 0xff0000) >> 16; // get red color by bitwise operation  
 var Gg = (color & 0x00ff00) >> 8; // get green color by bitwise operation 
 var Bb = (color & 0x0000ff); // get blue color by bitwise operation 
 var RrGgBb = new vector3d(Rr,Gg,Bb);
 var r = (Rr/255); // dividing red by 255 to clamp b/w 0-1 
 var g = (Gg/255); // dividing green by 255 to clamp b/w 0-1 
 var b = (Bb/255); // dividing blue by 255 to clamp b/w 0-1 
 var rgb = new vector3d (r,g,b); // final rgb value to use in the editor
 return rgb;
 }
 
 
 /*End Of Code*/
 
 
// Above extension is written by Vazahat Khan (just_in_case) //
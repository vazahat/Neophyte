/*  
  <behavior jsname="behavior_SMCarController" description="SM Car Controller">
  	<property name="WheelFrontR" type="scenenode"/>
  	<property name="WheelFrontL" type="scenenode"/>
  	<property name="WheelBackR" type="scenenode"/>
  	<property name="WheelBackL" type="scenenode"/>
  	<property name="Smoke" type="scenenode"/>
  	<property name="Tiretrack" type="scenenode"/>
  	<property name="maxSpeed" type="float" default="3"/>
  	<property name="maxTurnSpeed" type="float" default="1.5"/>
  	<property name="accelerationForce" type="float" default="0.0008"/>
  	<property name="decelerationForce" type="float" default="0.0008"/>
  	<property name="brakeForce" type="float" default="0.002"/>
  	<property name="turnForceAdd" type="float" default="0.004"/>
  	<property name="turnForceSub" type="float" default="0.006"/>
  	<property name="TiretrackBufferSize" type="int" default="1000"/>
  </behavior>
*/

/* 
	(C) Smn Mhmdy, (smarturl.it/SmnMhmdy \\ autosam.sm@gmail.com \\ discord.gg/e6TpKsq)
	April 17, 2021 \\ version 0.1 (alpha)
*/

var smCar;

behavior_SMCarController = function(){
	smCar = this;
	this.Root = ccbGetRootSceneNode();
	this.Camera = ccbGetActiveCamera();
	this.Rot = new Matrixhelper();

	this.forwardForceFloat = 0, this.rightForceFloat = 0;
	this.wheelSpinF = 0, this.wheelSpinB = 0;
	this.lastTireTrackPosition = new vector3d(0,0,0);
	this.tiretrackBuffer = [];
}

behavior_SMCarController.prototype.onAnimate = function(node, Time){
	if(!this.Car){
		this.Car = node;
		this.maxTurnSpeedDefault = this.maxTurnSpeed
		this.prefab = {
			tiretrack: this.Tiretrack,
			smoke: this.Smoke
		};
		this.wheel = {
		    1: this.WheelFrontR,
		    2: this.WheelFrontL,
		    3: this.WheelBackR,
		    4: this.WheelBackL
		};
		this.smoke = {
		    1: Instantiate(this.prefab.smoke, false, false, "smoke_1", this.wheel["1"]),
		    2: Instantiate(this.prefab.smoke, false, false, "smoke_2", this.wheel["2"]),
		    3: Instantiate(this.prefab.smoke, false, false, "smoke_3", this.wheel["3"]),
		    4: Instantiate(this.prefab.smoke, false, false, "smoke_4", this.wheel["4"])
		};
	}

    // time
    this.Time = new Date().getTime();
    this.deltaTime = this.Time - this.lastTime;
    this.lastTime = this.Time;

    // moving the vehicle
    this.movementHandler();

    // camera effect
    ccbSetSceneNodeProperty(this.Camera, "FieldOfView_Degrees", 62 + (Math.abs(this.forwardForceFloat) * 5));
}

behavior_SMCarController.prototype.movementHandler = function(){
    var directionVector = new vector3d(0,0,0);
    this.forwardForceFloatLast = this.forwardForceFloat;

    // forward backward
    if(Key.char["W"]){ // forward
        this.forwardForceFloat = (this.forwardForceFloat < this.maxSpeed) ? this.forwardForceFloat + this.accelerationForce * this.deltaTime : this.maxSpeed;
    }
    if(Key.char["S"]){ // backward
        this.forwardForceFloat = (this.forwardForceFloat > -this.maxSpeed * 0.4) ? this.forwardForceFloat - this.accelerationForce * this.deltaTime : -this.maxSpeed * 0.4;
    }
    if(!(Key.char["S"] || Key.char["W"]) && this.forwardForceFloat){ // deceleration
        if(this.forwardForceFloat > 0){
            var forwardForceFloatNext = this.forwardForceFloat - this.decelerationForce * this.deltaTime;
            if(forwardForceFloatNext < 0) forwardForceFloatNext = 0;
        }
        if(this.forwardForceFloat < 0){
            var forwardForceFloatNext = this.forwardForceFloat + this.decelerationForce * this.deltaTime;
            if(forwardForceFloatNext > 0) forwardForceFloatNext = 0;
        }
        this.forwardForceFloat = forwardForceFloatNext;
    }

    // brake
    if(Key.char["Space"] && this.forwardForceFloat){
        if(this.forwardForceFloat > 0){
            var forwardForceFloatNext = this.forwardForceFloat - this.brakeForce * this.deltaTime;
            if(forwardForceFloatNext < 0) forwardForceFloatNext = 0;
        }
        if(this.forwardForceFloat < 0){
            var forwardForceFloatNext = this.forwardForceFloat + this.brakeForce * this.deltaTime;
            if(forwardForceFloatNext > 0) forwardForceFloatNext = 0;
        }
        this.forwardForceFloat = forwardForceFloatNext;        
    }

    // calculating velocity
    this.forwardVelocity = this.forwardForceFloat - this.forwardForceFloatLast;
    print(this.forwardForceFloat + " _ " + this.rightForceFloat + " _ vel: " + this.forwardVelocity);

    // left and right
    if(Key.char["Space"]) this.maxTurnSpeed = this.maxTurnSpeedDefault * 1.6;
    else this.maxTurnSpeed = this.maxTurnSpeedDefault;

    if(Key.char["D"] && this.forwardForceFloat > 0){ // right forward
        this.rightForceFloat = (this.rightForceFloat < this.maxTurnSpeed) ? this.rightForceFloat + this.turnForceAdd * this.deltaTime * Math.abs(this.forwardForceFloat) : this.maxTurnSpeed;
        this.rightDir = "D";
    }
    if(Key.char["A"] && this.forwardForceFloat > 0){ // left forward
        this.rightForceFloat = (this.rightForceFloat > -this.maxTurnSpeed) ? this.rightForceFloat - this.turnForceAdd * this.deltaTime * Math.abs(this.forwardForceFloat) : -this.maxTurnSpeed;
        this.rightDir = "A";
    }
    if(Key.char["A"] && this.forwardForceFloat < 0){ // right backward
        this.rightForceFloat = (this.rightForceFloat < this.maxTurnSpeed) ? this.rightForceFloat + this.turnForceAdd * this.deltaTime * Math.abs(this.forwardForceFloat) : this.maxTurnSpeed;
        this.rightDir = "D";
    }
    if(Key.char["D"] && this.forwardForceFloat < 0){ // left backward
        this.rightForceFloat = (this.rightForceFloat > -this.maxTurnSpeed) ? this.rightForceFloat - this.turnForceAdd * this.deltaTime * Math.abs(this.forwardForceFloat) : -this.maxTurnSpeed;
        this.rightDir = "A";
    }
    if(!(Key.char["A"] || Key.char["D"]) || Math.abs(this.forwardForceFloat < this.maxSpeed * 0.1) && this.forwardVelocity <= 0){
        if(this.rightDir == "D"){
            this.rightForceFloat = (this.rightForceFloat > 0) ? this.rightForceFloat - this.turnForceSub * this.deltaTime : 0;
        } else if(this.rightDir == "A"){
            this.rightForceFloat = (this.rightForceFloat < 0) ? this.rightForceFloat + this.turnForceSub * this.deltaTime : 0;
        }
    }


    directionVector.z = this.forwardForceFloat;

    var rotation = ccbGetSceneNodeProperty(this.Car, "Rotation");
    var position = ccbGetSceneNodeProperty(this.Car, "Position");
    rotation.y += this.rightForceFloat;

    ccbSetSceneNodeProperty(this.Car, "Rotation", rotation);
    this.Rot.setRotationDegrees(new vector3d(0,rotation.y,0));
    this.Rot.rotateVect(directionVector);
    
    ccbSetSceneNodeProperty(this.Car, "Position", position.add(directionVector));

    // wheels spin
    if(this.forwardForceFloat){
        this.wheelSpinF += this.forwardForceFloat * 10;
        this.wheelSpinB += this.forwardForceFloat * 10;
        if(this.wheelSpinF >= 360) this.wheelSpinF = 0;
        if(this.wheelSpinB >= 360) this.wheelSpinB = 0;
    }

    // direction
    ccbSetSceneNodeProperty(this.wheel["1"], "Rotation", -this.wheelSpinF, 180 + (this.rightForceFloat * 15), 0);
    ccbSetSceneNodeProperty(this.wheel["2"], "Rotation", -this.wheelSpinF, 180 + (this.rightForceFloat * 15), 0);
    ccbSetSceneNodeProperty(this.wheel["3"], "Rotation", -this.wheelSpinB, 180, 0);
    ccbSetSceneNodeProperty(this.wheel["4"], "Rotation", -this.wheelSpinB, 180, 0);

    // smoke effect
    if(this.forwardForceFloat && Math.abs(this.forwardForceFloat) < this.maxSpeed * 0.4 || (Key.char["W"] || Key.char["S"] || this.forwardForceFloat) && Key.char["Space"]){
        ccbSetSceneNodeProperty(this.smoke["3"], "Position", 0, 0, 0);
        ccbSetSceneNodeProperty(this.smoke["4"], "Position", 0, 0 ,0);
        if(this.forwardForceFloat) this.placeTireTracks();
    }
    else if(Math.abs(this.forwardForceFloat) == this.maxSpeed && Math.abs(this.rightForceFloat) == this.maxTurnSpeed){
        ccbSetSceneNodeProperty(this.smoke["1"], "Position", 0, 0, 0);
        ccbSetSceneNodeProperty(this.smoke["2"], "Position", 0, 0 ,0);
        this.placeTireTracks(true);      
    }
    else{
        ccbSetSceneNodeProperty(this.smoke["1"], "Position", 0, -999999, 0);
        ccbSetSceneNodeProperty(this.smoke["2"], "Position", 0, -999999 ,0);
        ccbSetSceneNodeProperty(this.smoke["3"], "Position", 0, -999999, 0);
        ccbSetSceneNodeProperty(this.smoke["4"], "Position", 0, -999999 ,0);
    }

    // ccbSetPhysicsVelocity(this.Car, 
    //     directionVector.x * 10, 
    //     directionVector.y * 10, 
    //     directionVector.z * 10
    // );

}

behavior_SMCarController.prototype.placeTireTracks = function(arg){
    var modelRotation = ccbGetSceneNodeProperty(this.Car, "Rotation");
    if(!arg){ // back
        var tirePosition1 = ccbGetSceneNodeProperty(this.wheel["3"], "PositionAbs");
        var tirePosition2 = ccbGetSceneNodeProperty(this.wheel["4"], "PositionAbs");
    } else { // front
        var tirePosition1 = ccbGetSceneNodeProperty(this.wheel["1"], "PositionAbs");
        var tirePosition2 = ccbGetSceneNodeProperty(this.wheel["2"], "PositionAbs");
    }

    tirePosition1.y += 1, tirePosition2.y += 1;

    var Hit = RaycastAbs(tirePosition1, new vector3d(tirePosition1.x, tirePosition1.y - 4, tirePosition1.z));
    if(Hit){
        Hit.y += 0.1;
        this.lastTireTrackPosition = Hit;
        this.tiretrackBuffer.push(Instantiate(this.prefab.tiretrack, Hit, modelRotation, "tire_1" + this.tiretrackBuffer.length, false));
    }

    var Hit = RaycastAbs(tirePosition2, new vector3d(tirePosition2.x, tirePosition2.y - 4, tirePosition2.z));
    if(Hit){
        Hit.y += 0.1;
        this.lastTireTrackPosition = Hit;
        this.tiretrackBuffer.push(Instantiate(this.prefab.tiretrack, Hit, modelRotation, "tire_2" + this.tiretrackBuffer.length, false));
    }

    if(this.tiretrackBuffer.length > this.TiretrackBufferSize){
        ccbRemoveSceneNode(this.tiretrackBuffer[0]);
        ccbRemoveSceneNode(this.tiretrackBuffer[1]);
        this.tiretrackBuffer.shift();
        this.tiretrackBuffer.shift();
    }
}

// Keys
Key = {
    char: {},
    code: {}
};
ccbRegisterKeyDownEvent("fKeyDown");
ccbRegisterKeyUpEvent("fKeyUp");
function fKeyDown (code) {
    Key.code[code] = true;
    Key.char[String.fromCharCode(code)] = true;

    // special codes
    switch(code){
        case 32:
            Key.char["Space"] = true;
            break;
        case 160:
            Key.char["Shift"] = true;
            break;
        case 162:
            Key.char["Ctrl"] = true;
            break;
        case 164:
            Key.char["Alt"] = true;
            break;
    }
}
function fKeyUp (code) {
    Key.code[code] = false;
    Key.char[String.fromCharCode(code)] = false;

    // special codes
    switch(code){
        case 32:
            Key.char["Space"] = false;
            break;
        case 160:
            Key.char["Shift"] = false;
            smTPCAMERA.playerFootstepsReset();
            break;
        case 162:
            Key.char["Ctrl"] = false;
            break;
        case 164:
            Key.char["Alt"] = false;
            break;
    }
}

// Matrix transformation handler
function Matrixhelper(bMakeIdentity)
{
    if (bMakeIdentity == null)
        bMakeIdentity = true;
        
    this.m00 = 0;
    this.m01 = 0;
    this.m02 = 0;
    this.m03 = 0;
    this.m04 = 0;
    this.m05 = 0;
    this.m06 = 0;
    this.m07 = 0;
    this.m08 = 0;
    this.m09 = 0;
    this.m10 = 0;
    this.m11 = 0;
    this.m12 = 0;
    this.m13 = 0;
    this.m14 = 0;
    this.m15 = 0;
    
    this.bIsIdentity=false;
    
    if (bMakeIdentity)
    {
        this.m00 = 1;
        this.m05 = 1;
        this.m10 = 1;
        this.m15 = 1;
        this.bIsIdentity = true;
    }
}
Matrixhelper.prototype.rotateVect = function(v)
{
    var tmp = new vector3d(v.x, v.y, v.z);
    v.x = tmp.x*this.m00 + tmp.y*this.m04 + tmp.z*this.m08;
    v.y = tmp.x*this.m01 + tmp.y*this.m05 + tmp.z*this.m09;
    v.z = tmp.x*this.m02 + tmp.y*this.m06 + tmp.z*this.m10;
}
Matrixhelper.prototype.setRotationDegrees = function(v)
{
    var c = 3.14159265359 / 180.0;
    v.x *= c;
    v.y *= c;
    v.z *= c;
    this.setRotationRadians(v);
}
Matrixhelper.prototype.setRotationRadians = function(rotation)
{
    var cr = Math.cos( rotation.x );
    var sr = Math.sin( rotation.x );
    var cp = Math.cos( rotation.y );
    var sp = Math.sin( rotation.y );
    var cy = Math.cos( rotation.z );
    var sy = Math.sin( rotation.z );

    this.m00 = ( cp*cy );
    this.m01 = ( cp*sy );
    this.m02 = ( -sp );

    var srsp = sr*sp;
    var crsp = cr*sp;

    this.m04 = ( srsp*cy-cr*sy );
    this.m05 = ( srsp*sy+cr*cy );
    this.m06 = ( sr*cp );

    this.m08 = ( crsp*cy+sr*sy );
    this.m09 = ( crsp*sy-sr*cy );
    this.m10 = ( cr*cp );
    
    this.bIsIdentity = false;
}

// Lerp
function Lerp(s, e, p){
    return (1 - p) * s + p * e;
}

// Instantiate a node
function Instantiate(node, position, rotation, name, parent){
    var nodeinstance = ccbCloneSceneNode(node);
    if(position) ccbSetSceneNodeProperty(nodeinstance, "Position", position);
    if(rotation) ccbSetSceneNodeProperty(nodeinstance, "Rotation", rotation);
    if(name) ccbSetSceneNodeProperty(nodeinstance, "Name", name);
    if(parent) ccbSetSceneNodeParent(nodeinstance, parent);
    return nodeinstance;
}

// Shoots a raycast from a fixed coordinate to another fixed coordinate.
// Raycast(vect3d, vect3d)
RaycastAbs = function(rayStart, rayTarget){
    this.rayCollider = ccbGetCollisionPointOfWorldWithLine(rayStart.x,rayStart.y,rayStart.z,rayTarget.x,rayTarget.y,rayTarget.z);
    if(this.rayCollider)
        return this.rayCollider;
    else
        return false;   
}
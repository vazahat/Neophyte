// This is a coppercube behavior for animating the texture of an 3D object, with a set of dynamically loaded textures.
// Note that the texture files need to be on the same server as your 3D scene, otherwise they cannot be loaded.
// 
// The following embedded xml is for the editor and describes how the action can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*
  <behavior jsname="behavior_AnimateDynamicLoadedTextures" description="Animate with dynamically loaded textures">
     <property name="TimePerFrame" type="int" default="200" />
	 <property name="MaterialIndex" type="int" default="0" />
	 <property name="TextureAmount" type="int" default="8" />
	 <property name="StartTextureIndex" type="int" default="1" />
	 <property name="URL" type="string" default="texture$NUMBER$.png" />
  </behavior>
*/


behavior_AnimateDynamicLoadedTextures = function()
{
	this.StartTime = null;
}


behavior_AnimateDynamicLoadedTextures.prototype.onAnimate = function(node, timeMs)
{    
	if (this.StartTime == null)
		this.StartTime = timeMs; 
	
	var idx = this.StartTextureIndex + (Math.floor((timeMs - this.StartTime) / this.TimePerFrame) % this.TextureAmount);
	ccbSetSceneNodeMaterialProperty(node, this.MaterialIndex, "Texture1", ccbLoadTexture(this.URL.split("$NUMBER$").join(idx.toString())));
}


/*	Info 
	
	Extension Name	: Rotate towards target v1.2
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date updated	: June 15, 2022, 07:28 PM
	Description		: It allows you to rotate your scnenode in the direction of the target node. 
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	Discord Server :- https://discord.gg/RKcq89S7uA
	YouTube :- https://www.youtube.com/GlitchedVelocity
	Itch.io :- https://vazahat.itch.io/
	

*/
/*	Changelog

    [June 15, 2022]	- Updated the extension with animation functionlity
					- Added Smoothing parameter to control animation speed
					- Fixed a few bugs
					- Added ability to stop the rotation or rotate only once
					- Added ability to stop the rotation by setting Coppercube variable "player.rotatetowardstarget" to false

/*  <action jsname="action_rotatetowardstarget" description="Rotate an object towards another object">
      <property name="Scenenode" type="scenenode" />
	  <property name="Target" type="scenenode" />
	  <property name="Rotate_once" type="bool" default="false"/>
	  <property name="Rotation_smoothing" type="int" default="0.9" />
	  <property name="AdditionalRotation" type="int" default="0" />
    </action>
*/

action_rotatetowardstarget = function()
{
};

action_rotatetowardstarget.prototype.execute = function(node)
{
	
	var me = this;
	this.Animation = function() { me.animate(); }; 
	ccbRegisterOnFrameEvent(this.Animation);
	

}
action_rotatetowardstarget.prototype.animate = function()
{
	var me = this;
		
		var position = ccbGetSceneNodeProperty(this.Scenenode, "Position");
		var rotation = ccbGetSceneNodeProperty(this.Scenenode, "Rotation");
		var pos_target = ccbGetSceneNodeProperty(this.Target, "Position");
		var nodename = ccbGetSceneNodeProperty(this.Scenenode,"Name");
		var stopvar = ccbGetCopperCubeVariable(nodename+".rotatetowardstarget");
		var radians_Horizontal = Math.atan2(pos_target.x - position.x,pos_target.z - position.z); 
		var degree_Horizontal = (radians_Horizontal * (180 / Math.PI)) ;
		rotation.y = Lerp(degree_Horizontal+me.AdditionalRotation,rotation.y,this.Rotation_smoothing);
		ccbSetSceneNodeProperty(this.Scenenode,"Rotation",rotation.x, rotation.y, rotation.z); 
	if(!this.Rotate_once){}
	else if(Math.floor(rotation.y) == Math.floor(degree_Horizontal+me.AdditionalRotation)){ccbUnregisterOnFrameEvent(this.Animation);}
	if(stopvar == "false"){ccbUnregisterOnFrameEvent(this.Animation);}
}


function Lerp(plyr, trgt, amt){
    return (1 - amt) * plyr + amt * trgt;
}


/*End Of Code*/

// ***Author:- VAZAHAT PATHAN***

//        ****AKA****

 //   ****Just_in_case**** 

 
// Above extension is written by Vazahat Khan (just_in_case) //
//You are not allowed to remove this License info or any attribution details//
//License info:-//
/* All rights are reserved to Vazahat Khan.
You are allowed to use this asset( code ) in your coppercube projects freely for commercial and personal use without removing the attribtution comments from the code*/
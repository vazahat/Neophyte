/*	Info 
	
	Extension Name	: Action Copy Animations
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: January 30, 2023, 12:41 PM
	Description		: Copy animations from one node to another and use them with the new node if both the nodes share same skeleton/rig. 
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	Discord Server :- https://discord.gg/RKcq89S7uA
	YouTube :- https://www.youtube.com/GlitchedVelocity
	Itch.io :- https://vazahat.itch.io/
	

*/

/*  
  <action jsname="action_copyAnimation" description="Copy Animation from one node to another (same rig)">
  <property name="Copy_to" type="scenenode"/>
  <property name="Copy_from" type="scenenode"/>
  <property name="Animation_name" type="string"/>
  <property name="Looping" type="bool"/>
   
  </action>
*/

action_copyAnimation = function(){

}

action_copyAnimation.prototype.execute = function (node){
  
  ccbSetAnimationFromSceneNode(this.Copy_to,this.Copy_from, this.Animation_name);
  if(this.Looping)
  {
    ccbSetSceneNodeProperty(this.Copy_to,"Looping",true);
  }
  else
  {
    ccbSetSceneNodeProperty(this.Copy_to,"Looping",false);
  }

}

// ***Author:- VAZAHAT PATHAN***

//        ****AKA****

 //   ****Just_in_case**** 

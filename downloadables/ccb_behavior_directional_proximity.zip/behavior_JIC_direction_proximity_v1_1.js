/*	Info 
	
    Extension Name	: Behavior Directional Box Proximity
    Extension Type	: Behavior
    Author:			: Vazahat Khan (just_in_case)
    Date Created	: v1.0 on april 26, 2023, 04:24
    Description		: Allows you to execute and action when an object enters the proximity from a specific direction. 
	
*/
/* 	Donate
	
    If you like my work, please consider "buy me a cup of coffee" to support me.
    You can do that via PayPal :)
	
    PayPal: http://paypal.me/Vazahat
    Itch.io - https://vazahat.itch.io/cc-shader-spritesheet-animation
    Youtube - https://www.youtube.com/channel/UC_yfoGEKkmY63tnyy6hR7ZQ
    Website - https://neophyte.cf
    Discord - https://discord.gg/RKcq89S7uA
	

*/
/*	Changelog

    [April 26, 2023] - Copied base behavior
                     - Added direction detection and distance check
                     - Based on the distance created proximity
                     - Used the scale of the object as proximity area
                     - Added actions for each directions to be executed
                     - Added action on leave so that user can execute an action when leaving the proximity box.
    
    [May 02, 2023]   - Fixed a bug, that was not let the proximity work if the scenenode is a children to another scenenode. 
                     ToDo - Add Spherical proximity if people demand the speherical proximity while the box proximity is already enough. 
*/
/*
	<behavior jsname="behavior_JIC_direction_proximity_v1_1" description="Directional proximity 1.1">
	<property name="Near_to_what" type="scenenode" />
	<property name="X" type="action" />
	<property name="Negative_X" type="action" />
	<property name="Y" type="action" />
	<property name="Negative_Y" type="action" />
	<property name="Z" type="action" />
	<property name="Negative_Z" type="action" />
	<property name="Action_on_leave" type="action" />
	</behavior>
*/

behavior_JIC_direction_proximity_v1_1 = function()
{
    this.playerInside = false;
};

behavior_JIC_direction_proximity_v1_1.prototype.onAnimate = function(node) {
    var playerPosition = ccbGetSceneNodeProperty(this.Near_to_what,"PositionAbs");
    var proximityArea = ccbGetSceneNodeProperty(node,"PositionAbs");
    var proximityAreascale = ccbGetSceneNodeProperty(node,"Scale");

    var distanceX = Math.abs(playerPosition.x - proximityArea.x);
    var distanceY = Math.abs(playerPosition.y - proximityArea.y);
    var distanceZ = Math.abs(playerPosition.z - proximityArea.z);
    
    var directionOfEntryX;

    if (playerPosition.x < proximityArea.x)
    {
        directionOfEntryX = 'left';
    }
    if (playerPosition.x > proximityArea.x)
    {
        directionOfEntryX = 'right';
    }

    var directionOfEntryY;

    if (playerPosition.y < proximityArea.y)
    {
        directionOfEntryY = 'bottom';
    }
    if (playerPosition.y > proximityArea.y)
    {
        directionOfEntryY = 'top';
    }

    var directionOfEntryZ;

    if (playerPosition.z < proximityArea.z)
    {
        directionOfEntryZ = 'front';
    }
    if (playerPosition.z > proximityArea.z) {
        directionOfEntryZ = 'back';
    }

    if (distanceX < (proximityAreascale.x / 2) && distanceY < (proximityAreascale.y / 2) && distanceZ < (proximityAreascale.z / 2))
    {
        if(!this.playerInside)
        {
            if(directionOfEntryX == "left"){ccbInvokeAction(this.X);}
            else if(directionOfEntryX == "right"){ccbInvokeAction(this.Negative_X)}
            if(directionOfEntryY == "bottom"){ccbInvokeAction(this.Y)}
            else if(directionOfEntryY == "top"){ccbInvokeAction(this.Negative_Y)}
            if(directionOfEntryZ == "front"){ccbInvokeAction(this.Z)}
            else if(directionOfEntryZ == "back"){ccbInvokeAction(this.Negative_Z)}
            this.playerInside = true;
        }    
    }
    else{if(this.playerInside){ccbInvokeAction(this.Action_on_leave)}this.playerInside = false;}
}

/*End Of Code*/

// Above extension is written by Vazahat Khan (just_in_case) //
/*
	<action jsname="action_smThirdpersonActionManager" description="SM Thirdperson Action Manager">
		<property name="onMoveForward" type="action" />
		<property name="onMoveBackward" type="action" />
		<property name="onMoveRight" type="action" />
		<property name="onMoveLeft" type="action" />
		<property name="onJump" type="action" />
		<property name="onRun" type="action" />
	</action>
*/

/* 
	(C) Smn Mhmdy, (smarturl.it/SmnMhmdy \\ autosam.sm@gmail.com \\ discord.gg/e6TpKsq)
	
	This action requires "SM Thirdperson Controller" to work.
	
	You can use the "SM Thirdperson Action Manager" action to directly execute actions when an event (such as moving, jumping, etc.) occurs.

*/

var smTPAM;

action_smThirdpersonActionManager = function(){ smTPAM = this; }
action_smThirdpersonActionManager.prototype.execute = function(node){}
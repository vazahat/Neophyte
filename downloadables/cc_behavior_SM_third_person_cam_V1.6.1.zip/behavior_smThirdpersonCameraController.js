/*  
  <behavior jsname="behavior_smThirdpersonCameraController" description="SM Thirdperson Controller">
  	<property name="Player" type="scenenode"/>
	<property name="Sensitivity" type="float" default="20"/>
	<property name="maxRadius" type="float" default="20"/>
	<property name="shoulderOffset" type="float" default="0"/>
	<property name="lookHeight" type="float" default="15"/>
	<property name="angleClamp" type="float" default="0"/>
	<property name="collisionCheck" type="bool" default="true"/>
	<property name="handleMovement" type="bool" default="true"/>
	<property name="handleAnimation" type="bool" default="true"/>
	<property name="canFly" type="bool" default="false"/>
	<property name="alwaysFaceCamDir" type="bool" default="false"/>
	<property name="idleFaceCamDir" type="bool" default="false"/>
	<property name="mouseWheelChangeRadius" type="bool" default="true"/>
	<property name="walkSpeed" type="float" default="0.2"/>
	<property name="runSpeed" type="float" default="0.4"/>
	<property name="jumpSpeed" type="float" default="3"/>
	<property name="idleAnimation" type="string" default="Idle"/>
	<property name="walkAnimation" type="string" default="Walk"/>
	<property name="runAnimation" type="string" default="Run"/>
	<property name="airAnimation" type="string" default="Idle"/>
	<property name="externalAnimationWindowMs" type="float" default="500"/>
	<property name="keyMoveForward" type="string" default="W"/>
	<property name="keyMoveBackward" type="string" default="S"/>
	<property name="keyMoveRight" type="string" default="D"/>
	<property name="keyMoveLeft" type="string" default="A"/>
	<property name="keyRun" type="string" default="Shift"/>
	<property name="keyJump" type="string" default="Space"/>
	<property name="playFootsteps" type="bool" default="false"/>
	<property name="walkFootstepInterval" type="float" default="580"/>
	<property name="runFootstepInterval" type="float" default="300"/>
	<property name="soundFootstepDefault" type="action"/>
	<property name="soundFootstepType1" type="action"/>
	<property name="soundFootstepType2" type="action"/>
	<property name="soundFootstepType3" type="action"/>
	<property name="soundFootstepType4" type="action"/>
	<property name="soundFootstepType5" type="action"/>
	<property name="folderFootstepType1" type="scenenode"/>
	<property name="folderFootstepType2" type="scenenode"/>
	<property name="folderFootstepType3" type="scenenode"/>
	<property name="folderFootstepType4" type="scenenode"/>
	<property name="folderFootstepType5" type="scenenode"/>
	<property name="stickySurfaces" type="bool" default="false"/>
	<property name="folderStickyNodes" type="scenenode"/>
  </behavior>
*/

/* 
	(C) Smn Mhmdy, (smarturl.it/SmnMhmdy \\ autosam.sm@gmail.com \\ discord.gg/e6TpKsq)
	May 17, 2021 \\ version 1.6.1

	Create a simple camera and attach "SM Thirdperson Controller" to it, then attach the built-in "First Person Shooter style controlled" and set the "MoveSpeed", "RotateSpeed" and "JumpSpeed" to 0. Make sure SM Thirdperson Controller is above the FPS style controlled in the action manager. 

	Change the sensitivity at runtime using smTPCAMERA.Sensitivity or by setting the value of "Sensitivity" using "Set or change a Variable" action.

	You can use the "SM Thirdperson Action Manager" action to directly execute actions when an event (such as moving, jumping, etc.) occurs.
*/

var smTPCAMERA, smTPAM;

behavior_smThirdpersonCameraController = function(){
	smTPCAMERA = this;
	this.deltaTimeDivide = 20;
	this.Rot = new MatrixhelperB();
	this.PlayerCameraDiff = new vector3d(0,0,0);
	this.CollisionRay = new vector3d(0,0,0);
	this.PlayerVelocity = { x: 0, y: 0 };
	this.mouseInputHandleType = 1;
	this.animationLooping = true;
	this.Root = ccbGetRootSceneNode();
	this.PlayerJumpForceFloat = 0;
}

behavior_smThirdpersonCameraController.prototype.onAnimate = function(node, Time){
	if(!this.node){ // doing this only once
		this.node = node;
		this.name = ccbGetSceneNodeProperty(node, "Name");
		this.lastTime = Time;
		this.PlayerName = ccbGetSceneNodeProperty(this.Player, "Name");
		this.PlayerPosition = ccbGetSceneNodeProperty(this.Player, "Position");
		this.lastPlayerPosition = new vector3d(this.PlayerPosition.x, this.PlayerPosition.y, this.PlayerPosition.z);
		this.CameraPosition = ccbGetSceneNodeProperty(node, "Position");
		this.cameraPositionReset();
		this.cameraOrderReset();
		this.currentAnimation = ccbGetSceneNodeProperty(this.Player, "Animation");
		this.currentRadius = this.maxRadius; // * 1.2 // for a zooming out effect at the start

		// footsteps
		this.Footsteps = {
			// sounds
			sound: {
				default: this.soundFootstepDefault,
				type1: this.soundFootstepType1,
				type2: this.soundFootstepType2,
				type3: this.soundFootstepType3,
				type4: this.soundFootstepType4,
				type5: this.soundFootstepType5,
			},
			// node list
			container: {
				type1: GetChildList(this.folderFootstepType1),
				type2: GetChildList(this.folderFootstepType2),
				type3: GetChildList(this.folderFootstepType3),
				type4: GetChildList(this.folderFootstepType4),
				type5: GetChildList(this.folderFootstepType5),
			},
			count: 5
		};

		return;
	}

	// return if the camera is not active
	var activeCameraName = ccbGetSceneNodeProperty(ccbGetActiveCamera(), "Name");
	if(activeCameraName != this.name){
		if(this.handleAnimation) ccbSetSceneNodeProperty(this.Player, "Animation", this.idleAnimation);
		return;
	}

	// time
	this.Time = Time;
	this.deltaTime = Time - this.lastTime;
	this.lastTime = Time;

	// mouse input axis
	this.mouseInputHandler();

    // position and rotation, etc
	this.CameraPosition = ccbGetSceneNodeProperty(node, "Position");
	this.CameraRotation = ccbGetSceneNodeProperty(node, "Rotation");
	this.PlayerPosition = ccbGetSceneNodeProperty(this.Player, "Position");
	this.PlayerRotation = ccbGetSceneNodeProperty(this.Player, "Rotation");
	this.PlayerPosition.y += this.lookHeight;
	this.Rot.setRotationDegrees(new vector3d(this.CameraRotation.x, this.CameraRotation.y, this.CameraRotation.z));
	this.knownAnimationList = [this.idleAnimation, this.walkAnimation, this.runAnimation, this.airAnimation];

	// calculating shoulder view offset vector
	this.shoulderOffsetVect = new vector3d(this.shoulderOffset,0,0);
	this.Rot.rotateVect(this.shoulderOffsetVect);

	// player forced facing direction
	if(this.alwaysFaceCamDir || (this.idleFaceCamDir && !(Key.char[this.keyMoveBackward] || Key.char[this.keyMoveRight] || Key.char[this.keyMoveLeft])))
		this.SmoothRotation(this.Player,this.CameraRotation.y);

	// player sticking to defined surfaces
	if(this.stickySurfaces)
		this.playerStickToSurface();

	// positioning player
	if(this.handleMovement)
		this.playerMovementHandler();

	// moving camera with player
	this.cameraDiffHandler();

	// animating player
	if(this.handleAnimation)
		this.playerAnimationHandler();

	// checking for camera collisions
	if(this.collisionCheck)
		this.cameraCollisionHandler();

	// rotating camera around player using mouse
	this.cameraPositionHandler();

	// playing footstep sound
	if(this.playFootsteps)
		this.playerFootstepsHandler();

	// action manager
	this.actionManager();
}

behavior_smThirdpersonCameraController.prototype.playerMovementHandler = function(){
	// setting the speed
	if(Key.char[this.keyRun])
		var speed = this.runSpeed; 
	else 
		var speed = this.walkSpeed;

	var PlayerPosition = ccbGetSceneNodeProperty(this.Player, "Position");
	var directionVector = new vector3d(0,0,0), rotationFloat = 0;

	// calculate movement vector and rotation
	if(Key.char[this.keyMoveForward]){ // forward
		directionVector = directionVector.add(new vector3d(0.0, 0.0, 1.0));
	}
	if(Key.char[this.keyMoveBackward]){ // backward
		directionVector = directionVector.add(new vector3d(0.0, 0.0, -1.0));
		rotationFloat -= 180;
	}
	if(Key.char[this.keyMoveRight]){ // right
		directionVector = directionVector.add(new vector3d(1.0, 0.0, 0.0));
		if(Key.char[this.keyMoveForward])
			rotationFloat += 45;
		else if(Key.char[this.keyMoveBackward])
			rotationFloat -= 45;
		else 
			rotationFloat += 90;
	}
	if(Key.char[this.keyMoveLeft]){ // left 
		directionVector = directionVector.add(new vector3d(-1.0, 0.0, 0.0));
		if(Key.char[this.keyMoveForward])
			rotationFloat -= 45;
		else if(Key.char[this.keyMoveBackward])
			rotationFloat += 45;
		else 
			rotationFloat -= 90;
	}
	if(Key.char[this.keyJump] && this.PlayerJumpTime == 0 && Math.abs(this.PlayerVelocity.y) < 0.1 && !this.PlayerJumpPressed){ // jump start
		this.PlayerJumpForceFloat = this.jumpSpeed;
		this.PlayerJumpTime = this.PlayerJumpForceFloat * 110;
		this.PlayerJumpPressed = true;
		this.actionManager("Jump");

	} 
	if(!Key.char[this.keyJump]){
		this.PlayerJumpPressed = false;
	}
	if(this.PlayerJumpTime > 0){ // jump progress
		directionVector.y = 1.0;
		this.PlayerJumpTime -= this.deltaTime * 0.9;
		this.PlayerJumpForceFloat -= this.deltaTime * 0.009;
	} else { // jump end
		this.PlayerJumpForceFloat = 0;
		this.PlayerJumpTime = 0;
	} 

	if(this.alwaysFaceCamDir) rotationFloat = 0;

	// apply movement vector
	if(directionVector.x || directionVector.y || directionVector.z){
		if(directionVector.x || directionVector.z){
			this.SmoothRotation(this.Player,this.CameraRotation.y + rotationFloat);
			if(this.canFly) this.Rot.rotateVect(directionVector);
			else this.Rot.rotateVectB(directionVector);
		}
		directionVector.normalize();
		directionVector.x *= speed * this.deltaTime * 0.1;
		directionVector.y = (this.canFly) ? directionVector.y * speed * this.deltaTime * 0.1 : this.PlayerJumpForceFloat * this.deltaTime * 0.1;
		directionVector.z *= speed * this.deltaTime * 0.1;
		PlayerPosition = PlayerPosition.add(directionVector);
		ccbSetSceneNodeProperty(this.Player, "Position", PlayerPosition);
	}

	this.PlayerPosition = new vector3d(PlayerPosition.x, PlayerPosition.y + this.lookHeight, PlayerPosition.z);
}

behavior_smThirdpersonCameraController.prototype.playerAnimationHandler = function(){
	// overwriting the animation outside of the script
	this.lastAnimation = this.currentAnimation;
	this.currentAnimation = ccbGetSceneNodeProperty(this.Player, "Animation");
	if(this.currentAnimation != this.lastAnimation){
		if(this.knownAnimationList.indexOf(this.currentAnimation) < 0 || this.PlayerForcedAnimation){ // animation not recognized, overwriting
			this.PlayerForcedAnimation = this.currentAnimation;
			this.PlayerForcedAnimationWindow = this.externalAnimationWindowMs;
		}
	}

	if(this.PlayerForcedAnimation && this.PlayerForcedAnimationWindow > 0){ // forcing an animation
		this.PlayerForcedAnimationWindow -= this.deltaTime;
		ccbSetSceneNodeProperty(this.Player, "Animation", this.PlayerForcedAnimation);
		this.playerFootstepsReset();
		return;
	} else {
		this.PlayerForcedAnimation = false;
		this.PlayerForcedAnimationWindow = 0;
	}

	if(this.PlayerVelocity.x > this.walkSpeed / 2 && (Key.char[this.keyMoveForward] || Key.char[this.keyMoveBackward] || Key.char[this.keyMoveRight] || Key.char[this.keyMoveLeft])){
		if(Key.char[this.keyRun]){ // running
			ccbSetSceneNodeProperty(this.Player, "Animation", this.runAnimation);
		}
		else{ // walking
			ccbSetSceneNodeProperty(this.Player, "Animation", this.walkAnimation);
		}
	} else { // idling
		ccbSetSceneNodeProperty(this.Player, "Animation", this.idleAnimation);
	}

	this.PlayerForcedAnimation = false;
	
	if(this.PlayerVelocity.y < -1 && this.airAnimation){ // mid air
		ccbSetSceneNodeProperty(this.Player, "Animation", this.airAnimation);
	}

	if(!this.PlayerForcedAnimation)
		ccbSetSceneNodeProperty(this.Player, "Looping", this.animationLooping);
}

behavior_smThirdpersonCameraController.prototype.cameraCollisionHandler = function(){
	var CameraPositionCollisionCheck = new vector3d(0, 0, -this.maxRadius * 1.1);
	this.Rot.rotateVect(CameraPositionCollisionCheck);
	var CameraPositionCollisionCheck = CameraPositionCollisionCheck.add(this.CameraPosition).substract(this.shoulderOffsetVect);
	this.CollisionRay = RaycastAbs(this.PlayerPosition, CameraPositionCollisionCheck);
}

behavior_smThirdpersonCameraController.prototype.cameraDiffHandler = function(){
	this.PlayerPositionDiff = this.PlayerPosition.substract(this.lastPlayerPosition);
	this.lastPlayerPosition = new vector3d(this.PlayerPosition.x, this.PlayerPosition.y, this.PlayerPosition.z);
	this.CameraPosition = this.CameraPosition.add(this.PlayerPositionDiff);
	this.PlayerVelocity.x = new vector3d(this.PlayerPositionDiff.x, 0, this.PlayerPositionDiff.z).getLength();
	this.PlayerVelocity.y = this.PlayerPositionDiff.y;
}

behavior_smThirdpersonCameraController.prototype.cameraPositionHandler = function(){
	var position = new vector3d(this.CameraPosition.x, this.CameraPosition.y, this.CameraPosition.z);
	var target = new vector3d(this.PlayerPosition.x, this.PlayerPosition.y, this.PlayerPosition.z).add(this.shoulderOffsetVect);
	var playerVect = target.substract(position);
	var movementVect = new vector3d(-playerVect.z, 0, playerVect.x);
	movementVect.normalize();

	// camera speed distance multiplier
	var dstCameraMult = position.substract(target).getLength() * 2;

	if(this.xAxis || this.yAxis){
		movementVect.x *= this.xAxis * (dstCameraMult * 0.01);
		movementVect.z *= this.xAxis * (dstCameraMult * 0.01);
		movementVect.y  = this.yAxis * (dstCameraMult * 0.01);
		position = position.add(movementVect);
	}

	// collision (fixes the camera clipping through objects)
	if(!this.CollisionRay.x && !this.CollisionRay.y && !this.CollisionRay.z){
		this.currentRadius = Lerp(this.currentRadius, this.maxRadius, this.deltaTime * 0.004);
		var radius = this.currentRadius;
	}
	else {
		var dstClipping = this.CollisionRay.substract(target).getLength() * 0.88 - (this.shoulderOffset * 1.04);
		if(this.currentRadius < dstClipping){
			var radius = Lerp(this.currentRadius, Clamp(dstClipping, 2, this.maxRadius), this.deltaTime * 0.004);
		} else {
			var radius = Clamp(dstClipping, 2, this.maxRadius);
		}
		this.currentRadius = radius;
	}

	// orbit in radius
	var targetVect = position.substract(target);
	targetVect.normalize();
	targetVect.x *= radius;
	targetVect.y *= radius;
	targetVect.z *= radius;
	position = target.add(targetVect);

	// clamping the angle
	var lookAngle = (Math.abs(this.CameraRotation.x - 180) - 180) * -1;
	if(this.CameraRotation.x < 360 && this.CameraRotation.x > 200)
		var lookAngleBound = -1;
	else if(this.CameraRotation.x > 0 && this.CameraRotation.x < 200)
		var lookAngleBound = 1;
	if(this.angleClamp && lookAngle >= this.angleClamp){
		position.y -= lookAngleBound * this.deltaTime * 0.01 * radius * 0.2;
	}

	// setting the final position and target
	ccbSetSceneNodeProperty(this.node, "Position", position);
	ccbSetSceneNodeProperty(this.node, "Target", target);
}

behavior_smThirdpersonCameraController.prototype.cameraPositionReset = function(){
	// repositions the camera behind the player
	var PlayerRotation = ccbGetSceneNodeProperty(this.Player, "Rotation");
	var PlayerPosition = ccbGetSceneNodeProperty(this.Player, "Position");
	this.Rot.setRotationDegrees(PlayerRotation);
	var behindVector = new vector3d(0, 0, this.maxRadius * -10);
	this.Rot.rotateVect(behindVector);
	behindVector = behindVector.add(PlayerPosition);
	ccbSetSceneNodeProperty(this.node, "Position", behindVector);
}

behavior_smThirdpersonCameraController.prototype.mouseInputHandler = function(){
	// screen, mouse and sensitivity
    this.screenW = ccbGetScreenWidth();
    this.screenH = ccbGetScreenHeight();
    this.mouseY = ccbGetMousePosY();
    this.mouseX = ccbGetMousePosX();
    var ccSensitivity = ccbGetCopperCubeVariable("Sensitivity");
    if (ccSensitivity) this.Sensitivity = ccSensitivity;

    // mouse axis
    switch(this.mouseInputHandleType){
    	case 1:
		    this.xAxis = (this.mouseX - this.screenW/2) * this.Sensitivity * 0.01;
		    this.yAxis = (this.mouseY - this.screenH/2) * this.Sensitivity * 0.01;
		    break;
	    case 2:
            this.xAxis = Math.sin((this.mouseX - (this.screenW / 2)) / this.screenW) * 200.0 * 8 * this.Sensitivity * 0.01;
            this.yAxis = Math.sin((this.mouseY - (this.screenH / 2)) / this.screenH) * 100.0 * 8 * this.Sensitivity * 0.01;
	    	break;
	}
}

behavior_smThirdpersonCameraController.prototype.actionManager = function(action){
	if(!smTPAM) return;

	if(action){ // specific action call
		switch(action){
			case "Jump":
				ccbInvokeAction(smTPAM.onJump);
				break;
		}

	} else { // normal routine
		if(Key.char[this.keyMoveForward])
			ccbInvokeAction(smTPAM.onMoveForward);
		if(Key.char[this.keyMoveBackward])
			ccbInvokeAction(smTPAM.onMoveBackward);
		if(Key.char[this.keyMoveRight])
			ccbInvokeAction(smTPAM.onMoveRight);
		if(Key.char[this.keyMoveLeft])
			ccbInvokeAction(smTPAM.onMoveLeft);
		if(Key.char[this.keyRun])
			ccbInvokeAction(smTPAM.onRun);
	}
}

behavior_smThirdpersonCameraController.prototype.playerFootstepsHandler = function(){
	if(this.PlayerVelocity.x > this.walkSpeed / 4 && this.PlayerVelocity.y > -1 && (Key.char[this.keyMoveForward] || Key.char[this.keyMoveBackward] || Key.char[this.keyMoveRight] || Key.char[this.keyMoveLeft])){
		if(this.PlayerFootstepsTime > 0){
			this.PlayerFootstepsTime -= this.deltaTime;
		}
		else {
			this.playerFootstepsPlay();
			this.playerFootstepsReset();
		}
	} else {
		this.playerFootstepsReset();
	}
}

behavior_smThirdpersonCameraController.prototype.playerFootstepsReset = function(){
	if(Key.char[this.keyRun]){
		this.PlayerFootstepsTime = this.runFootstepInterval;
	} else {
		this.PlayerFootstepsTime = this.walkFootstepInterval;
	}
}

behavior_smThirdpersonCameraController.prototype.playerFootstepsPlay = function(){
	var currentFootstepSound = this.Footsteps.sound.default;

	var sPos = new vector3d(this.PlayerPosition.x, this.PlayerPosition.y + (this.lookHeight * 0.1), this.PlayerPosition.z);
	var ePos = new vector3d(this.PlayerPosition.x, this.PlayerPosition.y - (this.lookHeight * 1.2) - this.PlayerJumpForceFloat * 20, this.PlayerPosition.z);

	for(var i = 1; i <= this.Footsteps.count; i++){
		var str = "type" + i;
		if(RayHit(sPos, ePos, this.Footsteps.container[str])) currentFootstepSound = this.Footsteps.sound[str];
	}

	ccbInvokeAction(currentFootstepSound);
}

behavior_smThirdpersonCameraController.prototype.playerStickToSurface = function(){
	if(!this.SurfaceList){
		this.SurfaceList = GetChildList(this.folderStickyNodes);
		return;	
	}

	var sPos = new vector3d(this.PlayerPosition.x, this.PlayerPosition.y + (this.lookHeight * 0.1), this.PlayerPosition.z);
	var ePos = new vector3d(this.PlayerPosition.x, this.PlayerPosition.y - (this.lookHeight * 1.1) - this.PlayerJumpForceFloat * 20, this.PlayerPosition.z);

	var Hit = RayHit(sPos, ePos, this.SurfaceList);
	if(!Hit) { // didn't find a sticky surface
		this.currentSurfacePosition = new vector3d(0,0,0);
		this.lastSurfacePosition = new vector3d(0,0,0);
		this.currentSurface = false;
		this.lastSurface = false;
		return;
	} else { // found a sticky surface
		if(!this.currentSurface || this.currentSurface != this.lastSurface){
			this.currentSurface = Hit;
			this.currentSurfacePosition = ccbGetSceneNodeProperty(this.currentSurface, "Position");
			this.lastSurface = this.currentSurface;
			return;
		}
		this.lastSurface = this.currentSurface;
		this.currentSurface = Hit;
	}

	// moving the player with the surface
	var PlayerPosition = ccbGetSceneNodeProperty(this.Player, "Position");
	this.lastSurfacePosition = this.currentSurfacePosition;
	this.currentSurfacePosition = ccbGetSceneNodeProperty(this.currentSurface, "Position");
	var currentSurfacePositionDiff = this.currentSurfacePosition.substract(this.lastSurfacePosition);
	var currentSurfaceMovementVect = PlayerPosition.add(currentSurfacePositionDiff);
	ccbSetSceneNodeProperty(this.Player, "Position", currentSurfaceMovementVect);
	
	this.PlayerPosition = currentSurfaceMovementVect;

}

behavior_smThirdpersonCameraController.prototype.onMouseEvent = function(event, wdata){
	if(!this.mouseWheelChangeRadius) return;
	if(wdata){
		var dstCameraMult = this.PlayerPosition.substract(this.CameraPosition).getLength();
		this.maxRadius = Clamp(this.maxRadius - wdata * dstCameraMult * 0.08, 5, 100);
	}
}

behavior_smThirdpersonCameraController.prototype.SmoothRotation = function (node, target){
	// this code is quite old and definitely requires rewriting at some point 
	this.Rotation = ccbGetSceneNodeProperty(node,"Rotation");
	this.Relative = ((target - this.Rotation.y) / 10) * this.deltaTime / (this.deltaTimeDivide/1.5);
	this.SmoothRotationChange = 0;
	this.SmoothRotationDiff = (this.Rotation.y-target)%360;
	if(this.SmoothRotationDiff < 0)
		this.SmoothRotationChange = 1;
	else
		this.SmoothRotationChange = -1;
	if(Math.abs(this.SmoothRotationDiff) > 180)
		this.SmoothRotationChange = 0 - this.SmoothRotationChange;
	this.Rotation.y += this.SmoothRotationChange * this.deltaTime / (this.deltaTimeDivide / 1.5) * 5;
	if(this.Rotation.y > 360)
		this.Rotation.y -= 360;
	if(this.Rotation.y < -360)
		this.Rotation.y += 360;
	this.RotationCorrect = 0 + this.deltaTime / 2;
	this.RotationCorrectFlip = 360 - this.deltaTime / 2;
	if(Math.abs(this.Rotation.y - target) < this.RotationCorrect || Math.abs(target - this.Rotation.y) < this.RotationCorrect || Math.abs(this.Rotation.y - target) > this.RotationCorrectFlip || Math.abs(target - this.Rotation.y) > this.RotationCorrectFlip)
		this.Rotation.y = target;
	ccbSetSceneNodeProperty(node,"Rotation",this.Rotation);
	return this.Rotation;
}

behavior_smThirdpersonCameraController.prototype.cameraOrderReset = function(){
	ccbSetSceneNodeParent(this.node, this.Player);
	ccbSetSceneNodeParent(this.node, this.Root);
}

// Matrix transformation handler
// Originally by N.Gebhardt \\ office@ambiera.com
MatrixhelperB = function(bMakeIdentity)
{
	if (bMakeIdentity == null)
		bMakeIdentity = true;
		
	this.m00 = 0;
	this.m01 = 0;
	this.m02 = 0;
	this.m03 = 0;
	this.m04 = 0;
	this.m05 = 0;
	this.m06 = 0;
	this.m07 = 0;
	this.m08 = 0;
	this.m09 = 0;
	this.m10 = 0;
	this.m11 = 0;
	this.m12 = 0;
	this.m13 = 0;
	this.m14 = 0;
	this.m15 = 0;
	
	this.bIsIdentity=false;
	
	if (bMakeIdentity)
	{
		this.m00 = 1;
		this.m05 = 1;
		this.m10 = 1;
		this.m15 = 1;
		this.bIsIdentity = true;
	}
}

MatrixhelperB.prototype.rotateVect = function(v)
{
	var tmp = new vector3d(v.x, v.y, v.z);
	v.x = tmp.x*this.m00 + tmp.y*this.m04 + tmp.z*this.m08;
	v.y = tmp.x*this.m01 + tmp.y*this.m05 + tmp.z*this.m09;
	v.z = tmp.x*this.m02 + tmp.y*this.m06 + tmp.z*this.m10;
}

MatrixhelperB.prototype.rotateVectB = function(v)
{
	var tmp = new vector3d(v.x, v.y, v.z);
	v.x = tmp.x*this.m00 + tmp.y*this.m04 + tmp.z*this.m08;
	v.z = tmp.x*this.m02 + tmp.y*this.m06 + tmp.z*this.m10;
}

MatrixhelperB.prototype.setRotationDegrees = function(v)
{
	var c = 3.14159265359 / 180.0;
	v.x *= c;
	v.y *= c;
	v.z *= c;
	this.setRotationRadians(v);
}

MatrixhelperB.prototype.setRotationRadians = function(rotation)
{
	var cr = Math.cos( rotation.x );
	var sr = Math.sin( rotation.x );
	var cp = Math.cos( rotation.y );
	var sp = Math.sin( rotation.y );
	var cy = Math.cos( rotation.z );
	var sy = Math.sin( rotation.z );

	this.m00 = ( cp*cy );
	this.m01 = ( cp*sy );
	this.m02 = ( -sp );

	var srsp = sr*sp;
	var crsp = cr*sp;

	this.m04 = ( srsp*cy-cr*sy );
	this.m05 = ( srsp*sy+cr*cy );
	this.m06 = ( sr*cp );

	this.m08 = ( crsp*cy+sr*sy );
	this.m09 = ( crsp*sy-sr*cy );
	this.m10 = ( cr*cp );
	
	this.bIsIdentity = false;
}

// Keys
Key = {
    char: {},
    code: {}
};
ccbRegisterKeyDownEvent("fKeyDown");
ccbRegisterKeyUpEvent("fKeyUp");
function fKeyDown (code) {
    Key.code[code] = true;
    Key.char[String.fromCharCode(code)] = true;

    // special codes
    switch(code){
    	case 32:
    		Key.char["Space"] = true;
    		break;
    	case 160:
    		Key.char["Shift"] = true;
 			break;
 		case 162:
 			Key.char["Ctrl"] = true;
 			break;
 		case 164:
 			Key.char["Alt"] = true;
 			break;
    }
}
function fKeyUp (code) {
    Key.code[code] = false;
    Key.char[String.fromCharCode(code)] = false;

    // special codes
    switch(code){
    	case 32:
    		Key.char["Space"] = false;
    		break;
    	case 160:
    		Key.char["Shift"] = false;
    		smTPCAMERA.playerFootstepsReset();
 			break;
 		case 162:
 			Key.char["Ctrl"] = false;
 			break;
 		case 164:
 			Key.char["Alt"] = false;
 			break;
    }
}

// Shoots a raycast from a fixed coordinate to another fixed coordinate
RaycastAbs = function(rayStart, rayTarget){
    this.rayCollider = ccbGetCollisionPointOfWorldWithLine(rayStart.x,rayStart.y,rayStart.z,rayTarget.x,rayTarget.y,rayTarget.z);
    if(this.rayCollider)
        return this.rayCollider;
    else
        return false;   
}

// Shoots a raycast from a fixed coordinate to another fixed coordinate and checks for a collision with an array of objects
RayHit = function(rayStart, rayTarget, mask){
    if (!mask) return false;
    for (var i = 0 ; i < mask.length ; i++) {
        var Hit = RaycastHitAbs(rayStart, rayTarget, mask[i]);
        if (Hit) return mask[i];
    }
}

// Shoots a raycast from a fixed coordinate to another fixed coordinate and checks for the given target node collision
RaycastHitAbs = function(rayStart, rayTarget, rayTargetNode){
    if(ccbDoesLineCollideWithBoundingBoxOfSceneNode(rayTargetNode, rayStart.x,rayStart.y,rayStart.z,rayTarget.x,rayTarget.y,rayTarget.z))
        return true;
    else
        return false;
}

// Clamps a number between two given values
Clamp = function(n, min, max) {
    if (n < min) n = min;
    if (n > max) n = max;
    return n;
}

// Returns list of child nodes of an object
GetChildList = function(parent){

	if(ccbGetSceneNodeProperty(parent, "Name") == false)
		return false;

	var ret = [];
	var count = ccbGetSceneNodeChildCount(parent);
	for(var i = 0; i < count; i++){
		var child = ccbGetChildSceneNode(parent, i);
		ret.push(child);
	}
	return ret;
}

// Lerp
Lerp = function(s, e, p){
	return (1 - p) * s + p * e;
}
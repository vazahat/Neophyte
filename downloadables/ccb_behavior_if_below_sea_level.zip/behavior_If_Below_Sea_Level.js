//"If Below Sea Level do something" created by Bracer Jack.
// This is a coppercube behavior which moves the node it is attached to only on the x axis,
// controlled by the cursor keys and with space for 'jump'.
//
// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*
	<behavior jsname="behavior_If_Below_Sea_Level" description="If Below Sea Level do something">
		<property name="Sea_Level" type="int" default="0" />
		<property name="Action_When_Below_Sea_Level" type="action" />
	</behavior>
*/

behavior_If_Below_Sea_Level = function()
{
};

// called every frame. 
//   'node' is the scene node where this behavior is attached to.
//   'timeMs' the current time in milliseconds of the scene.
// Returns 'true' if something changed, and 'false' if not.
behavior_If_Below_Sea_Level.prototype.onAnimate = function(node, timeMs)
{
	this.i_Pos = ccbGetSceneNodeProperty(node, 'Position');
	
	//In case your character is not straight up, its y property might not be "down" per say
	//and the following code could be use to double check, but since I don't need it in 
	//my game, I did not further enhance this part of the checking.
	//this.i_Rotation = ccbGetSceneNodeProperty(node, 'Rotation');
	
	if (this.i_Pos.y < this.Sea_Level)
	{
		//var txtLevel = ccbGetSceneNodeFromName("txtLevel_Indicator");
		//ccbSetSceneNodeProperty(txtLevel,"Text","Restart !!!");
		ccbInvokeAction(this.Action_When_Below_Sea_Level, this.node);
	}
	
	return true;
}
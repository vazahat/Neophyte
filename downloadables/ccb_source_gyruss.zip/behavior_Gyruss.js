// This is a coppercube behavior which moves the node it is attached to only on the x axis,
// controlled by the cursor keys and with space for 'jump'.
//
// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*
	<behavior jsname="behavior_Gyruss" description="GYRUS">
		<property name="speed" type="float" default="0.02" />

	</behavior>
*/

behavior_Gyruss = function()
{
	this.speed = 0.0;
	this.step = 0;
	this.r = 50;
	this.x=0.0;
	this.y=0.0;
	this.direction="";
	this.key=0;
	this.key_value=false;
	this.key_left_value=false;
	this.key_right_value=false;
	this.key_up_value=false;
	this.key_down_value=false;
};

// called every frame. 
//   'node' is the scene node where this behavior is attached to.
//   'timeMs' the current time in milliseconds of the scene.
// Returns 'true' if something changed, and 'false' if not.
behavior_Gyruss.prototype.onAnimate = function(currentNode, timeMs,pressed)
{
	var gp = ccbGetSceneNodeProperty(currentNode, "Position");
	var gr = ccbGetSceneNodeProperty(currentNode, "Rotation");

 	//if (this.speed>0){this.speed=this.speed-0.01;}
		//if (this.speed<0){this.speed=this.speed+0.01;}
		//if (this.speed>0.1){this.speed=0.1;}
		//if (this.speed<-0.1){this.speed=-0.1;}

		this.step=this.step+this.speed;
		this.x=this.r*Math.cos(this.step)*1.2;
		this.y=this.r*Math.sin(this.step);
		ccbSetSceneNodeProperty(currentNode, "Position",this.x,this.y,0);
		if (this.y<0)
		{
			var attack_angle=this.x*90/this.r;
		}else{
			var attack_angle=this.x*90/this.r;
		}
		
		ccbSetSceneNodeProperty(currentNode, "Rotation",gr.x,gr.y,attack_angle);

		if (this.key == 38 && this.key_value)//up

		{
			if (this.x>0){this.speed=0.04;}
			if (this.x<0){this.speed=-0.04;}
			if (parseInt(this.x)==0){this.speed=-0.04;}
			if (this.x>-1 && this.x<1 && this.y>0){this.speed=0.00;}
		}

		//if (this.key == 40 && this.key_value)//down
		if (this.key_down_value)//down
		{
			if (this.x>0){this.speed=-0.04;}
			if (this.x<0){this.speed=0.04;}
			if (parseInt(this.x)==0){this.speed=0.04;}
			if (this.x>-1 && this.x<1 && this.y<0){this.speed=0.00;}
		}

		//if (this.key == 37 && this.key_value)//left
		if (this.key_left_value)	
		{
			if (this.y>0){this.speed=0.04;}
			if (this.y<0){this.speed=-0.04;}
			if (parseInt(this.y)==0){this.speed=-0.04;}
			if (this.y>-1 && this.y<1 && this.x<0){this.speed=0.00;}
		}

		//if (this.key == 39 && this.key_value)//right
		if (this.key_right_value)	
		{
			if (this.y>0){this.speed=-0.04;}
			if (this.y<0){this.speed=0.04;}
			if (parseInt(this.y)==0 && this.x<0){this.speed=0.04;}
			if (this.y>-1 && this.y<1 && this.x>0){this.speed=0.00;}
		}

		//if (!this.key_value)//notkey
		if (this.key_left_value || this.key_right_value || this.key_up_value || this.key_down_value)	
		{}else{
			this.speed=this.speed/10;
			if (parseInt(this.speed)==0){this.speed=0;}
		}

		

		//print(this.step);

}

// parameters: key: key id pressed or left up.  pressed: true if the key was pressed down, false if left up

behavior_Gyruss.prototype.onKeyEvent = function(key, pressed)
{
	this.key=key;
	this.key_value=pressed;
	//print(key);



		if (key == 40)
		{
			/*
			if (this.x>0){this.speed=this.speed-0.1;}
			if (this.x<0){this.speed=this.speed+0.1;}
			if (this.x==0){this.speed=this.speed+0.1;}
			*/
			this.direction="down";
			this.key_down_value = pressed;
		}


		if (key == 39)
		{
			/*
			if (this.y>0){this.speed=this.speed-0.1;}
			if (this.y<0){this.speed=this.speed+0.1;}
			if (this.y==0){this.speed=this.speed+0.1;}
			*/
			this.key_right_value = pressed;
			this.direction="right";
		}
		if (key == 37)
		{
			/*
			if (this.y>0){this.speed=this.speed+0.1;}
			if (this.y<0){this.speed=this.speed-0.1;}
			if (this.y==0){this.speed=this.speed-0.1;}
			*/
			this.key_left_value = pressed;
			this.direction="left";
		}
		if (key == 38)
		{
			/*
			if (this.y>0){this.speed=this.speed+0.1;}
			if (this.y<0){this.speed=this.speed-0.1;}
			if (this.y==0){this.speed=this.speed-0.1;}
			*/
			this.key_up_value = pressed;
			this.direction="up";
		}


}

// mouseEvent: 0=mouse moved, 1=mouse wheel moved, 2=left mouse up,  3=left mouse down, 4=right mouse up, 5=right mouse down
behavior_Gyruss.prototype.onMouseEvent = function(mouseEvent, mouseWheelDelta)
{
	// we currently don't support move event. But for later use maybe.
}

// This is a coppercube behavior slightly moves the camera it is attached to only on the x axis,
// and y axis, controlled by the mouse, making a parallax effect. You can also call 
// enable_behavior_parallaxCameraEffect(true);
// or
// enable_behavior_parallaxCameraEffect(false);
// to temporarily enable or disable this effect.
//
// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*
	<behavior jsname="behavior_parallaxCameraEffect" description="Parallax Camera Effect">
		<property name="MovementSpeed" type="float" default="0.1"  />
		<property name="MaxMovementArea" type="float" default="10"  />
	</behavior>
*/

behavior_parallaxCameraEffect = function()
{
	this.LastTime = null;
};

behavior_parallaxCameraEffectEnabled = true;

enable_behavior_parallaxCameraEffect = function(b)
{
	behavior_parallaxCameraEffectEnabled = b;
}

// called every frame. 
//   'node' is the scene node where this behavior is attached to.
//   'timeMs' the current time in milliseconds of the scene.
// Returns 'true' if something changed, and 'false' if not.
behavior_parallaxCameraEffect.prototype.onAnimate = function(n, timeMs)
{
	if (!behavior_parallaxCameraEffectEnabled)
		return;
		
	// get the time since the last frame
	
	if (this.LastTime == null)
	{
		this.LastTime = timeMs;
		return;
	}
	
	// calculate time delta
	
	var delta = timeMs - this.LastTime;
	this.LastTime = timeMs;
	if (delta > 200) delta = 200;
	
	// move camera
	
	var camPos = ccbGetSceneNodeProperty(n, 'Position');
	var camTarget = ccbGetSceneNodeProperty(n, 'Target');
	
	var moveZInsteadOfX = Math.abs(camTarget.x - camPos.x) > Math.abs(camTarget.z - camPos.z);
	
	var mx = ccbGetMousePosX();
	var my = ccbGetMousePosY();
	var sx = ccbGetScreenWidth();
	var sy = ccbGetScreenHeight();
	
	var moveX = ((mx - (sx / 2)) / sx) * this.MovementSpeed * delta;
	var moveY = ((my - (sy / 2)) / sy) * this.MovementSpeed * delta;
	
	if (moveZInsteadOfX)
	{
		camPos.z -= moveX;
		
		if (camPos.z < camTarget.z - this.MaxMovementArea)
			camPos.z = camTarget.z - this.MaxMovementArea;
		if (camPos.z > camTarget.z + this.MaxMovementArea)
			camPos.z = camTarget.z + this.MaxMovementArea;
	}
	else
	{
		camPos.x -= moveX;
		
		if (camPos.x < camTarget.x - this.MaxMovementArea)
			camPos.x = camTarget.x - this.MaxMovementArea;
		if (camPos.x > camTarget.x + this.MaxMovementArea)
			camPos.x = camTarget.x + this.MaxMovementArea;
	}
		
	camPos.y += moveY;
		
	if (camPos.y < camTarget.y - this.MaxMovementArea)
		camPos.y = camTarget.y - this.MaxMovementArea;
	if (camPos.y > camTarget.y + this.MaxMovementArea)
		camPos.y = camTarget.y + this.MaxMovementArea;
	
	ccbSetSceneNodeProperty(n, 'Position', camPos);
	
	return true;
}
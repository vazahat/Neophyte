/*	Info 
	
	Extension Name	: Action Cel Shading (toon Shader)
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: July 26, 2021, 12:20 PM
	Description		: A shader to create stylized toon characters and object with multiple options. 
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	Discord Server :- https://discord.gg/RKcq89S7uA
	YouTube :- https://www.youtube.com/GlitchedVelocity
	

*/
/*	Changelog

    [July 26,2021]	- Added Shader action code from previous shader actions
					- Added basic flat shading
					- Added light color and light positions
					- Added specular lighting with specular color and gloss options
					- Added ambient color
					- Added shader brigtness controller to control shade
					- Added basic Edge with controllable properties like edge size, threshold and color
					- Added extra paramters to action properties required by shader to run properly
					- Fixed a Bug causing the edge to not appear on the lit area instead appearing on the dark side
					- Added Edge threshold to control the amount of edge drawn

    [February 17,2022]	- Fixed a bug that was causing the shader to not update, when the object on which the shader is applied gets rotated.

    [July 09,2022]	- Added support for fog rendering for the objects on which the shaders are applied to.
					- Added FogEnabled parameter to the shader to toggle fog the object, can be useful if you don't want the object to be affected by fog
					
					- TODO:- update the shader action to disable or enable some functionality of the shader.


*/



/* Usage
  
  Attach this action to a behavior event and then specify a scenenode in "Light_source" which will act as source for our shader, specify an "Affecting_node" to make toon. 
  Specify additional light properties like light color,ambient color, specular color etc.
  You can adjust the shade strength and Specularity using the provided parameters. Check if you want to affect all the materials of the "Affecting node" or 
  you can uncheck it and can speicfy specific material index (for example zero "1" if you want to affect first material of the node only). You can also specify
  a "Base_material_type" to blend the shader with other material type for exmaple (12 if you want to use Tranparent_Add as base material type). Not all the materials
  blend with the shader, only a few can be blended with shaders.
  
  NOTE:- Edge size uses a value between 0-1 and size decreases as the value increases. same goes for the specular gloss,
  the higher the value for the gloss is the tighter the specular highlights will become. Edge Threshold is also between 0-1.
*/

/*  <action jsname="action_cellshade" description="Toon Shader (cel shading)">
	  <property name="Light_source" type="scenenode"/>
	  <property name="Affecting_node" type="scenenode"/>
	  <property name="Affect_all_material" type="bool" default="true" />
	  <property name="Affecting_material" type="int" default="1" />
	  <property name="Base_material_type" type="int" default="0" />
	  <property name="shade_brightness" type="int" default="0.5" />
	  <property name="Light_color" type="color"	default="ffFFFFFF"/>
	  <property name="Ambient_color" type="color"	default="ff000000"/>
	  <property name="Specular_color" type="color"	default="ffFFFFFF"/>
	  <property name="Specular_Gloss" type="int" default="40" />
	  <property name="Edge_color" type="color"	default="ff000000"/>
	  <property name="Edge_size" type="int" default="0.5" />
	  <property name="Edge_threshold" type="int" default="0.1" />
	  <property name="Fog_Enabled" type="bool" default="true" />
    </action>
*/
action_cellshade = function()
{

};

action_cellshade.prototype.execute = function()
{	
	this.Affecting_material -= 1;	
//Shader Part
var vertexShader = 
"		float4x4 mWorldViewProj;  // World * View * Projection 					\n" + 
"		float4x4 mTransWorld;     // Transposed world matrix					\n" +
"		float4x4 mInvWorld;       // Inverted world matrix	 					\n" + 
"		float3 lightPos ;														\n" +
"		float3 cameraPos ;														\n" + 
"		float mFogDensity ;														\n" + 
"		float fogEnable ;														\n" + 
"		// Output to fragment program V2F										\n" + 
"		struct VS_OUTPUT														\n" + 
"		{																		\n" + 
"			float4 Position   : POSITION;   // vertex position 					\n" + 
"			float2 TexCoord   : TEXCOORD0;  // tex coords						\n" + 
"			float3 worldNormal  : TEXCOORD1;  // tex coords						\n" +
"			float3 lightVec   : TEXCOORD2;   // vertex Diffuse color			\n" + 
"			float3 eyeVec   : TEXCOORD3;										\n" +
"			float Fog	: FOG;													\n" +
"		};																		\n" + 
"																				\n" + 
"			//Input From app to vertex program A2V								\n" + 
"		VS_OUTPUT main      ( in float4 vPosition : POSITION,					\n" +
"		                      in float3 vNormal   : NORMAL,						\n" +
"		                      float2 texCoord     : TEXCOORD0) 					\n" + 
"		{																		\n" + 
"			//Vertex Shader														\n" + 
"			VS_OUTPUT Output;													\n" +  
"			Output.Position = mul(vPosition, mWorldViewProj);					\n" + 
"			Output.worldNormal = mul(vNormal, mInvWorld);						\n" +
"			float3 worldSpacePos = mul(mTransWorld, vPosition);					\n" + 
"			Output.lightVec = lightPos - worldSpacePos;							\n" +
"			Output.eyeVec = cameraPos - worldSpacePos;							\n" +	
"			Output.TexCoord = texCoord;											\n" +
"			if (fogEnable == 1)											    	\n" + 
"   		{ 																	\n" + 
"     			Output.Fog = saturate(1.0 / exp(Output.Position.z * mFogDensity));	\n" + 
"  			}																	\n" + 
"  			else																\n" + 
"  			 {     																\n" + 
"     			Output.Fog = 1;													\n" + 
"   		 }  																\n" + 
"																				\n" +
"			return Output;														\n" + 
"		}";

var fragmentShader = 
"		struct PS_OUTPUT																\n" + 
"		{																				\n" + 
"		    float4 RGBColor : COLOR; 		  											\n" +	
"		};																				\n" +
"																						\n" + 
"		sampler2D tex0;																	\n" + 
"		float ShadowStrength;															\n" +
"		float4 LightColor;															    \n" +
"		float4 AmbientColor;															\n" +
"		float4 SpecularColor;															\n" +
"		float SpecularGloss;															\n" +
"		float4 EdgeColor;																\n" +
"		float EdgeSize;																	\n" +
"		float EdgeThreshold;															\n" +
"		float4 FogColor;																\n" +
"																						\n" +
"		PS_OUTPUT main( float2 TexCoord : TEXCOORD0,									\n" +
"						float3 worldNormal  : TEXCOORD1,								\n" +
"						float3 lightVec  : TEXCOORD2,									\n" +
"						float3 eyeVec  : TEXCOORD3,										\n" +
"						float Fog    : FOG,												\n" +
"		                float4 Position : POSITION)										\n" +
"		{ 																				\n" +
"			PS_OUTPUT Output;															\n" +
"		    float4 ColorTexture = tex2D(tex0, TexCoord);								\n" +
"			float3 N = normalize(worldNormal);											\n" +
"			float3 L = normalize(lightVec);												\n" +
"			float3 E = normalize(eyeVec);												\n" +
"			float3 HalfAngle = normalize(L + E); 										\n" +
"			float NdotH = saturate(dot(N,HalfAngle));									\n" +
"			float NdotL = dot(N,L);														\n" +
"			float LI = NdotL > 0 ? 1 : ShadowStrength;									\n"	+
"			float LIS = smoothstep(0, 0.01, LI);										\n" +
"			float4 Light = LIS * LightColor;											\n" +
"			float SI = pow(NdotH * LIS, SpecularGloss * SpecularGloss);					\n" +
"			float SIS = smoothstep(0.005, 0.01, SI); 									\n" +
"			float4 Specular = SIS * SpecularColor;										\n" +
"			float4 EdgeDot = 1 - dot(E, N);												\n" +
"			float EI = EdgeDot * pow(NdotL, EdgeThreshold);								\n" +
"			EI = smoothstep(EdgeSize - 0.01, EdgeSize + 0.01, EI);						\n" +
"			float4 Edge = EI * EdgeColor -EI;											\n" +
"			float4 toonColor = ColorTexture *(Light + AmbientColor + Specular + Edge); 	\n" + 
"			float4 fogcol = FogColor*(1-Fog);											\n"	+
"			Output.RGBColor = float4(toonColor.rgb*Fog+fogcol.rgb,toonColor.a);			\n" +
"			return Output;																\n" +
"		}";

var me = this; 
//Shader Callaback Function
myShaderCallBack = function()
{
	var light = me.Light_source;
	var GlobalfogEnable = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"Fog");
	var fogEnable = me.Fog_Enabled;
	if(fogEnable && GlobalfogEnable){var fogenable = 1;var fogDensity = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogDensity");
	var fogColor = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogColor");}
	else{ var fogenable = 0; var fogColor = new vector3d(1,1,1)};
	var lightpos = ccbGetSceneNodeProperty(light,"Position");
	var cam =  ccbGetActiveCamera();
	this.camPos = ccbGetSceneNodeProperty(cam,"Position");
	var lightcolor = RGB(me.Light_color);
	var ambientcolor = RGB(me.Ambient_color);
	var specularcolor = RGB(me.Specular_color);
	var edgecolor = RGB(me.Edge_color);
	this.SS = me.shade_brightness;
	this.SG = me.Specular_Gloss;
	this.ES = me.Edge_size;
	this.ET = me.Edge_threshold;
	ccbSetShaderConstant(1, 'lightPos', lightpos.x,lightpos.y,lightpos.z,0);
	ccbSetShaderConstant(1, 'mFogDensity', fogDensity,0,0,0);
	ccbSetShaderConstant(1, 'fogEnable', fogenable,0,0,0);
	ccbSetShaderConstant(1, 'cameraPos', this.camPos.x,this.camPos.y,this.camPos.z,0);
	ccbSetShaderConstant(2, 'LightColor', lightcolor.x,lightcolor.y,lightcolor.z,1);
	ccbSetShaderConstant(2, 'AmbientColor', ambientcolor.x,ambientcolor.y,ambientcolor.z,1);
	ccbSetShaderConstant(2, 'SpecularColor', specularcolor.x,specularcolor.y,specularcolor.z,1);
	ccbSetShaderConstant(2, 'EdgeColor', edgecolor.x,edgecolor.y,edgecolor.z,1);
	ccbSetShaderConstant(2, 'ShadowStrength', this.SS,0,0,0);
	ccbSetShaderConstant(2, 'SpecularGloss', this.SG,1,1,1);
	ccbSetShaderConstant(2, 'EdgeSize', this.ES,1,1,1);
	ccbSetShaderConstant(2, 'EdgeThreshold', this.ET,1,1,1);
	ccbSetShaderConstant(2, 'FogColor', fogColor.x,fogColor.y,fogColor.z,1);
	
}
// creating Material
var newMaterial = ccbCreateMaterial(vertexShader, fragmentShader, this.Base_material_type, myShaderCallBack);

//Check Material index and apply to sepcifed mat index or to all the materials.
var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

for(var i=0; i<matCount; ++i)
{	
	if(this.Affect_all_material)
	{
		ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial);
	}
	else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial);}
}

}
// Fixing the Color Property type Parameter of action to get RGB value and clamp them between 0 and 1.
function RGB(decimalcolorcode)
{var color = (decimalcolorcode); // use the property type or put a  decimal color value.
 var Rr = (color & 0xff0000) >> 16; // get red color by bitwise operation  
 var Gg = (color & 0x00ff00) >> 8; // get green color by bitwise operation 
 var Bb = (color & 0x0000ff); // get blue color by bitwise operation 
 var RrGgBb = new vector3d(Rr,Gg,Bb);
 var r = (Rr/255); // dividing red by 255 to clamp b/w 0-1 
 var g = (Gg/255); // dividing green by 255 to clamp b/w 0-1 
 var b = (Bb/255); // dividing blue by 255 to clamp b/w 0-1 
 var rgb = new vector3d (r,g,b); // final rgb value to use in the editor
 return rgb;
 }
 
 /*End Of Code*/
 
 
// Above extension is written by Vazahat Khan (just_in_case) //
/*	Info 
	
	Extension Name	: Behavior Custom Path nodes and AI
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: June 03, 2022, 07:28 PM
	Description		: Makes an AI follows a custom path 
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	Discord Server :- https://discord.gg/RKcq89S7uA
	YouTube :- https://www.youtube.com/GlitchedVelocity
	Itch.io :- https://vazahat.itch.io/
	

*/

/*	Changelog

    [June 03, 2022]	- Added Base code
					- Added ability to use path nodes inside a path folder to be followed by AI
					- Added ability to loop path continuosly or follow once
	[June 04, 2022]	- Added ability to make the AI stop once in the activation radius
					- Fixed a bug and use another way to solve the activation radius issue
					- Added the necessary parameters to the extension
					- Ability to execute action on completing path once
					- Ability to execute action on reaching or interacting with Player 
	[June 06, 2022]	- Ability to  execute an action when reaching specific node
					- Option to enable or disable stopping of AI when encountered with the player
					- Added ability to look towards motion
					- Added additional rotation parameter for look towards motion
					- Added ability to execute an action on leaving player interaction or player radius
	[June 07, 2022]	- Fixed a bug that was causing memory leaks and out of memory error in the game
					- Added Patrol Mode so that the AI can go back and forth on the path
					- Fixed bugs for the action on finish ( it was executing one node earlier before)
					- Fixed other bugs that were causing trouble to the extension 
					- Used a different approach for activation radius  ( thanks to SmnMhmdy)
					- Fixed a bug that was not executing the action on finish when Path is not in loop mode
					- AI is now look towards the player when player is encountered



// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*
	<behavior jsname="behavior_Custom_Path_AI" description="Makes an AI follows a custom path ">
		<property name="AI" type="scenenode" />
		<property name="Player" type="scenenode" />
		<property name="Speed" type="float" default="0.02" />
		<property name="Path" type="scenenode" />
		<property name="Look_towards_motion" type="bool" />
		<property name="AdditionalRotation" type="int" />
		<property name="Loop_path" type="bool" />
		<property name="Patrol_mode" type="bool" />
		<property name="Stop_when_player_encounter" type="bool" />
		<property name="Activation_radius" type="int" default="100"/>
		<property name="Action_on_interact" type="action" />
		<property name="Action_on_leaving" type="action" />
		<property name="Action_on_finish" type="action" />
		<property name="Action_on_node" type="action" />
		<property name="Node_number" type="int" />

	</behavior>
*/
var unit_type;
behavior_Custom_Path_AI = function()
{
	this.LastTime = null;
	this.unit_pos;
    this.pathnodePos = [];
    this.angle = 0;
    this.TargetPosition ;
    this.currentpathnode = 0;
    this.activation  = false;
};



behavior_Custom_Path_AI.prototype.onAnimate = function(node, timeMs)
{	
    
    if(!node){
		return false;
	}
	node = this.AI;

    var TargetPos = ccbGetSceneNodeProperty(this.Player,"Position");
	this.unit_pos = ccbGetSceneNodeProperty(node, "Position");
    var pathnodeCount = ccbGetSceneNodeChildCount(this.Path);
    if(!this.activate)
	{
        this.TargetPosition  = this.pathnodePos[this.currentpathnode];
    }
	if(this.currentpathnode == this.Node_number){ccbInvokeAction(this.Action_on_node)}
        

    		
	//	
	if (this.LastTime == null)
	{
		this.LastTime = timeMs; // we were never called before, so store the time and cancel
		this.stopPos = ccbGetSceneNodeProperty(node,"Position");
		if(this.Patrol_mode){this.Loop_path = true}
		for(var i=0; i<pathnodeCount; ++i)
        {
           if(i >= pathnodeCount){break;}
			var child = ccbGetChildSceneNode(this.Path, i);
		    this.pathnodePos.push(ccbGetSceneNodeProperty(child, 'Position'));
        } 
		return false;
	}
	
	this.LastNodeUsed = node;
	
	var timeDiff = timeMs - this.LastTime;
	this.LastTime = timeMs;
	if (timeDiff > 200) timeDiff = 200;
	
	var pos = ccbGetSceneNodeProperty(node, 'Position');
	var directionForward = new vector3d(0.0,0.0,0.0);
	var lengthToGo = 0.0;
	this.bMovingForward = false;
		
	// get wanted rotation /Direction of the movement
    /*this.angle ++;
	if (this.angle >= 360){this.angle = 0};
	var radiusx = this.unit_pos.x+ Math.sin(this.angle)*this.Activation_radius;
	var radiusz = this.unit_pos.z+ Math.cos(this.angle)*this.Activation_radius;
	if (Math.sqrt((TargetPos.x-radiusx)*(TargetPos.x-radiusx) + (TargetPos.z-radiusz)*(TargetPos.z-radiusz)) <= this.Activation_radius)
	{
	
    }*/ //this was casuing a bug that so used alternative fake radius method below.
	if(this.Stop_when_player_encounter){
	//if (this.unit_pos.x < TargetPos.x+this.Activation_radius && this.unit_pos.x > TargetPos.x-this.Activation_radius && this.unit_pos.z > TargetPos.z-this.Activation_radius && this.unit_pos.z < TargetPos.z+this.Activation_radius && this.unit_pos.y > TargetPos.y-this.Activation_radius && this.unit_pos.y < TargetPos.y+this.Activation_radius)
	if(this.unit_pos.substract(TargetPos).getLength() <= this.Activation_radius)
		{
		this.stopPos = ccbGetSceneNodeProperty(node,"Position");
		this.activate = true;
        this.TargetPosition = this.stopPos;
        ccbInvokeAction(this.Action_on_interact);
		}
	else{this.activate = false;ccbInvokeAction(this.Action_on_leaving);}
	}

	
	if (this.TargetPosition != null)
	{
		directionForward = this.TargetPosition.substract(pos);
		lengthToGo = directionForward.getLength();
		this.bMovingForward = lengthToGo > (this.Speed * 200);
						
	}
	var rotation = ccbGetSceneNodeProperty(node, "Rotation");
	if(this.activate){ var pos_target = TargetPos}
	else{var pos_target = this.TargetPosition};
	var radians_Horizontal = Math.atan2(pos_target.x - pos.x,pos_target.z - pos.z); 
    var degree_Horizontal = (radians_Horizontal * (180 / Math.PI)) ;
	if (this.Look_towards_motion){
	ccbSetSceneNodeProperty(node,"Rotation",rotation.x, degree_Horizontal + this.AdditionalRotation, rotation.z); 
	}
	this.PosCorrection = new vector3d(this.TargetPosition.x-directionForward.x,this.TargetPosition.y-directionForward.y,this.TargetPosition.z-directionForward.z);
	if(!this.bMovingForward && !this.activate)
    {
        if(Math.floor(this.unit_pos.x) == Math.floor(this.PosCorrection.x) && Math.floor(this.unit_pos.y) == Math.floor(this.PosCorrection.y) && Math.floor(this.unit_pos.z) == Math.floor(this.PosCorrection.z))
        {
            if(!this.Loop_path)
            {	
                	if(this.currentpathnode+1 == pathnodeCount)
                	{
                   		this.currentpathnode = pathnodeCount-1;
						ccbInvokeAction(this.Action_on_finish);
               		}
                	else{this.currentpathnode += 1};
				
			}
			else if(this.currentpathnode+1 == pathnodeCount)
				{
				   this.currentpathnode = 0;
			   }
			else{this.currentpathnode += 1 };
			if(this.Patrol_mode)
			{
				if(this.currentpathnode == 0)
				{
				   this.pathnodePos.reverse();
			    }
			}
			if( this.currentpathnode == 0){ccbInvokeAction(this.Action_on_finish);}
        }
    }

	if (this.bMovingForward)
	{
		// move forward/backward
		var speed = this.Speed * timeDiff;
		directionForward.normalize();
		pos.x += directionForward.x * speed;
		pos.y += directionForward.y * speed;
		pos.z += directionForward.z * speed;
	}
	

	//set position of the node
	ccbSetSceneNodeProperty(node, 'Position', pos);
	return true;

}



/*End Of Code*/
 
// Above extension is written by Vazahat Khan (just_in_case) //
//You are not allowed to remove this License info or any attribution details//
//License info:-//
/* All rights are reserved to Vazahat Khan.
You are allowed to use this asset( code ) in your coppercube projects freely for commercial and personal use without removing the attribtution comments from the code*/
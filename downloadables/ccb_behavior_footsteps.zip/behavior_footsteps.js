// This is a coppercube behavior which plays footsteps sounds when the object it is attached to is moving.
// There are three different footsteps possible, as action slot. Fill it with a 'play sound' action. 
// You can also use this for doing other stuff when a sound is played, like creating a particle system, or similar.
//
// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*
	<behavior jsname="behavior_footsteps" description="Play Footstep Sounds">
		<property name="StepLength" type="float" default="10.0" />
		<property name="MinTimeMs" type="int" default="250" />
		<property name="PlayFootStepSound1" type="action" />
		<property name="PlayFootStepSound2" type="action" />
		<property name="PlayFootStepSound3" type="action" />
	</behavior>
*/

behavior_footsteps = function()
{
	// settings:
	
	this.LastTime = null;
	this.LastPosition = new vector3d(0,0,0);
};


// called every frame. 
//   'node' is the scene node where this behavior is attached to.
//   'timeMs' the current time in milliseconds of the scene.
// Returns 'true' if something changed, and 'false' if not.
behavior_footsteps.prototype.onAnimate = function(n, timeMs)
{	
	var currentPos = ccbGetSceneNodeProperty(n, 'Position');
	if (this.LastPosition == null)
		this.LastPosition = currentPos;
			
	// get the time since the last test

	if (this.LastTime == null)
	{
		this.LastTime = timeMs;
		return false;
	}	
		
	// calculate time delta
	
	var delta = timeMs - this.LastTime;
	if (delta < this.MinTimeMs) return false;
		
	// calculate step delta
	
	var posdelta =  this.LastPosition.substract(currentPos);
	var dist = Math.sqrt(posdelta.x * posdelta.x + posdelta.z * posdelta.z);
	if (dist < this.StepLength)
		return;
		
	this.LastTime = timeMs;	
	this.LastPosition = currentPos;
	
	switch(Math.floor(Math.random() * 1000) % 3)
	{
	case 0: ccbInvokeAction(this.PlayFootStepSound1); break;
	case 1: ccbInvokeAction(this.PlayFootStepSound2); break;
	case 2: ccbInvokeAction(this.PlayFootStepSound3); break;
	}
		
	return false;
}

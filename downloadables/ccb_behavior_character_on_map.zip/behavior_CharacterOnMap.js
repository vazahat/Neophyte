// Script : Follow Main Character On Scene Map
// Created by : Ahmed Abdel-Salam	(Techno-Valley)
// e-mail : a.m.abdelsalam@techno-valley.com || support@letterskingdom.com
// Inspired by Radar Script (Jaime A. Zegpi B.)

/*  <behavior jsname="behavior_CharacterOnMap" description="Follow Main Character On Scene Map">
      <property name="scene_width" type="int" default="1000" description="Maximum Scene Width" />
      <property name="scene_height" type="int" default="1000" description="Maximum Scene Height" />
      <property name="radar_width" type="int" default="20" description="In Percent in relation to the whole scene width on screen" />
      <property name="radar_height" type="int" default="20" description="In Percent in relation to the whole scene width on screen" />
	  <property name="target_character" type="scenenode" description="Select the character to follow on screen" />
      <property name="background_color"	type="color"  default="ffff0000" description="This is the On-Screen Map Background - Default is White" />
	  <property name="player_color"	type="color"  default="ffffffff" description="This is the On-Screen Player Color on Map - Default is White]" />
      <property name="map_texture"	type="string"  default="MAP-NEW.png" description="Select a texture to use as your map" />
    </behavior>
*/

behavior_CharacterOnMap = function()
{
	this.counter = 0;  
};


behavior_CharacterOnMap.prototype.onAnimate = function(node, timeMs){

	this.counter        = this.counter+1;
	
    var v_scene_width  = this.scene_width;		// Set the value of maximum scene width in v_scene_width (v_ means value)
    var v_scene_height = this.scene_height;		// Set the value of maximum scene height in v_scene_height (v_ means value)

	// Get the scene main character name property to plot on the map
	var character_objectname = ccbGetSceneNodeProperty(this.target_character,"Name");
	
    var v_radar_width   = this.radar_width;		// The radar width percentage in proportion to the whole screen width (v_ means value)
    var v_radar_height  = this.radar_height;	// The radar height percentage in proportion to the whole screen height (v_ means value)

	var back_color	= this.background_color;	// Set the map background color	
	var plyr_color = this.player_color;	// Set the player color on map	
	var map	 = this.map_texture;				// Set the map image to use
	
    function ShowOnMap(){
		
      var level_length  = v_scene_height;		// Set the level height used
      var level_width   = v_scene_width;  		// Set the level width used


      var screen_width       = ccbGetScreenWidth();		 // Get the Full Screen Width Resolution in Pixels
      var screen_height      = ccbGetScreenHeight();	 // Get the Full Screen Height Resolution in Pixels
		
	// Calculate the radar width in Pixels
	  var radar_width   = level_width*(v_radar_width/100);
	// Calculate the radar height in Pixels
	  var radar_height  = level_length*(v_radar_height/100);
	// Set the radar top position to left bottom you can change the map location as you wish.
	// Radar Top position = Screen Height Max Resolution - Radar Full Length
      var radar_top     = screen_height - radar_height;
  	// Radar left position = 0 oriented to the left of the screen
      var radar_left    = 0;

	  var root          = ccbGetRootSceneNode();
	  var count         = ccbGetSceneNodeChildCount(root);


//		Draw a square at the target position to act as the map.
// 		The line below draws a colored square relative to the scene terrain (You will have to calculate manually)
	  
//		ccbDrawColoredRectangle(back_color, radar_left-3, radar_top, radar_left + radar_width-3, radar_top + radar_height);
		ccbDrawColoredRectangle(back_color, radar_left-3, radar_top, radar_left + radar_width-3, radar_top + radar_height);

// 		You can also add your custom map drawn in relevance to your scene/environment as well using the below command instead 
// 		add the ccbDrawTextureRectangle command line 
// 		[ without Alpha Channel (No Transparency) ]
// 		or add the ccbDrawTextureRectangleWithAlpha command line
// 		[ with Alpha Channel (With Transparency) ]
		ccbDrawTextureRectangleWithAlpha (map, radar_left-3, radar_top, radar_left + radar_width -3, radar_top + radar_height);	
		//ccbDrawTextureRectangleWithAlpha ("MAP-NEW.png", radar_left -3, radar_top, radar_left + radar_width -3, radar_top + radar_height);	
				
//	 	Uncomment the following line to test with texture.
// 		ccbDrawTextureRectangle ("MAP-NEW.png", radar_left, radar_top, radar_width, w_height);	
//   	Where metalpanel.jpg is the image for your scene from top view for example.



// sc_pos_x : scene position on x axis
// sc_pos_z : scene position on z axis
// plot the character relative position on the map
// The player is shown as a little white square by default if an object was already selected to be followed.
// The square color can be changed from the behaviour properties.
// Square size can be changed sc_pos_x-3 can be sc_pos_x-5 for example (the square will be bigger)
		
			
		var scene_character     = ccbGetSceneNodeFromName(character_objectname);
        var pos                 = ccbGetSceneNodeProperty(scene_character, "Position");
        var sc_pos_x            = (pos.x*-1) * ((radar_width)/(level_width));
		var sc_pos_z            = (pos.z*-1) * ((radar_height)/(level_length));
        var pin_top_left_w      = ((sc_pos_z-3)+(radar_width/2));
		var pin_top_left_h      = ((sc_pos_x-3)+(radar_top+(radar_height/2)));
        var pin_bottom_right_w  = ((sc_pos_z+3)+(radar_width/2));
        var pin_bottom_right_h  = ((sc_pos_x+3)+(radar_top+(radar_height/2)));

		print(pos.x);
		print(pos.z);
		print(sc_pos_x);
		print(sc_pos_z);

		if (sc_pos_x>99) {
		sc_pos_x= 99;
		} 
		
		
		ccbDrawColoredRectangle(plyr_color, pin_top_left_w, pin_top_left_h, pin_bottom_right_w, pin_bottom_right_h);
    }

	if (this.counter==1){
		ccbRegisterOnFrameEvent(ShowOnMap);	
	}
  
}

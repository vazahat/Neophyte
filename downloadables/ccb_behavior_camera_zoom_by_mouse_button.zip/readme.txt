Author: Mio "J0linar" Sejic
Filename: behavior_CameraZoomByMouseButton

Attached to a scene node (multiple ones possible), this will zoom the current active camera if the right mouse button is used.
Speed and minimal and maximal zoom adjustable. It can be used for multiple items, for example googles, cams, weapon zoom.


Note this is based on N.Gebhardts Camera Zoom By MouseWheel

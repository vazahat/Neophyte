// This is a scripted coppercube behavior which performs an action at random intervals.
// If LogarithmicDistribution is enabled, it will simulate the random occurrence of atomic decay.
// Otherwise it will use a linear distribution function, with a much smaller standard deviation.

/*
    <behavior jsname="behavior_DoAtRandomIntervals" description="At random intervals do something">
        <property name="LogarithmicDistribution" type="bool" default="true" />
        <property name="MeanIntervalMs" type="integer" default="5000" />
        <property name="Action" type="action" />
    </behavior>
*/

behavior_DoAtRandomIntervals = function () {
    'use strict';
    this.newInterval = true;
};

behavior_DoAtRandomIntervals.prototype.onAnimate = function (node, timeMs) {
    'use strict';
    if (this.newInterval) {    // We need a new interval...
        this.randomValue = Math.random();
        if (this.LogarithmicDistribution) {    // Use logarithmic distribution to create an interval...
            this.intervalTimer = Math.log(this.randomValue / (1 - this.randomValue) + 1) * this.MeanIntervalMs + timeMs;
        } else {    // Or, use linear distribution to create an interval
            this.intervalTimer = this.randomValue * 2 * this.MeanIntervalMs + timeMs;
        }
        this.newInterval = false;
    }
    if (this.intervalTimer < timeMs) {    // Interval has expired - fire the event and reset.
        ccbInvokeAction(this.Action, node);
        this.newInterval = true;
    }
};
/*	Info 
	
	Extension Name	: Weblinks
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: ‎‎July ‎11, ‎2021, 10:31 PM
	Description		: Open website links in the browser.
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	

*/
/*	Changelog

    [September 02, ‎2021]	- Created the action.
	
*/


/*  
  <action jsname="action_weblinks" description="Open a Website.">
     <property name="Website" type="string" default="https://neophyte.cf"/>
	 <property name="Open_in_same_tab" type="bool" default="false"/>
  </action>
*/

// Constructor
action_weblinks = function(){

}

// Runs this code every time the action is being executed
action_weblinks.prototype.execute = function (node){
	var platform = ccbGetPlatform(); //check the current platform of the game.
	if (platform == "windows"){
	system("explorer "+this.Website,true);  // works in windows platforms only
	}
	else if(platform == "webgl"){
		if(this.Open_in_same_tab)
		{
			window.open(this.Website,"_self"); // works in most browsers.
		}
		else{window.open(this.Website);}
	}
}

/*End*///Author:- Vazahat (just_in_case) //
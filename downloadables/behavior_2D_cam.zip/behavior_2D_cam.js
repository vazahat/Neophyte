//2D Camera script behavior Extension for Coppercube 3D Developed by ****Vazahat Pathan**** AKA ****just_in_case****//
//downloaded from **** https://neophyte.cf ****
/*
	<behavior jsname="behavior_2D_cam" description="2D camera script">
		<property name="Player" type="scenenode" />
		<property name="Camera" type="scenenode" />
		<property name="Stop_Camera_left_at" type="int" default="544" />
		<property name="Stop_Camera_up_at" type="int" default="0" />
		<property name="Z_Forward" type="bool" default="false" description="If player Forward is on Z axis" />
		<property name="X_Forward" type="bool" default="true" description="If player Forward is on X axis" />
	</behavior>
*/
behavior_2D_cam = function () {
    'use strict';
};

behavior_2D_cam.prototype.onAnimate = function ( node, timeMs) {
    'use strict';
//create here a camera script so that our camera will move according to our player//

//get player ,camera,and camera target positions//
var camera = this.Camera;
var target = ccbGetSceneNodeProperty(camera, "Target");
var player = this.Player;
var player_pos = ccbGetSceneNodeProperty(player, "Position");
var camera_pos = ccbGetSceneNodeProperty(camera, "Position");
var move_right = ccbGetCopperCubeVariable("#!@move_right");
var move_up = ccbGetCopperCubeVariable("#!@move_up");

if(this.Z_Forward == true)
{	
	//Check & compare Player and camera target positions to make the camera move right//

	if (player_pos.z < target.z)
		{target.z = player_pos.z;
		camera_pos.z = player_pos.z;
		ccbSetSceneNodeProperty (camera, "Position",camera_pos.x,camera_pos.y,camera_pos.z);
		ccbSetSceneNodeProperty(camera, "Target",target.x,target.y,target.z);
		ccbSetCopperCubeVariable("#!@move_right",1);}

	////Check & compare Player and camera target positions to make the camera move Left and stop movement or reaching a certain point//

	if (move_right == 1)
		{if (player_pos.z > target.z)
				{target.z = player_pos.z;
				camera_pos.z = player_pos.z;
				ccbSetSceneNodeProperty (camera, "Position",camera_pos.x,camera_pos.y,camera_pos.z);
				ccbSetSceneNodeProperty(camera, "Target",target.x,target.y,target.z);}
				if (player_pos.z >= this.Stop_Camera_left_at)
						{ccbSetCopperCubeVariable("#!@move_right",0);}}

}


if(this.X_Forward == true)
{	
	//Check & compare Player and camera target positions to make the camera move right//

	if (player_pos.x < target.x)
		{target.x = player_pos.x;
		camera_pos.x = player_pos.x;
		ccbSetSceneNodeProperty (camera, "Position",camera_pos.x,camera_pos.y,camera_pos.z);
		ccbSetSceneNodeProperty(camera, "Target",target.x,target.y,target.z);
		ccbSetCopperCubeVariable("#!@move_right",1);}

	////Check & compare Player and camera target positions to make the camera move Left and stop movement or reaching a certain point//

	if (move_right == 1)
		{if (player_pos.x > target.x)
				{target.x = player_pos.x;
				camera_pos.x = player_pos.x;
				ccbSetSceneNodeProperty (camera, "Position",camera_pos.x,camera_pos.y,camera_pos.z);
				ccbSetSceneNodeProperty(camera, "Target",target.x,target.y,target.z);}
				if (player_pos.x >= this.Stop_Camera_left_at)
						{ccbSetCopperCubeVariable("#!@move_right",0);}}

}



//Check & compare Player and camera target height to make the camera move up and stop movement for certain height//

if (player_pos.y  < target.y-88)
     {target.y = player_pos.y+88;
      camera_pos.y = player_pos.y+88;
      ccbSetSceneNodeProperty (camera, "Position",camera_pos.x,camera_pos.y,camera_pos.z);
      ccbSetSceneNodeProperty(camera, "Target",target.x,target.y,target.z);
      ccbSetCopperCubeVariable("#!@move_up",1);}

//Check & compare Player and camera target height to make the camera move down//

if (move_up == 1)
     {if (player_pos.y  > target.y-88)
            {target.y = player_pos.y+80;
             camera_pos.y = player_pos.y+80;
             ccbSetSceneNodeProperty (camera, "Position",camera_pos.x,camera_pos.y,camera_pos.z);
             ccbSetSceneNodeProperty(camera, "Target",target.x,target.y,target.z);}
              if (player_pos.y >= this.Stop_Camera_up_at)
                    {ccbSetCopperCubeVariable("#!@move_up",0);}}
	
};

//Author of the behaviour :- Vazahat Pathan aka Just_in_case!
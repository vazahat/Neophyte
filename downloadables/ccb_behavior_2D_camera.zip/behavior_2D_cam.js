/*	Info 
	
    Extension Name	: Behavior 2D Camera( Platformer and RTS)
    Extension Type	: Behavior
    Author:			: Vazahat Khan (just_in_case)
    Date Created	: v1.2  on june 09, 2022, 06:12
    Description		: Allows you to create a 2D camera Controller. 
	
*/
/* 	Donate
	
    If you like my work, please consider "buy me a cup of coffee" to support me.
    You can do that via PayPal :)
	
    PayPal: http://paypal.me/Vazahat
    Itch.io - https://vazahat.itch.io/cc-shader-spritesheet-animation
    Youtube - https://www.youtube.com/channel/UC_yfoGEKkmY63tnyy6hR7ZQ
    Website - https://neophyte.cf
    Discord - https://discord.gg/RKcq89S7uA
	

*/
/*	Changelog

    [June 09, 2022]		- Copied base behavior
                        - Tried updating the old version by modifying it with little changes .
						- Decide to rewrite whole code from scratch
						- Added platformer camera type where the camera follows a player
						- Added Smooth movement for camera Controller
						- Fixed quite a few bugs that were encountered while developing
	[June 10, 2022]		- Added some general parameters to the action.
						- Added X forward or Z forward option for XY and ZY axis based games
						- Added Stop camera for all left,right,up,down Direction
                        - Fixed some other bugs and cleaned out the code a bit
                        - Added Zoom with mouse scroll
						- Wasted hours fixing some bugs with Zoom Scroll mechanism, Tried many and then left it with bugs
						- Added ability for the RTS mode instead of platformer camera type
						- Added ability to specify RTS boundary so that the camera can be moved in a virtual boundary
						- Added RTS camera speed and respective parameters to the behavior
	[June 11, 2022]		- Fixed bugs with the Zoom functionality
						- Fixed a lot of other bugs within the whole code for both X-Forward and Z-Forward axis
						- Added Zoom Scroll and max zoom in and max zoom out functionality and their respective parameters
						- Fixed more bugs in the whole code that was arouse due to the Zooming ability
						- Fixed Bug for Z-forward Zooming
	[June 14, 2022]		- Added TDS( top down shooter)/RPG mode to camera
	[June 17, 2022]		- Fixed Zoom mode for RPG/TDS camera


	[To Do for v1.3]	- Add more camera modes {easy}
						- Add Keyboard Controls for RTS camera {easy}
						

*/


/*
	<behavior jsname="behavior_2D_cam" description="2D Platformer and RTS Camera Controller Type">
		<property name="TDS_Style_Camera" type="bool" default="false" />
		<property name="RTS_Style_Camera" type="bool" default="false" />
		<property name="Platformer_Style_Camera" type="bool" default="false" />
		<property name="Player" type="scenenode" />
		<property name="Z_Forward" type="bool" default="false" description="If player Forward is on Z axis" />
		<property name="X_Forward" type="bool" default="true" description="If player Forward is on X axis" />
		<property name="Camera_Smoothing" type="int" default="0.9" />
		<property name="Stop_Camera_left_at" type="int" default="1000" />
		<property name="Stop_Camera_right_at" type="int" default="1000" />
		<property name="Stop_Camera_up_at" type="int" default="1000" />
		<property name="Stop_Camera_down_at" type="int" default="1000" />
		<property name="RTS_distance_from_boundary" type="int" default="50" />
		<property name="RTS_Cam_Speed" type="int" default="5" />
		<property name="Enable_Zoom_Scroll" type="bool" default="false" />
		<property name="Zoom_Scroll_distance" type="int" default="50" />
		<property name="MAX_Zoom_out_distance" type="int" default="50" />
		<property name="MAX_Zoom_in_distance" type="int" default="50" />
		

	</behavior>
*/
behavior_2D_cam = function () {
};

behavior_2D_cam.prototype.onAnimate = function ( node, timeMs) {
this.Camera = node;
//get player ,camera,and camera target  and other positions//
var target = ccbGetSceneNodeProperty(this.Camera, "Target");
var player_pos = ccbGetSceneNodeProperty(this.Player, "Position");
var camera_pos = ccbGetSceneNodeProperty(this.Camera, "Position");
var mouseX = ccbGetMousePosX();
var mouseY = ccbGetMousePosY();
var screenX = ccbGetScreenWidth();
var screenY = ccbGetScreenHeight();
// FiX Camera smoothing
if(this.Camera_Smoothing >= 0.99){this.Camera_Smoothing = 0.99}

// For RTS Camera Mode

if(this.RTS_Style_Camera)
{
// If game is created on XY axis
		if(this.X_Forward) 
		{	
			//on moving right
			if(target.x > this.Stop_Camera_right_at-1 ){}
			else
			{
				if(mouseX > screenX-this.RTS_distance_from_boundary)
				{
					target.x = Lerp(target.x+(this.RTS_Cam_Speed*100),target.x,0.98)
				}
			};
			// on moving left
			if(target.x < -this.Stop_Camera_left_at+1){}
			else
			{
				if(mouseX < 0+this.RTS_distance_from_boundary)
				{ 
					target.x = Lerp(target.x-(this.RTS_Cam_Speed*100),target.x,0.98)
				}
			};
			// on moving down
			if(target.y < -this.Stop_Camera_down_at+2){}
			else
			{
				if(mouseY > screenY-this.RTS_distance_from_boundary)
				{
					target.y = Lerp(target.y-(this.RTS_Cam_Speed*100),target.y,0.98)
				}
			};
			// on moving up
			if(target.y > this.Stop_Camera_up_at-2 ){}
			else
			{
				if(mouseY < 0+this.RTS_distance_from_boundary)
				{ 
					target.y = Lerp(target.y+(this.RTS_Cam_Speed*100),target.y,0.98)
				}
			};
			ccbSetSceneNodeProperty (this.Camera, "Position",target.x,target.y,camera_pos.z);
			ccbSetSceneNodeProperty(this.Camera, "Target",target.x,target.y,player_pos.z);
		};

//if game is created on ZY axis
		if(this.Z_Forward) 
		{	
			//Check & compare Player and camera target positions to make the camera move right//

			//on moving right
			if(target.z > this.Stop_Camera_right_at-1 ){}
			else
			{
				if(mouseX > screenX-this.RTS_distance_from_boundary)
				{
					target.z = Lerp(target.z+(this.RTS_Cam_Speed*100),target.z,0.98)
				}
			};
			// on moving left
			if(target.z < -this.Stop_Camera_left_at+1){}
			else
			{
				if(mouseX < 0+this.RTS_distance_from_boundary)
				{ 
					target.z = Lerp(target.z-(this.RTS_Cam_Speed*100),target.z,0.98)
				}
			};
			// on moving down
			if(target.y < -this.Stop_Camera_down_at+2 ){}
			else
			{
				if(mouseY > screenY-this.RTS_distance_from_boundary)
				{
					target.y = Lerp(target.y-(this.RTS_Cam_Speed*100),target.y,0.98)
				}
			};
			// on moving up
			if(target.y > this.Stop_Camera_up_at-2 ){}
			else
			{
				if(mouseY < 0+this.RTS_distance_from_boundary)
				{ 
					target.y = Lerp(target.y+(this.RTS_Cam_Speed*100),target.y,0.98)
				}
			};
			ccbSetSceneNodeProperty (this.Camera, "Position",camera_pos.x,target.y,target.z);
			ccbSetSceneNodeProperty(this.Camera, "Target",player_pos.x,target.y,target.z);
		}
}
// For Platformer Player chasing Camera mode
else if(this.Platformer_Style_Camera){
	if(this.X_Forward)
	{	
		if(player_pos.x > this.Stop_Camera_right_at || player_pos.x < -this.Stop_Camera_left_at ){}
		else{target.x = Lerp(player_pos.x,target.x, this.Camera_Smoothing);}
		if(player_pos.y > this.Stop_Camera_up_at || player_pos.y < -this.Stop_Camera_down_at){}
		else{target.y = Lerp(player_pos.y,target.y, this.Camera_Smoothing);}
		ccbSetSceneNodeProperty (this.Camera, "Position",target.x,target.y,camera_pos.z);
		ccbSetSceneNodeProperty(this.Camera, "Target",target.x,target.y,player_pos.z);
	}
	if(this.Z_Forward)
	{	
		if(player_pos.z > this.Stop_Camera_right_at || player_pos.z < -this.Stop_Camera_left_at ){}
		else{target.z = Lerp(player_pos.z,target.z, this.Camera_Smoothing);}
		if(player_pos.y > this.Stop_Camera_up_at || player_pos.y < -this.Stop_Camera_down_at){}
		else{target.y = Lerp(player_pos.y,target.y, this.Camera_Smoothing);}	
		ccbSetSceneNodeProperty (this.Camera, "Position",camera_pos.x,target.y,target.z);
		ccbSetSceneNodeProperty(this.Camera, "Target",player_pos.x,target.y,target.z);
	}
}
// For RPG/TDS chasing Camera mode
else if (this.TDS_Style_Camera){
	
		if(player_pos.x > this.Stop_Camera_right_at || player_pos.x < -this.Stop_Camera_left_at ){}
		else{target.x = Lerp(player_pos.x,target.x, this.Camera_Smoothing);}
		if(player_pos.z > this.Stop_Camera_up_at || player_pos.z < -this.Stop_Camera_down_at){}
		else{target.z = Lerp(player_pos.z,target.z, this.Camera_Smoothing);}
		ccbSetSceneNodeProperty (this.Camera, "Position",target.x,camera_pos.y,target.z);
		ccbSetSceneNodeProperty(this.Camera, "Target",target.x,player_pos.y,target.z);
	
}
if(this.MAX_Zoom_in_distance <= 25){this.MAX_Zoom_in_distance = 25}; // Don't Allow Zooming more than 25 ( minimimum Zoom in should be 25)

};

//Mouse Events

// ZOOM Controller  
behavior_2D_cam.prototype.onMouseEvent = function(mouseEvent, mouseWheelDelta)
{
	
//get player ,camera,positions//
var player_pos = ccbGetSceneNodeProperty(this.Player, "Position");
var camera_pos = ccbGetSceneNodeProperty(this.Camera, "Position");
	if(this.Enable_Zoom_Scroll)
	{
		// ZOOM if game is created on XY axis
		if(this.X_Forward)
		{
			if(mouseWheelDelta == 1){if(camera_pos.z >= player_pos.z-this.MAX_Zoom_in_distance){} else{camera_pos.z = Lerp(camera_pos.z+this.Zoom_Scroll_distance,camera_pos.z,0.9)};ccbSetSceneNodeProperty (this.Camera, "Position",camera_pos.x,camera_pos.y,camera_pos.z);}
			if(mouseWheelDelta == -1){if(camera_pos.z <= player_pos.z-this.MAX_Zoom_out_distance){} else{camera_pos.z = Lerp(camera_pos.z-this.Zoom_Scroll_distance,camera_pos.z,0.9)};ccbSetSceneNodeProperty (this.Camera, "Position",camera_pos.x,camera_pos.y,camera_pos.z);}
		}
		//ZOOM if game is created on ZY axis
		if(this.Z_Forward)
		{
			if(mouseWheelDelta == 1){if(camera_pos.x <= player_pos.x+this.MAX_Zoom_in_distance){} else{camera_pos.x = Lerp(camera_pos.x-this.Zoom_Scroll_distance,camera_pos.x,0.9)};ccbSetSceneNodeProperty (this.Camera, "Position",camera_pos.x,camera_pos.y,camera_pos.z);}
			if(mouseWheelDelta == -1){if(camera_pos.x >= player_pos.x+this.MAX_Zoom_out_distance){} else{camera_pos.x = Lerp(camera_pos.x+this.Zoom_Scroll_distance,camera_pos.x,0.9)};ccbSetSceneNodeProperty (this.Camera, "Position",camera_pos.x,camera_pos.y,camera_pos.z);}
		}
		//ZOOM if RPG/TDS camera
		if(this.TDS_Style_Camera)
		{
			if(mouseWheelDelta == 1){if(camera_pos.y <= player_pos.y+this.MAX_Zoom_in_distance){} else{camera_pos.y = Lerp(camera_pos.y-this.Zoom_Scroll_distance,camera_pos.y,0.9)};ccbSetSceneNodeProperty (this.Camera, "Position",camera_pos.x,camera_pos.y,camera_pos.z);}
			if(mouseWheelDelta == -1){if(camera_pos.y >= player_pos.y+this.MAX_Zoom_out_distance){} else{camera_pos.y = Lerp(camera_pos.y+this.Zoom_Scroll_distance,camera_pos.y,0.9)};ccbSetSceneNodeProperty (this.Camera, "Position",camera_pos.x,camera_pos.y,camera_pos.z);}
		}
	}	
}

function Lerp(plyr, trgt, amt){
    return (1 - amt) * plyr + amt * trgt;
}

// ***Author:- VAZAHAT PATHAN***

//        ****AKA****

 //   ****Just_in_case**** 

 // Above extension is written by Vazahat Khan (just_in_case) //
//You are not allowed to remove this License info or any attribution details//
//License info:-//
/* All rights are reserved to Vazahat Khan.
You are allowed to use this asset( code ) in your coppercube projects freely for commercial and personal use without removing the attribtution comments from the code*/

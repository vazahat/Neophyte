//=======================================
// This is a CopperCube behavior which enables a customizable scanlines effect to your scenes. The following params can be adjusted:
//=======================================
// UseTexture: instead of CopperCube's built-in 100% opaque DrawRectangle function use a semi-transparent image texture to decrease the effect
// HTextureFileName -> horizontal image texture for scanlines -> set file name
// VTextureFileName -> vertical image texture for scanlines -> set file name 
//=======================================
// Horizontal: toggle horizontal scanlines
// Vertical: toggle vertical scanlines
//=======================================
// In addition the scanlines effect can be customized by adjusting "Width", "Spacing" and/or "Color" for vertical/horizontal lines individually.
//=======================================
// -----> by CopperCube forum member hadoken 2022, slightly modded and updated by Vazahat (just_in_case) with color transparency 2023 <----- 
//updated version 2023-06-21: added CopperCube variable "HadokenScanlinesFX" to switch scanlines fx on/off
/*
	<behavior jsname="behavior_HadokenScanlinesFX" description="behavior_HadokenScanlinesFX">
		<property name="UseTexture" type="bool" default="false" />
		<property name="HTextureFileName" type="string" default="" />
		<property name="VTextureFileName" type="string" default="" />			
		<property name="Horizontal" type="bool" default="true" />
		<property name="Vertical" type="bool" default="false" />		
		<property name="HSpacing" type="int" default="3" />
		<property name="HWidth" type="int" default="1" />
		<property name="VSpacing" type="int" default="3" />
		<property name="VWidth" type="int" default="1" />
		<property name="HColor" type="color" default="77000000" />
		<property name="VColor" type="color" default="77000000" />
		<property name="HAlpha" type="float" default="100" />
		<property name="VAlpha" type="float" default="100" />
		<property name="StartWithFX" type="bool" default="true" />
	</behavior>
*/

behavior_HadokenScanlinesFX = function()
{
	this.init_ccvar = 0;
	this.init_scanlines = 0;
	HadokenScanlinesFX = 0;
}

behavior_HadokenScanlinesFX.prototype.onAnimate = function()
{
	if(this.init_ccvar == 0)
	{
		if(this.StartWithFX == true) ccbSetCopperCubeVariable("HadokenScanlinesFX", 1);
		if(this.StartWithFX == false) ccbSetCopperCubeVariable("HadokenScanlinesFX", 0);
		this.init_ccvar = 1;
	}
	
	if(ccbGetCopperCubeVariable("HadokenScanlinesFX") == 0)	HadokenScanlinesFX = 0;
	if(ccbGetCopperCubeVariable("HadokenScanlinesFX") == 1 && HadokenScanlinesFX == 0) HadokenScanlinesFX = 1;
	
	ScreenWidth = ccbGetScreenWidth();
	ScreenHeight = ccbGetScreenHeight();

	ScanlinesFX_UseTexture = this.UseTexture;
	ScanlinesFX_HTextureFileName = this.HTextureFileName;
	ScanlinesFX_VTextureFileName = this.VTextureFileName;		
	ScanlinesFX_Vertical = this.Vertical;
	ScanlinesFX_Horizontal = this.Horizontal;
	ScanlinesFX_HSpacing = this.HSpacing;
	ScanlinesFX_HWidth = this.HWidth;	
	ScanlinesFX_VSpacing = this.VSpacing;
	ScanlinesFX_VWidth = this.VWidth;	
	//Added by Vazahat (just_in_case) fro color transparency
	ScanlinesFX_HColor = RGB(this.HColor);
	ScanlinesFX_VColor = RGB(this.VColor);
	ScanlinesFX_HColor = color(ScanlinesFX_HColor.x,ScanlinesFX_HColor.y,ScanlinesFX_HColor.z,this.HAlpha);
	ScanlinesFX_VColor = color(ScanlinesFX_VColor.x,ScanlinesFX_VColor.y,ScanlinesFX_VColor.z,this.VAlpha);

	ScanlinesFX_TextureFileName = this.TextureFileName;

	function onFrameDrawing()
	{
	 	if(HadokenScanlinesFX >= 1)
	 	{	
			for(var i=0; i<ScreenWidth*0.6; ++i)
			{			
				if(ScanlinesFX_UseTexture == false) 
				{
					if(ScanlinesFX_Horizontal == true)				
					{	ccbDrawColoredRectangle(ScanlinesFX_HColor, 0, 
						i*ScanlinesFX_HSpacing, ScreenWidth, i*ScanlinesFX_HSpacing+ScanlinesFX_HWidth);
					}
				}
				else 
				{	
					if(ScanlinesFX_Horizontal == true)				
					{	ccbDrawTextureRectangleWithAlpha(ScanlinesFX_HTextureFileName, 0,
						i*ScanlinesFX_HSpacing, ScreenWidth, i*ScanlinesFX_HSpacing+ScanlinesFX_HWidth);
					}
				}
			}
			
			for(var j=0; j<ScreenWidth*0.6; ++j)
			{			
				if(ScanlinesFX_UseTexture == false) 
				{
					if(ScanlinesFX_Vertical == true)
					{	
						ccbDrawColoredRectangle(ScanlinesFX_VColor, j*ScanlinesFX_VSpacing, 0,
						j*ScanlinesFX_VSpacing+ScanlinesFX_VWidth, ScreenHeight);
					}
				}
				else 
				{	
					if(ScanlinesFX_Vertical == true)
					{
						ccbDrawTextureRectangleWithAlpha(ScanlinesFX_VTextureFileName, j*ScanlinesFX_VSpacing, 0,
						j*ScanlinesFX_VSpacing+ScanlinesFX_VWidth, ScreenHeight);
					}
				}
			}
	 	}
	}
	
	if(HadokenScanlinesFX == 1)
	{
		ccbRegisterOnFrameEvent(onFrameDrawing);
		HadokenScanlinesFX = 2;
	}
	
	if(HadokenScanlinesFX == 0) 
	{
		ccbUnregisterOnFrameEvent(onFrameDrawing)
	}
}

//Added by Vazahat ( just_in_case) for Color Transparency 
// Fixing the Color Property type Parameter of action to get RGB value and clamp them between 0 and 1.
function RGB(decimalcolorcode)
{var color = (decimalcolorcode); // use the property type or put a  decimal color value.
 var Rr = (color & 0xff0000) >> 16; // get red color by bitwise operation  
 var Gg = (color & 0x00ff00) >> 8; // get green color by bitwise operation 
 var Bb = (color & 0x0000ff); // get blue color by bitwise operation 
 var RrGgBb = new vector3d(Rr,Gg,Bb);
 var r = (Rr/255); // dividing red by 255 to clamp b/w 0-1 
 var g = (Gg/255); // dividing green by 255 to clamp b/w 0-1 
 var b = (Bb/255); // dividing blue by 255 to clamp b/w 0-1 
 var rgb = new vector3d (r,g,b); // final rgb value to use in the editor
 return rgb;
 }

 function color(r,g,b,alpha)
{
    var r =  toHexcol(r); // get hex value for red
    var g = toHexcol(g); // get hex value for green
    var b = toHexcol(b); //get hex value for blue
    var color = (alpha<<24) | ( "0x00"+r+g+b & 0x00ffffff); //return color with alpha transparency correction using bitwise operation
    return color;
};

//Conversion of rgb to hex color
function toHexcol(rgb)
{
     var hexColor = rgb.toString(16); //convert rgb color to string value
     while (hexColor.length < 2) {hexColor = "0" + hexColor; } //get hex color from rgb string
     return hexColor;
}


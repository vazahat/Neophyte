/*	Info 
	
	Extension Name	: Shader Action Fog_fix_Skybox
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: ‎‎July ‎23, ‎2021, 09:06 AM
	Description		: Turn off fog for skybox and other objects.. 
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	

*/
/*	Changelog

    [July 23, ‎2021]	- Modified previous shaders to create this one

	
*/



/* Usage
  Attach the action to a behavior and select the skybox, that's it.
  
 */

/*  <action jsname="action_fog_fix" description="No Fog for Skybox and other object">
	  <property name="No_Fog_Object" type="scenenode"/>
	  <property name="Base_Material" type="int"/>
	  
    </action>
*/
action_fog_fix = function()
{

};

action_fog_fix.prototype.execute = function()
{	
//Shader Part
var vertexShader = 
"		float4x4 mWorldViewProj;  // World * View * Projection 					\n" + 
"		float4x4 mTransWorld;     // Transposed world matrix					\n" +
"		float4x4 mInvWorld;       // Inverted world matrix	 					\n" + 
"		// Output to fragment program V2F										\n" + 
"		struct VS_OUTPUT														\n" + 
"		{																		\n" + 
"			float4 Position   : POSITION;   // vertex position 					\n" + 
"			float4 Texcoord   : TEXCOORD;   // vertex position 					\n" + 
"		};																		\n" + 
"																				\n" + 
"			//Input From app to vertex program A2V								\n" + 
"		VS_OUTPUT main      ( in float4 vPosition : POSITION,					\n" +
"							  in float4 Texcoord : TEXCOORD)					\n" +
"		{																		\n" + 
"			//Vertex Shader														\n" + 
"			VS_OUTPUT Output;													\n" + 
"			Output.Position = mul(vPosition, mWorldViewProj);					\n" + 
"			Output.Texcoord = Texcoord;											\n" + 
"			return Output;														\n" + 
"		}";

var fragmentShader = 
"		struct PS_OUTPUT																\n" + 
"		{																				\n" + 
"		    float4 RGBColor : COLOR; 		  											\n" +	
"		};																				\n" + 
"		sampler2D tex0;																	\n" +
"		PS_OUTPUT main( float4 Texcoord: TEXCOORD)										\n" +
"		{ 																				\n" +
"			PS_OUTPUT Output;															\n" +
"			float4 mainColor = tex2D(tex0, Texcoord);									\n"	+
"			Output.RGBColor =  mainColor;												\n" + 
"			return Output;																\n" +
"}";
	

// creating Material
var newMaterial = ccbCreateMaterial(vertexShader, fragmentShader,this.Base_Material);
//Check Material index and apply to sepcifed mat index or to all the materials.
var matCount = ccbGetSceneNodeMaterialCount(this.No_Fog_Object);

for(var i=0; i<matCount; ++i)
{
	ccbSetSceneNodeMaterialProperty(this.No_Fog_Object, i, 'Type', newMaterial);
}

}
 
 /*End Of Code*/
 
 
// Above extension is written by Vazahat Khan (just_in_case) //
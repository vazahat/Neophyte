// The following is a scripted behaviour for "CopperCube 3D".
//The Behaviour Provides an option to CopperCube Users, This behaviour provides an option to add "Animation Effect to Static Text of 2D Overlays" to CopperCube Projects.
//This Behaviour is Created by a non-Programmer:- Vazahat Pathan.
/*
	<behavior jsname="behavior_TextAnimation" description="Text Animation">
		<property name="Text" type="string" value="text" />
		<property name="SceneNode" type="scenenode" />
        <property name="Speed" type="integer" default="100"  />
	</behavior>
*/
behavior_TextAnimation = function () {
    'use strict';
    this.ReSpeed = true;
};

behavior_TextAnimation.prototype.onAnimate = function ( node, timeMs) { // to Controll Speed, animation of text 
    'use strict';
    if (this.ReSpeed) {    
        this.randomValue = Math.random();
        this.speedTimer =  this.Speed + timeMs;       
        this.ReSpeed = false;
    }
	// Variables and properties items
	var message = this.Text;
	this.result = message.charAt(0);
	this.variable = ccbGetCopperCubeVariable('!@#&*variable');
	this.index = this.variable;
	this.overlay = this.SceneNode;
	
    if (this.speedTimer < timeMs) {    //Printing/animating String Characters at 2d Overlay
		this.index++;
		this.ReSpeed = true;
		ccbSetCopperCubeVariable('!@#&*variable', this.index);
		this.value = this.variable; 
		this.result = message.charAt(this.value);
		this.effect = message.slice(0,this.value);
		this.message = this.Text;
		ccbSetSceneNodeProperty(this.overlay, 'Draw Text', true);
		ccbSetSceneNodeProperty(this.overlay, 'Text', this.effect);
		this.ReSpeed = true;     
    }
	
};

//AUTHOR: VAZAHAT PATHAN aka Just_in_Case.....
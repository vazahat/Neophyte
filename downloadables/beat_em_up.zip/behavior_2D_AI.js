// This is a coppercube behavior which moves the node it is attached to only on the x axis,
// controlled by the cursor keys and with space for 'jump'.
//
// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*
	<behavior jsname="behavior_2D_AI" description="Simple beat em up AI">
		<property name="EnemyName" type="string" default="Kazuya" />
		<property name="Animated" type="scenenode"/>
		<property name="Speed" type="float" default="0.2" />
		<property name="Attack_on_node" type="scenenode"/>
		<property name="Health" type="int" default="100" />
		<property name="Punch_damage" type="int" default="10" />
		<property name="Kick_damage" type="int" default="10" />
		<property name="Activation_radius" type="int" default="200" />
		<property name="Chase_radius" type="int" default="200" />
		<property name="Fight_distance" type="int" default="70" />
		<property name="hitFx" type="scenenode"/>
		<property name="hitSound" type="string" default= "Audio/PunchHit1.wav"/>
	</behavior>
*/

behavior_2D_AI = function()
{
	this.LastTime = null;
	this.activation  = false;
	this.deathtimeR = 1;
	this.angle = 0;
	this.deathlooper = 1;
	this.currentAnimation = "" ; // just for defining, doesn't need to actually contain an animation name, can be just false
};

// called every frame. 
//   'node' is the scene node where this behavior is attached to.
//   'timeMs' the current time in milliseconds of the scene.
// Returns 'true' if something changed, and 'false' if not.
behavior_2D_AI.prototype.onAnimate = function(node, timeMs)
{
		
	
	 
	// get the time since the last frame
	
	if (this.LastTime == null)
	{
		this.LastTime = timeMs; // we were never called before, so store the time and cancel
		this.InitPos = ccbGetSceneNodeProperty(node, 'Position');// store the default Position of the player to alter it in different situations.
		this.InitRotation = ccbGetSceneNodeProperty(node, 'Rotation');// store the default rotation of the player to alter it in different situations.
		this.InitSpeed = this.Speed; // store the default speed of the player to alter it in different situations.
		this.currentNode = node;
		return false;
	}
	
	this.NewRotation = ccbGetSceneNodeProperty(node, 'Rotation');	//get the new rotation to stop player from rotating if up and down arrow keys are pressed.
	var animation = this.currentAnimation; // get the current animation of the player to compare in different situations.
	this.LastNodeUsed = node;
	var timeDiff = timeMs - this.LastTime;
	this.LastTime = timeMs;
	if (timeDiff > 200) timeDiff = 200;
	var directionForward = new vector3d(0.0,0.0,0.0);
	var lengthToGo = 0.0;
	this.bMovingForward = false;
	var pos = ccbGetSceneNodeProperty(node, 'Position');
	var posb = ccbGetSceneNodeProperty(node, "Position");
	var TargetPos = ccbGetSceneNodeProperty(this.Attack_on_node,"Position");
	var nodename = ccbGetSceneNodeProperty(node,"Name");
	this.Enemyhit = {LK: ccbGetCopperCubeVariable(nodename+"hit_LK") , RK:ccbGetCopperCubeVariable(nodename+"hit_RK"), LP: ccbGetCopperCubeVariable(nodename+"hit_LP"), RP:ccbGetCopperCubeVariable(nodename+"hit_RP")} ;
	this.enemy_status = ccbGetCopperCubeVariable(nodename+".status");
	this.enemy_damage_taken = ccbGetCopperCubeVariable("enemy_damage");
	

	if(this.enemy_status != "dead"){
	if (this.TargetPosition != null)
	{
		directionForward = this.TargetPosition.substract(pos);
		lengthToGo = directionForward.getLength();
		this.bMovingForward = lengthToGo > (this.Speed * 200);
		
		//Applying Rotation to the AI according to the target position(player position).
		if (this.bMovingForward)
		{
			var angley = Math.atan2(directionForward.x, directionForward.z) * (180.0 / 3.14159265358);

			if (angley < 0.0) angley += 360.0;
			if (angley >= 360.0) angley -= 360.0;
						
			ccbSetSceneNodeProperty(node, 'Rotation', 0.0, angley+90, 0.0); //+90 is the additional rotation for our AI player we need to alter(change) it if the AI shows wrong rotation.
		}
		
	}
	//movement scripts
	if (this.bMovingForward)
		{
			var speed = this.Speed * timeDiff;
			directionForward.normalize();
			pos.x += directionForward.x * speed;
			pos.y += directionForward.y * speed;
			pos.z += directionForward.z * speed;
		}
	if (this.bMovingForward && this.Enemyhit.LK != "true" && this.Enemyhit.RK != "true" && this.Enemyhit.LP != "true" && this.Enemyhit.RP != "true")
		{
			ccbSetSceneNodeProperty(this.Animated, 'Animation', 'walk');
		}
	if (!this.bMovingForward) // if AI is not moving(walking)
		{	
			rdirectionForward = TargetPos.substract(pos);
			var angley = Math.atan2(rdirectionForward.x, rdirectionForward.z) * (180.0 / 3.14159265358);
			
			if (angley < 0.0) angley += 360.0;
			if (angley >= 360.0) angley -= 360.0;
						
			ccbSetSceneNodeProperty(node, 'Rotation', 0.0, angley+90, 0.0);//change the rotation of the AI according to the player pos
			
			//changing animations of AI according to situations
			if (this.Enemyhit.LK == "true" || this.Enemyhit.RK == "true" || this.Enemyhit.LP == "true" || this.Enemyhit.RP == "true") //checking variables
			{
				ccbSetSceneNodeProperty(this.Animated,'Animation','hit'); // play hit animation if AI gets hit based on CC variable.
			}
			else
			if (pos.x <= TargetPos.x-170 || pos.x >= TargetPos.x+170) //play idle animation if AI has nothing to do.
			{
				ccbSetSceneNodeProperty(this.Animated, 'Animation', 'idle');	
			}
		
			else
			if (this.Health <= 0)
			{
				ccbSetSceneNodeProperty(this.Animated, 'Animation', 'death');//play death Animation if AI is dead
				ccbSetCopperCubeVariable(nodename+".status","dead");
				ccbPlaySound("Audio/ButtonPress.wav");
				
			}
			else
			{
				
				if(this.randomAttack == undefined){if(timeMs % 25 == 0){this.randomAttack = Math.floor((Math.random() * 6) + 1);}this.attacktimeR = 1};
				
				if(this.attacktimeR >= 150)
				{
					if(animation == "punch"){this.randomAttack = Math.floor((Math.random() * 6) + 1);this.attacktimeR = 1};
					
				};
				if(this.attacktimeR >= 75)
				{
					if(animation == "kick"){this.randomAttack = Math.floor((Math.random() * 6) + 1);this.attacktimeR = 1};
					
				};
				if(this.attacktimeR >= 50)
				{
					if(animation == "idle"){this.randomAttack = Math.floor((Math.random() * 6) + 1);this.attacktimeR = 1};
				};
				if(this.attacktimeR >= 10)
				{
					if(animation == "walk"){this.randomAttack = Math.floor((Math.random() * 6) + 1);this.attacktimeR = 1};
				};
				
				if(this.randomAttack == 3){ccbSetSceneNodeProperty(this.Animated, 'Animation', 'punch');ccbSetCopperCubeVariable("player_damage",this.Punch_damage);this.attacktimeR ++}
				else if(this.randomAttack == 2 || this.randomAttack == 5){ccbSetSceneNodeProperty(this.Animated, 'Animation', 'idle');this.attacktimeR ++}
				else if(this.randomAttack == 1){ccbSetSceneNodeProperty(this.Animated, 'Animation', 'kick');ccbSetCopperCubeVariable("player_damage",this.Kick_damage);this.attacktimeR ++}
				else if(this.randomAttack == 4 || this.randomAttack == 6)
				{
				if (TargetPos.x < posb.x)		//make AI move closer to the player to perform the attack sucessfully.
				{
					ccbSetSceneNodeProperty(this.currentNode,"Position",posb.x+1,posb.y,posb.z);
					this.TargetPosition = new vector3d(TargetPos.x+this.Fight_distance+1,TargetPos.y,TargetPos.z);
					this.attacktimeR ++
					
				};
				if (TargetPos.x > posb.x)
				{
					ccbSetSceneNodeProperty(this.currentNode,"Position",posb.x-1,posb.y,posb.z);
					this.TargetPosition = new vector3d(TargetPos.x-this.Fight_distance+1,TargetPos.y,TargetPos.z);
					this.attacktimeR ++
				
				};
				};
				
			
			}; // play attack animation ( testing for now)
		
		}
		

	this.angle ++;
	if (this.angle >= 360){this.angle = 0};
	var radiusx = pos.x+ Math.sin(this.angle)*this.Activation_radius;
	var radiusz = pos.z+ Math.cos(this.angle)*this.Activation_radius;
	if (Math.sqrt((TargetPos.x-radiusx)*(TargetPos.x-radiusx) + (TargetPos.z-radiusz)*(TargetPos.z-radiusz)) < this.Activation_radius)
	{
		this.activation = true;
	}
	//if (TargetPos.x > radiusx && TargetPos.z > radius.z) //  x axis radius which let the ai only moves if player gets away.
	//{	
	//	this.activation = true;
//	}
	

if(this.activation == true){
	if (TargetPos.x > pos.x+this.Chase_radius) //  x axis radius which let the ai only moves if player gets away.
	{	
		this.TargetPosition = new vector3d(TargetPos.x-this.Fight_distance,TargetPos.y,TargetPos.z);	
	}
	else
	if (TargetPos.x < pos.x-this.Chase_radius)
	{
		this.TargetPosition = new vector3d(TargetPos.x+this.Fight_distance,TargetPos.y,TargetPos.z);
		
	};
}

	
	//checking Animation and setting variables to trigger with the player beahavior if enemy is fighting or in idle state, if AI is fighting then compare the variable in player behavior and give player damage. 
	if (animation == 'punch' || animation == "kick")
	{
		ccbSetCopperCubeVariable(nodename+"_fighting","true");
	}
	else {ccbSetCopperCubeVariable(nodename+"_fighting","false")};
	
	// set position

	ccbSetSceneNodeProperty(node, 'Position', pos);
	
	//hit effect for AI
	if (animation == "hit")
	{
		if (TargetPos.x < posb.x)
		{
			ccbSetSceneNodeProperty(this.currentNode,"Position",posb.x+1,posb.y,posb.z);
			this.TargetPosition = new vector3d(TargetPos.x+71,TargetPos.y,TargetPos.z);

			
		};
		if (TargetPos.x > posb.x)
		{
			ccbSetSceneNodeProperty(this.currentNode,"Position",posb.x-1,posb.y,posb.z);
			this.TargetPosition = new vector3d(TargetPos.x-71,TargetPos.y,TargetPos.z);

		};
	};
	
//Check Animation and deal damage or do other stuff

	this.lastAnimation = this.currentAnimation;
	this.currentAnimation = ccbGetSceneNodeProperty(this.Animated, "Animation");

	if(this.currentAnimation == "hit")
	{ 
		if(this.currentAnimation != this.lastAnimation)
		{
			this.Health -= this.enemy_damage_taken;
			ccbPlaySound(this.hitSound); // play the hit sound
			//Enemy healthbar setup
			this.AI_HealthBar = ccbGetSceneNodeFromName("Enemy_HP");
			this.AI_NameBar = ccbGetSceneNodeFromName("EnemyName");
			ccbSetSceneNodeProperty(this.hitFx,'Position',pos);
			ccbSetSceneNodeProperty(this.hitFx,'Visible',true);
			ccbSetSceneNodeProperty(this.AI_HealthBar,"Visible",true);
			ccbSetSceneNodeProperty(this.AI_NameBar,"Visible",true);
			ccbSetSceneNodeProperty(this.AI_NameBar,"Text",this.EnemyName)
			ccbSetSceneNodeProperty(this.AI_HealthBar,"Width (pixels)",this.Health*2) //multiplying Ai healthbar by 2 According to the overlay setup.
		};
	};
	}
	else// after the enemy is dead end all the actions of AI, put it into a deathloop and then delete it.
	{
		this.deathlooper ++;
		if(this.deathlooper >= 190) // set the time to go into deathloop phase
		{
			ccbSetSceneNodeProperty(this.Animated, 'Animation', 'death_loop');
			this.deathtimeR++;
			
			if(this.deathtimeR > 10) // set the time to deletion and to stay in deathloop
			{
				ccbRemoveSceneNode(node);
			}
		}
	}
	//additional project specific//

	this.playerStopper1 = ccbGetSceneNodeFromName("player_stopper1");
	this.playerStopper2 = ccbGetSceneNodeFromName("player_stopper2");
	this.camStopper1 = ccbGetSceneNodeFromName("cam_stop1");
	this.camStopper2 = ccbGetSceneNodeFromName("cam_stop2");
	
	this.enemy1 = ccbGetCopperCubeVariable("enemy1.status");
	this.enemy2 = ccbGetCopperCubeVariable("enemy2.status");

	if(this.enemy1 == "dead")
	{
		ccbRemoveSceneNode(this.playerStopper1);
		ccbRemoveSceneNode(this.camStopper1);
	}
	if(this.enemy2 == "dead")
	{
		ccbRemoveSceneNode(this.playerStopper2);
		ccbRemoveSceneNode(this.camStopper2);
	}	
	
}
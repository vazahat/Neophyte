// This is a coppercube behavior which moves the node it is attached to only on the x axis,
// controlled by the cursor keys and with space for 'jump'.
//
// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*
	<behavior jsname="behavior_2D_Player" description="Simple beat'em up player">
		<property name="Speed" type="float" default="0.2" />
		<property name="RunSpeed" type="float" default="0.4" />
		<property name="Animated" type="scenenode"/>
		<property name="Health" type="int" default="100" />
		<property name="Pickup_Health" type="int" default="30" />
		<property name="Kick_damage" type="int" default="10" />
		<property name="Punch_damage" type="int" default="10" />
		<property name="hitSound" type="string" default="Audio/PunchHit1.wav" />
	</behavior>
*/

behavior_2D_Player = function()
{
	this.ForwardKeyDown = false;
	this.BackKeyDown = false;
	this.PressedJump = false;
	this.LastTime = null;
	this.JumpForce = 0;
	this.JumpLengthMs = 0;
	this.animation = "";
	this.move = "walk";	// sets the default movement when the movement key is pressed once.
};

// called every frame. 
//   'node' is the scene node where this behavior is attached to.
//   'timeMs' the current time in milliseconds of the scene.
// Returns 'true' if something changed, and 'false' if not.
behavior_2D_Player.prototype.onAnimate = function(node, timeMs)
{
	this.currentNode = node;
	this.movement = this.speed;
	this.animation = this.currentAnimation; //out of memory bug fix
	this.checkAnim = this.variationVar; //out of memory bug fix
	this.player_damage_taken = ccbGetCopperCubeVariable("player_damage");// get the specific damage value for the player from enemy.
	// get the time since the last frame
	
	if (this.LastTime == null)
	{
		this.LastTime = timeMs; // we were never called before, so store the time and cancel
		this.InitPos = ccbGetSceneNodeProperty(node, 'Position');// store the default Position of the player to alter it in different situations.
		this.InitRotation = ccbGetSceneNodeProperty(node, 'Rotation');// store the default rotation of the player to alter it in different situations.
		this.InitSpeed = this.Speed; // store the default speed of the player to alter it in different situations.
		this.InitHealth = this.Health;
		
		return false;
	}
	this.NewRotation = ccbGetSceneNodeProperty(node, 'Rotation');	//get the new rotation to stop player from rotating if up and down arrow keys are pressed.
 // get the current animation of the player to compare in different situations.
	this.LastNodeUsed = node;
	
	var delta = timeMs - this.LastTime;
	this.LastTime = timeMs;
	if (delta > 200) delta = 200;
	
	// move 
	var pos = ccbGetSceneNodeProperty(node, 'Position');
	//pos.z = this.InitPos.z; // force to by always on the same 2D axis
	
	if (this.move == "run"){	// check if the player is running and then increase it speeds otherwise set speed to normal. 
		this.Speed = this.RunSpeed;
	}
	else{	//sets the speed to default speed (normal)
		this.Speed = this.InitSpeed;
	}
	
	if (this.FightKeyDown)	// check if the fight keys are pressed down and then change the fighting animation for the player according to the key press or fight action.
	{
		if(this.FightAction == "kick"){	// change the animation to kick1 if fighting action is equal to kick
			ccbSetSceneNodeProperty(this.Animated, 'Animation', 'kick 1');
			ccbSetCopperCubeVariable("enemy_damage",this.Kick_damage);  // set to give specific damage to enemy
		}
		else
		if(this.FightAction == "punch"){// change the animation to punch1 if fighting action is equal to punch
			ccbSetSceneNodeProperty(this.Animated, 'Animation', 'punch 1');
			ccbSetCopperCubeVariable("enemy_damage",this.Punch_damage); // set to give specific damage to enemy
		}	
	}
	else
	if( this.ForwardKeyDown && this.UpKeyDown) // move forward when right and up arrow keys are pressd
	{
		pos.x += this.Speed * delta;
		pos.z += this.Speed * delta;
		ccbSetSceneNodeProperty(node, 'Rotation', this.InitRotation);
	}
	else
	if( this.ForwardKeyDown && this.DownKeyDown) // move forward when right and down arrow keys are pressd
	{
		pos.x += this.Speed * delta;
		pos.z -= this.Speed * delta;
		ccbSetSceneNodeProperty(node, 'Rotation', this.InitRotation);
	}
	else
	if( this.BackKeyDown && this.UpKeyDown) // move backward when left and up arrow keys are pressd
	{
		pos.x -= this.Speed * delta;
		pos.z += this.Speed * delta;
		ccbSetSceneNodeProperty(node, 'Rotation', this.InitRotation.x, this.InitRotation.y - 180, this.InitRotation.z);//Rotate the player to left
		
	}
	else
	if( this.BackKeyDown && this.DownKeyDown) // move backward when left and down arrow keys are pressd
	{
		pos.x -= this.Speed * delta;
		pos.z -= this.Speed * delta;
		ccbSetSceneNodeProperty(node, 'Rotation', this.InitRotation.x, this.InitRotation.y - 180, this.InitRotation.z);//Rotate the player to left
		
	}
	else
	if (this.ForwardKeyDown)	// cheks if the movement key is pressed and then allow the player to move and change his position and rotation and animation accordingly.
	{
		pos.x += this.Speed * delta; //makes the player move by changing its movement speed.
		ccbSetSceneNodeProperty(node, 'Rotation', this.InitRotation);
		if(this.animation != 'kick 1' && this.animation != 'punch 1'){	//check if fighting animation is playing or not and prevents the walk animation to be played.
			this.FightKeyDown = false;	
			if (this.move == "run"){	//check if the player is running and then play the run animation otherwise play walk animation
				ccbSetSceneNodeProperty(this.Animated, 'Animation', 'run');
			}
			else{//sets the animation to walk if not walking or fighting.
			ccbSetSceneNodeProperty(this.Animated, 'Animation', 'walk');
			}}
	}
	else
	if (this.BackKeyDown)
	{
		pos.x -= this.Speed * delta;//makes the player move by changing its movement speed.
		ccbSetSceneNodeProperty(node, 'Rotation', this.InitRotation.x, this.InitRotation.y - 180, this.InitRotation.z);//Rotate the player to left
		if(this.animation != 'kick 1' && this.animation != 'punch 1'){	//check if fighting animation is playing or not and prevents the walk animation to be played.
			this.FightKeyDown = false;	
			if (this.move == "run"){	//check if the player is running and then play the run animation otherwise play walk animation
				ccbSetSceneNodeProperty(this.Animated, 'Animation', 'run');
			}
			else{ //sets the animation to walk if not walking or fighting.
			ccbSetSceneNodeProperty(this.Animated, 'Animation', 'walk');
			}}
	}
	else
	if (this.UpKeyDown) //changes the position of player on Z-axis
	{
		pos.z += this.Speed * delta;
		ccbSetSceneNodeProperty(node, 'Rotation', this.NewRotation);
		if(this.animation != 'kick 1' && this.animation != 'punch 1'){	//check if fighting animation is playing or not and prevents the walk animation to be played.
			this.FightKeyDown = false;	//sets the figting key to false to prevent animation playing when the key is pressed
			ccbSetSceneNodeProperty(this.Animated, 'Animation', 'walk'); // sets walk animation when no fighting key is pressed.
			}
	}
	else
	if (this.DownKeyDown) //changes the position of player on Z-axis
	{
		pos.z -= this.Speed * delta;
		ccbSetSceneNodeProperty(node, 'Rotation', this.NewRotation);
		if(this.animation != 'kick 1' && this.animation != 'punch 1'){	//check if fighting animation is playing or not and prevents the walk animation to be played.
			this.FightKeyDown = false;	//sets the figting key to false to prevent animation playing when the key is pressed.
			ccbSetSceneNodeProperty(this.Animated, 'Animation', 'walk'); // sets walk animation when no fighting key is pressed.
			}
	}
	
	else
	{
		// not walking, stand
		this.FightKeyDown = false;
		 	//sets the animation to idle when player is doing nothing.
		if(this.checkAnim == "true")
		{
			ccbSetSceneNodeProperty(this.Animated, 'Animation', 'hit');
		}
		else
		{ccbSetSceneNodeProperty(this.Animated, 'Animation', 'idle fight');}
	}

	
	// jump if jump was pressed
	
	if (this.PressedJump && this.JumpForce == 0)
	{
		this.PressedJump = false;
		this.JumpForce = this.JumpLengthMs;
	}
		
	if (this.JumpForce > 0)
	{
		pos.y += this.JumpSpeed * delta;
		this.JumpForce -= delta;
		
		if (this.JumpForce < 0) 
			this.JumpForce = 0;
	}
	//check timing for the animation
	var now = (new Date()).getTime();//this the timer which compares the time stored for animations in the keyEvents function and then check it with the current timer
	if (now > this.endTime)
	{		
			ccbSetCopperCubeVariable("fighting","false");
			//check the current animation when the timer runs out and play default animation //for example (walk and run) if a movement key is still pressed after the timer is over. 
			if(this.ForwardKeyDown == true || this.BackKeyDown == true || this.UpKeyDown == true || this.DownKeyDown == true)
			{	if(this.animation != "walk" || this.animation != "run"){
					if(this.move == "run"){
						ccbSetSceneNodeProperty(this.Animated, 'Animation', 'run');
					}
					else{
						ccbSetSceneNodeProperty(this.Animated, 'Animation', 'walk');
					}
			}
			}//check if no key was presssed when the timer ends.
			else
			if(this.animation != "walk" || this.animation != "run"){ // sets the animation to idle if no movement key was pressed when the timer ends.
				if(this.checkAnim == "true")
				{
					ccbSetSceneNodeProperty(this.Animated, 'Animation', 'hit');
				}
				else
				{ccbSetSceneNodeProperty(this.Animated, 'Animation', 'idle fight');}
			}
			this.FightKeyDown = false;	// make sure to turn off the fight animation once the timer runs out.
			
			if(this.animation != "run"){	// to make the player to undergo walk animation if movement key is not pressed before the timer ends.
				this.move = "walk";
			}
				
		
	}
	
	 // set variables to pass to the AI behavior 
	if (this.animation == "punch 1")
	{
		ccbSetCopperCubeVariable("fighting","punch");
	}
	else if(this.animation == "kick 1")
	{
		ccbSetCopperCubeVariable("fighting","kick");
	}
	else {ccbSetCopperCubeVariable("fighting","none");}

	// set position
	
	ccbSetSceneNodeProperty(node, 'Position', pos);
	
	//hit effect for player
	if (this.animation == "hit")
	{
		if (this.NewRotation.y == this.InitRotation.y)
		{
			ccbSetSceneNodeProperty(node,"Position", pos.x-1,pos.y,pos.z);
		}
		else
		{
			ccbSetSceneNodeProperty(node,"Position", pos.x+1,pos.y,pos.z);
		}
		
	}
	//healthbar setup
	this.HealthBar = ccbGetSceneNodeFromName("HP_bar");
	this.HealthNumericals = ccbGetSceneNodeFromName("player_health");
	ccbSetSceneNodeProperty(this.HealthBar,"Width (pixels)",this.Health*2) //multiplying healthbar by 2 According to the overlay setup.
	ccbSetSceneNodeProperty(this.HealthNumericals,"Text",this.Health);
	//Check Animation and deal damage or do other stuff 
	
	this.lastAnimation = this.currentAnimation;
	this.currentAnimation = ccbGetSceneNodeProperty(this.Animated, "Animation"); //out of mermory fix
	this.variationVar = ccbGetCopperCubeVariable("playerhit"); //out of mermory fix
	if(this.currentAnimation == "hit")
	{ 
	if(this.currentAnimation != this.lastAnimation) // player damage setup, also used to play hit effect.
	{
		this.Health -= this.player_damage_taken;
		ccbPlaySound(this.hitSound); // play the hit sound
		
	}
	}
	if(this.Health > this.InitHealth){ this.Health = this.InitHealth}   //lock health to not go over the initial health ( for example if health is full and picked up health item will not increase any health.)
	
	if (this.Health <= 0)
	{
		//insert gameover part here.
	}
	//health pickup ( this is temporary code just for testing) a better way can be is to get the variable along with pickup node name in order to remove only the collected node.
	this.pickup = ccbGetCopperCubeVariable("Health_pickup");  //get the pickup variable to activate the code.
	this.pickupnode = ccbGetSceneNodeFromName("health_pickup"); 
	if( this.pickup == "true")
	{
		ccbSetCopperCubeVariable("Health_pickup","false");
		this.Health += this.Pickup_Health;
		ccbPlaySound("Audio/HandPointer.wav") 
		ccbRemoveSceneNode(this.pickupnode);
	}

	return true;
}



// parameters: key: key id pressed or left up.  pressed: true if the key was pressed down, false if left up
behavior_2D_Player.prototype.onKeyEvent = function(key, pressed)
{
	// store which key is down
	// key codes are this: left=37, up=38, right=39, down=40
	
		
	if (key == 37 ) //check the keypress for left arrow key
	{	this.BackKeyDown = pressed;
		this.pressed = false;//variable use to check the key presses.
		}
	if (key == 39 )//check the keypress for right arrow key
	{	this.ForwardKeyDown = pressed;
		this.pressed = false;}	//variable use to check the key presses.
	if (key == 40){//check the keypress for down arrow key
		this.DownKeyDown = pressed;
		this.pressed = false;}//variable use to check the key presses.
	if (key == 38){//check the keypress for Up arrow key
		this.UpKeyDown = pressed;
		this.pressed = false;}//variable use to check the key presses.
	
		
	if (key == 32 && pressed)//check the keypress for Space arrow key
		{this.FightKeyDown = pressed; //make sure to set the fight key to true when pressed.
		this.FightAction = "kick"; //sets the fighting action to kick if spacebar is pressed
		this.pressed = pressed;} //variable use to check the key presses.
		
	if (key == 90 && pressed)//check the keypress for Z arrow key
		{this.FightKeyDown = pressed; //make sure to set the fight key to true when pressed.
		this.FightAction = "punch";//sets the fighting action to punch if Z is pressed
		this.pressed = pressed;//variable use to check the key presses.
		}
	if (key == 37 || key == 39 )	// to check if the movement key is released for few ms then allow player to run (keys are left and right arrow keys)
	{	if (!pressed){ // to check with timer and to make sure player is allowed to run if he is walking and then the movement key is pressed again to allow running.
		this.move = "run";
		}
	}		
	//checks the timing for actions animation(not the movement keys).	
		
	var a = this.animation;	//get the current animation playing when a key is pressed 
	
	if(a != "kick 1" && this.FightAction == 'kick'){	//trigger the timer if there is no kick animation running but the kick key is pressed
		this.startTime = (new Date()).getTime();			//start the timer 
		this.endTime = this.startTime + 1400; //1400 is the time for the animation to be played(timer to end)
	}

	if(a != "punch 1" && this.FightAction == 'punch'){
			this.startTime = (new Date()).getTime();
			this.endTime = this.startTime + 400;
		}
		
	if(this.move == "run" && !this.FightKeyDown){		//check if the player is allowed to run and if no other fighting action has been playing or fighting key is pressed then start
			this.startTime = (new Date()).getTime();	// timer so that if the key is pressed again within the timer then the run animation will be played otherwise play walk animation, sets a variable to walk again in the OnAnimate function.
			this.endTime = this.startTime+100;
		}

	
	
	// jump when space pressed
	
	if (key == 32 && pressed)
		this.PressedJump = true;
				
		
}


var childarray = [];// creates a global array
function Selection() // to select and push the nodes in to global array
{
    childarray.push(editorGetSelectedSceneNode());
}
function CurrentParent() // to simply move all children of a node to a new parent by sending its children into a global array
{
    var currentparent = editorGetSelectedSceneNode();		 				
	var childcount = ccbGetSceneNodeChildCount(currentparent); 		
    //selectedarray.push(ccbGetSceneNodeProperty(currentparent,"Name")); //for debugging
	for(var i=0; i < childcount; i++)
	{
		childarray.push(ccbGetChildSceneNode(currentparent, i));
	}
}
function NewParent () // to assign stored nodes from the array to the new parent node and then clear the array.
{
    var newparent =  editorGetSelectedSceneNode();
    if(!ccbGetSceneNodeProperty(newparent,"Name"))
    {
        newparent = ccbGetRootSceneNode();
    }
    var arrlen = childarray.length;
    for(var i =0; i < arrlen; i++)
    {
        ccbSetSceneNodeParent(childarray[i],newparent);
        editorUpdateAllWindows();
    }
    childarray = [];
}
//register all the function as menu entry with key codes
editorRegisterMenuEntry("CurrentParent()", "Select Current Parent node\tShift+C");
editorRegisterMenuEntry("Selection()", "Add node to selection\tShift+B");
editorRegisterMenuEntry("NewParent()", "Select New Parent node\tShift+V");

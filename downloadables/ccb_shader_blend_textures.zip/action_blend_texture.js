// This is a scripted coppercube action. It starts/stops dragging a 3d object with the mouse. 
// Add this action into the "when clicked onto this do something" behavior to make it dragable.
// It is possible to constrain the drag movement to an axis by deactivating the 'x', 'y' and 'z' flags.
//
// The following embedded xml is for the editor and describes how the behavior can be edited:
// Supported types are: int, float, string, bool, color, vect3d, scenenode, texture, action
/*  <action jsname="action_blend_texture" description="Blend two textures together">
	  <property name="Blend_Add" type="bool" default="false" />
	  <property name="Blend_Multiply" type="bool" default="false" />
	  <property name="Blend_Subtract" type="bool" default="false" />
	  <property name="Blend_Divide" type="bool" default="false" />
	  <property name="Change_Which_Material" type="int" default="0" />
	  <property name="Material_Type" type="int" default="0" />
	  
    </action>
*/
action_blend_texture = function()
{
};


action_blend_texture.prototype.execute = function(currentNode)
{	

	//For Blend Mode Type Add
	if(this.Blend_Add == true){
		var vertexShader_Add = 
		"float4x4 mWorldViewProj;  // World * View * Projection \n" + 
		"float4x4 mInvWorld;       // Inverted world matrix	 	\n" + 
		"float4x4 mTransWorld;     // Transposed world matrix	\n" + 
		"														\n" + 
		"// Vertex shader output structure						\n" + 
		"struct VS_OUTPUT										\n" + 
		"{														\n" + 
		"	float4 Position   : POSITION;   // vertex position 	\n" + 
		"	float4 Diffuse    : COLOR0;     // vertex diffuse 	\n" + 
		"	float2 TexCoord   : TEXCOORD0;  // tex coords		\n" + 
		"};														\n" + 
		"														\n" + 
		"VS_OUTPUT main      ( in float4 vPosition : POSITION,	\n" + 
		"                      in float3 vNormal   : NORMAL,	\n" + 
		"                      float2 texCoord     : TEXCOORD0 )\n" + 
		"{														\n" + 
		"	VS_OUTPUT Output;									\n" + 
		"														\n" + 
		"	// transform position to clip space 				\n" + 
		"	Output.Position = mul(vPosition, mWorldViewProj);	\n" + 
		"														\n" + 
		"	// transformed normal would be this:				\n" + 
		"	float3 normal = mul(vNormal, mInvWorld);			\n" + 
		"														\n" + 
		"	// position in world coodinates	would be this:		\n" + 
		"	// float3 worldpos = mul(mTransWorld, vPosition);	\n" + 
		"														\n" + 
		"	Output.Diffuse = float4(1.0, 1.0, 1.0, 1.0);		\n" + 
		"	Output.TexCoord = texCoord;							\n" + 
		"														\n" + 
		"	return Output;										\n" + 
		"}														";

		var fragmentShader_Add = 
		"struct PS_OUTPUT								\n" + 
		"{												\n" + 
		"    float4 RGBColor : COLOR0; 		  			\n" +	
		"};												\n" +
		"												\n" + 
		"sampler2D tex0;								\n" + 
		"sampler2D tex1;								\n" + 
		"												\n" +
		"PS_OUTPUT main( float2 TexCoord : TEXCOORD0,	\n" +
		"                float4 Position : POSITION,	\n" +
		"                float4 Diffuse  : COLOR0 ) 	\n" +
		"{ 												\n" +
		"	PS_OUTPUT Output;							\n" +
		"	float4 col1 = tex2D( tex0, TexCoord );  	\n" + 
		"	float4 col2 = tex2D( tex1, TexCoord );  	\n" + 
		"	Output.RGBColor = abs(col1+col2);			\n" + 
		"	return Output;								\n" +
		"}";
		
		var newMaterial_Add = ccbCreateMaterial(vertexShader_Add, fragmentShader_Add,this.Material_Type, null);
		ccbSetSceneNodeMaterialProperty(currentNode, this.Change_Which_Material-1, 'Type', newMaterial_Add);
		
	}
	
	
	//For Blend Mode Type multiply
	if(this.Blend_Multiply == true){
		var vertexShader_Multiply = 
		"float4x4 mWorldViewProj;  // World * View * Projection \n" + 
		"float4x4 mInvWorld;       // Inverted world matrix	 	\n" + 
		"float4x4 mTransWorld;     // Transposed world matrix	\n" + 
		"														\n" + 
		"// Vertex shader output structure						\n" + 
		"struct VS_OUTPUT										\n" + 
		"{														\n" + 
		"	float4 Position   : POSITION;   // vertex position 	\n" + 
		"	float4 Diffuse    : COLOR0;     // vertex diffuse 	\n" + 
		"	float2 TexCoord   : TEXCOORD0;  // tex coords		\n" + 
		"};														\n" + 
		"														\n" + 
		"VS_OUTPUT main      ( in float4 vPosition : POSITION,	\n" + 
		"                      in float3 vNormal   : NORMAL,	\n" + 
		"                      float2 texCoord     : TEXCOORD0 )\n" + 
		"{														\n" + 
		"	VS_OUTPUT Output;									\n" + 
		"														\n" + 
		"	// transform position to clip space 				\n" + 
		"	Output.Position = mul(vPosition, mWorldViewProj);	\n" + 
		"														\n" + 
		"	// transformed normal would be this:				\n" + 
		"	float3 normal = mul(vNormal, mInvWorld);			\n" + 
		"														\n" + 
		"	// position in world coodinates	would be this:		\n" + 
		"	// float3 worldpos = mul(mTransWorld, vPosition);	\n" + 
		"														\n" + 
		"	Output.Diffuse = float4(1.0, 1.0, 1.0, 1.0);		\n" + 
		"	Output.TexCoord = texCoord;							\n" + 
		"														\n" + 
		"	return Output;										\n" + 
		"}														";

		var fragmentShader_Multiply = 
		"struct PS_OUTPUT								\n" + 
		"{												\n" + 
		"    float4 RGBColor : COLOR0; 		  			\n" +	
		"};												\n" +
		"												\n" + 
		"sampler2D tex0;								\n" + 
		"sampler2D tex1;								\n" + 
		"												\n" +
		"PS_OUTPUT main( float2 TexCoord : TEXCOORD0,	\n" +
		"                float4 Position : POSITION,	\n" +
		"                float4 Diffuse  : COLOR0 ) 	\n" +
		"{ 												\n" +
		"	PS_OUTPUT Output;							\n" +
		"	float4 col1 = tex2D( tex0, TexCoord );  	\n" + 
		"	float4 col2 = tex2D( tex1, TexCoord );  	\n" + 
		"	Output.RGBColor = abs(col1*col2);			\n" + 
		"	return Output;								\n" +
		"}";

		var newMaterial_Multiply = ccbCreateMaterial(vertexShader_Multiply, fragmentShader_Multiply, this.Material_Type, null);
		ccbSetSceneNodeMaterialProperty(currentNode, this.Change_Which_Material-1, 'Type', newMaterial_Multiply);
	}
	
	//For Blend Mode Type Subtract
	if(this.Blend_Subtract == true){
		var vertexShader_Subtract = 
		"float4x4 mWorldViewProj;  // World * View * Projection \n" + 
		"float4x4 mInvWorld;       // Inverted world matrix	 	\n" + 
		"float4x4 mTransWorld;     // Transposed world matrix	\n" + 
		"														\n" + 
		"// Vertex shader output structure						\n" + 
		"struct VS_OUTPUT										\n" + 
		"{														\n" + 
		"	float4 Position   : POSITION;   // vertex position 	\n" + 
		"	float4 Diffuse    : COLOR0;     // vertex diffuse 	\n" + 
		"	float2 TexCoord   : TEXCOORD0;  // tex coords		\n" + 
		"};														\n" + 
		"														\n" + 
		"VS_OUTPUT main      ( in float4 vPosition : POSITION,	\n" + 
		"                      in float3 vNormal   : NORMAL,	\n" + 
		"                      float2 texCoord     : TEXCOORD0 )\n" + 
		"{														\n" + 
		"	VS_OUTPUT Output;									\n" + 
		"														\n" + 
		"	// transform position to clip space 				\n" + 
		"	Output.Position = mul(vPosition, mWorldViewProj);	\n" + 
		"														\n" + 
		"	// transformed normal would be this:				\n" + 
		"	float3 normal = mul(vNormal, mInvWorld);			\n" + 
		"														\n" + 
		"	// position in world coodinates	would be this:		\n" + 
		"	// float3 worldpos = mul(mTransWorld, vPosition);	\n" + 
		"														\n" + 
		"	Output.Diffuse = float4(1.0, 1.0, 1.0, 1.0);		\n" + 
		"	Output.TexCoord = texCoord;							\n" + 
		"														\n" + 
		"	return Output;										\n" + 
		"}														";

		var fragmentShader_Subtract = 
		"struct PS_OUTPUT								\n" + 
		"{												\n" + 
		"    float4 RGBColor : COLOR0; 		  			\n" +	
		"};												\n" +
		"												\n" + 
		"sampler2D tex0;								\n" + 
		"sampler2D tex1;								\n" + 
		"												\n" +
		"PS_OUTPUT main( float2 TexCoord : TEXCOORD0,	\n" +
		"                float4 Position : POSITION,	\n" +
		"                float4 Diffuse  : COLOR0 ) 	\n" +
		"{ 												\n" +
		"	PS_OUTPUT Output;							\n" +
		"	float4 col1 = tex2D( tex0, TexCoord );  	\n" + 
		"	float4 col2 = tex2D( tex1, TexCoord );  	\n" + 
		"	Output.RGBColor = abs(col1-col2);			\n" + 
		"	return Output;								\n" +
		"}";

		var newMaterial_Subtract = ccbCreateMaterial(vertexShader_Subtract, fragmentShader_Subtract, this.Material_Type, null);
		ccbSetSceneNodeMaterialProperty(currentNode, this.Change_Which_Material-1, 'Type', newMaterial_Subtract);
	}
	
	//For Blend Mode Type Divide
	if(this.Blend_Divide == true){
		var vertexShader_Divide = 
		"float4x4 mWorldViewProj;  // World * View * Projection \n" + 
		"float4x4 mInvWorld;       // Inverted world matrix	 	\n" + 
		"float4x4 mTransWorld;     // Transposed world matrix	\n" + 
		"														\n" + 
		"// Vertex shader output structure						\n" + 
		"struct VS_OUTPUT										\n" + 
		"{														\n" + 
		"	float4 Position   : POSITION;   // vertex position 	\n" + 
		"	float4 Diffuse    : COLOR0;     // vertex diffuse 	\n" + 
		"	float2 TexCoord   : TEXCOORD0;  // tex coords		\n" + 
		"};														\n" + 
		"														\n" + 
		"VS_OUTPUT main      ( in float4 vPosition : POSITION,	\n" + 
		"                      in float3 vNormal   : NORMAL,	\n" + 
		"                      float2 texCoord     : TEXCOORD0 )\n" + 
		"{														\n" + 
		"	VS_OUTPUT Output;									\n" + 
		"														\n" + 
		"	// transform position to clip space 				\n" + 
		"	Output.Position = mul(vPosition, mWorldViewProj);	\n" + 
		"														\n" + 
		"	// transformed normal would be this:				\n" + 
		"	float3 normal = mul(vNormal, mInvWorld);			\n" + 
		"														\n" + 
		"	// position in world coodinates	would be this:		\n" + 
		"	// float3 worldpos = mul(mTransWorld, vPosition);	\n" + 
		"														\n" + 
		"	Output.Diffuse = float4(1.0, 1.0, 1.0, 1.0);		\n" + 
		"	Output.TexCoord = texCoord;							\n" + 
		"														\n" + 
		"	return Output;										\n" + 
		"}														";

		var fragmentShader_Divide = 
		"struct PS_OUTPUT								\n" + 
		"{												\n" + 
		"    float4 RGBColor : COLOR0; 		  			\n" +	
		"};												\n" +
		"												\n" + 
		"sampler2D tex0;								\n" + 
		"sampler2D tex1;								\n" + 
		"												\n" +
		"PS_OUTPUT main( float2 TexCoord : TEXCOORD0,	\n" +
		"                float4 Position : POSITION,	\n" +
		"                float4 Diffuse  : COLOR0 ) 	\n" +
		"{ 												\n" +
		"	PS_OUTPUT Output;							\n" +
		"	float4 col1 = tex2D( tex0, TexCoord );  	\n" + 
		"	float4 col2 = tex2D( tex1, TexCoord );  	\n" + 
		"	Output.RGBColor = abs(col1/col2);			\n" + 
		"	return Output;								\n" +
		"}";

		var newMaterial_Divide = ccbCreateMaterial(vertexShader_Divide, fragmentShader_Divide, this.Material_Type, null);
		ccbSetSceneNodeMaterialProperty(currentNode, this.Change_Which_Material-1, 'Type', newMaterial_Divide);
	}
		
	
}

// ***Author:- VAZAHAT PATHAN***

//        ****AKA****

 //   ****Just_in_case**** 

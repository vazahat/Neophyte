# Coppercube fps-3ps-example
This is an Firs Person Shooter or 3er person Shooter demo make using Coppercube

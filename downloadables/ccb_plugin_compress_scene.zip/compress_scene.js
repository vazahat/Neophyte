// Optimizes all geometry in the scene in order to make the file size smaller. This will compress all mesh geometry in the scene by merging vertices with similar attributes.
// Normals and colors will be merged, meaning the object might look a bit different as before.
// If you are using lightmaps, you have to recalculate them again afterwards.
// Version: 1.0
// Author: N.Gebhardt

vector3d.prototype.getLength = function() // fixing wrong get length implementation of old coppercube versions
{
	return Math.sqrt( this.x*this.x + this.y*this.y + this.z*this.z );
}

function getIndexForReusableVertex(newPositions, newCoords, pos, tpos, nrm, clr, node, meshbuffernumber)
{
	for (var i=0; i<newPositions.length; ++i)
	{
		var p = newPositions[i];
		var c = newCoords[i];
		
		if (p.x == pos.x && p.y == pos.y && p.z == pos.z &&
			c.x == tpos.x && c.y == tpos.y)
		{
			return i;
		}
	}
	
	var ret = newPositions.length;
	newPositions.push(pos);
	newCoords.push(tpos);
	
	ccbAddMeshBufferVertex(node, meshbuffernumber, pos);
	ccbSetMeshBufferVertexTextureCoord(node, meshbuffernumber, newCoords.length-1, tpos);
	ccbSetMeshBufferVertexColor(node, meshbuffernumber, newCoords.length-1, clr); // 0x00ffffff
	ccbSetMeshBufferVertexNormal(node, meshbuffernumber, newCoords.length-1, nrm);
	
	return ret;
}

optimizeScene_totalVertexCountBefore = 0;
optimizeScene_totalIndexCountBefore = 0;
optimizeScene_totalVertexCountAfter = 0;
optimizeScene_totalIndexCountAfter = 0;

function compressScene()
{
	if (!confirm("This will compress all mesh geometry in the scene by merging vertices " + 
					"with similar attributes. Normals and colors will be merged, meaning the object might look a bit different as before.\nIt is not possible to undo this.\nIt is probably also very slow.\nContinue?"))
		{
			return;
		}
		
	optimizeScene_totalVertexCountBefore = 0;
	optimizeScene_totalIndexCountBefore = 0;
	optimizeScene_totalVertexCountAfter = 0;
	optimizeScene_totalIndexCountAfter = 0;

	compressAllMeshes(ccbGetRootSceneNode());
	
	var v1 = ((optimizeScene_totalVertexCountBefore*33)+(optimizeScene_totalIndexCountBefore * 2));
	var v2 = ((optimizeScene_totalVertexCountAfter*33)+(optimizeScene_totalIndexCountAfter * 2));
	
	if (v1 == v2)
		alert("Compression done.\n" +
		  "Was not able to optimize anything, sorry.");
	else
	{
		var p = ((v1 - v2) / v1 * 100).toFixed(1);
		alert("Compression done. Scene geometry size reduced by " + p + "%.\n\n" + 
			  "Geometry usage before optimization: " + v1 + "bytes \n" +
			  "Geometry usage after optimization:  " + v2 + "bytes \n");
	}
}

function compressAllMeshes(meshnode)
{
	var bufferCount = ccbGetSceneNodeMeshBufferCount(meshnode);
	if (bufferCount != 0)
	{
		for (var i=0; i<bufferCount; ++i)
		{
			optimizeScene_totalVertexCountBefore += ccbGetMeshBufferVertexCount(meshnode, i);
			optimizeScene_totalIndexCountBefore += ccbGetMeshBufferIndexCount(meshnode, i);
		}
	}
  
	optimizeMesh(meshnode);
	
	var bufferCount = ccbGetSceneNodeMeshBufferCount(meshnode);
	if (bufferCount != 0)
	{
		for (var i=0; i<bufferCount; ++i)
		{
			optimizeScene_totalVertexCountAfter += ccbGetMeshBufferVertexCount(meshnode, i);
			optimizeScene_totalIndexCountAfter += ccbGetMeshBufferIndexCount(meshnode, i);
		}
	}	
	
	var count = ccbGetSceneNodeChildCount(meshnode);

	for(var i=0; i<count; ++i)
	{
	 var child = ccbGetChildSceneNode(meshnode, i);
	 compressAllMeshes(child);
	}
}

function optimizeMesh(meshnode)
{
	var bufferCount = ccbGetSceneNodeMeshBufferCount(meshnode);
		
	if (bufferCount == 0)
		return;
	else
	{
		
		// create optimized version of each buffer
		
		for (var i=0; i<bufferCount; ++i)
		{
			var vertexcount = ccbGetMeshBufferVertexCount(meshnode, i);
			var idxcount = ccbGetMeshBufferIndexCount(meshnode, i);
			var newPositions = new Array();
			var newCoords = new Array();
			
			var newBufferIndex = bufferCount+i;
			ccbAddMeshBuffer(meshnode);
			
			// copy material
			
			ccbSetSceneNodeMaterialProperty(meshnode, bufferCount+i, "Type", ccbGetSceneNodeMaterialProperty(meshnode, i, "Type"));
			ccbSetSceneNodeMaterialProperty(meshnode, bufferCount+i, "Texture1", ccbGetSceneNodeMaterialProperty(meshnode, i, "Texture1"));
			ccbSetSceneNodeMaterialProperty(meshnode, bufferCount+i, "Texture2", ccbGetSceneNodeMaterialProperty(meshnode, i, "Texture2"));
			ccbSetSceneNodeMaterialProperty(meshnode, bufferCount+i, "Lighting", ccbGetSceneNodeMaterialProperty(meshnode, i, "Lighting"));
			
			var verticesAdded = 0;
			
			for (var idx=0; idx<idxcount; idx+=3)
			{
				var i1 = ccbGetMeshBufferIndexValue(meshnode, i, idx);
				var i2 = ccbGetMeshBufferIndexValue(meshnode, i, idx+1);
				var i3 = ccbGetMeshBufferIndexValue(meshnode, i, idx+2);
				
				var pos = null;
				var tpos = null;
				var nrm = null;
				var clr = 0x00ffffff;
				
				pos = ccbGetMeshBufferVertexPosition(meshnode, i, i1);
				tpos = ccbGetMeshBufferVertexTextureCoord(meshnode, i, i1);	
				nrm = ccbGetMeshBufferVertexNormal(meshnode, i, i1);
				clr = ccbGetMeshBufferVertexColor(meshnode, i, i1);
				i1 = getIndexForReusableVertex(newPositions, newCoords, pos, tpos, nrm, clr, meshnode, newBufferIndex);				
				ccbAddMeshBufferIndex(meshnode, newBufferIndex, i1);
				
				pos = ccbGetMeshBufferVertexPosition(meshnode, i, i2);
				tpos = ccbGetMeshBufferVertexTextureCoord(meshnode, i, i2);				
				nrm = ccbGetMeshBufferVertexNormal(meshnode, i, i2);
				clr = ccbGetMeshBufferVertexColor(meshnode, i, i2);
				i2 = getIndexForReusableVertex(newPositions, newCoords, pos, tpos, nrm, clr, meshnode, newBufferIndex);				
				ccbAddMeshBufferIndex(meshnode, newBufferIndex, i2);
				
				pos = ccbGetMeshBufferVertexPosition(meshnode, i, i3);
				tpos = ccbGetMeshBufferVertexTextureCoord(meshnode, i, i3);				
				nrm = ccbGetMeshBufferVertexNormal(meshnode, i, i3);
				clr = ccbGetMeshBufferVertexColor(meshnode, i, i3);
				i3 = getIndexForReusableVertex(newPositions, newCoords, pos, tpos, nrm, clr, meshnode, newBufferIndex);				
				ccbAddMeshBufferIndex(meshnode, newBufferIndex, i3);
			}
	  }    
	  

	// remove old buffers
	for (var i=0; i<bufferCount; ++i)
	{
		ccbRemoveMeshBuffer(meshnode, 0);
	}
	
	ccbUpdateSceneNodeBoundingBox(meshnode);
  }
}

// add the function to the plugin menu
editorRegisterMenuEntry("compressScene()", "Compress whole scene geometry (makes file smaller)");

function snap(value, gridSize, roundFunction){
    if (roundFunction === undefined) roundFunction = Math.round;
    return gridSize * roundFunction(value / gridSize);
}

var global_gridSnapValue = 5;

function SnapSceneNodeToGrid()
{
	var s = editorGetSelectedSceneNode();
	var position = ccbGetSceneNodeProperty(s, "Position");

	var moveobjX = snap(position.x, global_gridSnapValue);
	var moveobjY = snap(position.y, global_gridSnapValue);
	var moveobjZ = snap(position.z, global_gridSnapValue);

	ccbSetSceneNodeProperty(s,"Position",moveobjX,moveobjY,moveobjZ);
	ccbUpdateSceneNodeBoundingBox(s);
	editorUpdateAllWindows();
}

function setSnapSceneNodeToGridValue()
{
	global_gridSnapValue = prompt("Set a grid size value for the Snapt to grid function",5);
}

editorRegisterMenuEntry("SnapSceneNodeToGrid()", "Snap to grid\tCtrl+M");
editorRegisterMenuEntry("setSnapSceneNodeToGridValue()", "Set snap to grid size...");
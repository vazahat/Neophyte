// CopperCube Special Functions Key Pressed Behavior
// This script is used when you want to assign specific actions when pressing the Functions Keys on your Keyboard F1,F2,F3 .. F12
// If you don't want to assign an action just leave the field non used.
// To use it , just add it to your scene root node and assign the function for each key.
// Ahmed ABDEL SALAM
// www.techno-valley.com || www.letterskingdom.com
// Support : a.m.abdelsalam@techno-valley.com || a.m.abdelsalam@link.net

/*
  <behavior jsname="behavior_FunctionKeyIsPressed" 
	description="Function Keys Usage">
      <property name="ActionOnF1" type="action" />
      <property name="ActionOnF2" type="action" />
      <property name="ActionOnF3" type="action" />
      <property name="ActionOnF4" type="action" />
      <property name="ActionOnF5" type="action" />
      <property name="ActionOnF6" type="action" />
      <property name="ActionOnF7" type="action" />
      <property name="ActionOnF8" type="action" />
      <property name="ActionOnF9" type="action" />
      <property name="ActionOnF10" type="action" />
      <property name="ActionOnF11" type="action" />
      <property name="ActionOnF12" type="action" />
  </behavior>
*/

behavior_FunctionKeyIsPressed = function()
{
}

behavior_FunctionKeyIsPressed.prototype.onAnimate = function(n, timeMs)
{
}

behavior_FunctionKeyIsPressed.prototype.onKeyEvent = function(key, pressed)
{
  if (key == 112) // 'F1' key
  {
     if (pressed)
		ccbInvokeAction(this.ActionOnF1);
  }

  if (key == 113)// 'F2' key
  {
     if (pressed)
		ccbInvokeAction(this.ActionOnF2);
  }
  
  if (key == 114) // 'F3' key
  {
     if (pressed)
		ccbInvokeAction(this.ActionOnF3);
  }

  if (key == 115) // 'F4' key
  {
     if (pressed)
		ccbInvokeAction(this.ActionOnF4);
  }

  if (key == 116) // 'F5' key
  {
     if (pressed)
		ccbInvokeAction(this.ActionOnF5);
  }

  if (key == 117) // 'F6' key
  {
     if (pressed)
		ccbInvokeAction(this.ActionOnF6);
  }

  if (key == 118) // 'F7' key
  {
     if (pressed)
		ccbInvokeAction(this.ActionOnF7);
  }

  if (key == 119) // 'F8' key
  {
     if (pressed)
		ccbInvokeAction(this.ActionOnF8);
  }

  if (key == 120) // 'F9' key
  {
     if (pressed)
		ccbInvokeAction(this.ActionOnF9);
  }

  if (key == 121) // 'F10' key
  {
     if (pressed)
		ccbInvokeAction(this.ActionOnF10);
  }

  if (key == 122) // 'F11' key
  {
     if (pressed)
		ccbInvokeAction(this.ActionOnF11);
  }

  if (key == 123) // 'F12' key
  {
     if (pressed)
		ccbInvokeAction(this.ActionOnF12);
  }
	
}

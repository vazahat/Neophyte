// This is a scripted coppercube behavior. It works like the model viewer camera behavior, but it has some more features:
// It can pan when left+right button is presed down, and its radius can
// additionally be changed by the JavaScript variable "ModelViewerCameraExRadius".
//
/*
  <behavior jsname="behavior_ModelViewerCameraEx" description="Extended Model Viewer Camera">
     <property name="RotateSpeed" type="float" default="10000" />
	 <property name="SlideAfterMovementEnd" type="bool" default="true" />
	 <property name="NoVerticalMovement" type="bool" default="false" />
	 <property name="SlidingSpeed" type="float" default="500.0" />	 
	 <property name="AllowPan" type="bool" default="false" />
	 <property name="PanSpeed" type="float" default="500.0" />	 
  </behavior>
*/


behavior_ModelViewerCameraEx = function()
{
	ModelViewerCameraExRadius = 100.0;
	
	this.MouseDown = false;
	this.MouseDownR = false;
	this.MouseDownX = 0;
	this.MouseDownY = 0;
	
	this.RotateSpeed = 10000;
	this.NoVerticalMovement = false;
	this.NoVerticalMovementYPos = -66666.0;	
	
	this.SlideAfterMovementEnd = false;
	this.SlidingSpeed = 0;
	this.SlidingMoveX = 0;
	this.SlidingMoveY = 0;
	
	this.LastTime = null;
};

behavior_ModelViewerCameraEx.prototype.onAnimate = function(node, timeMs)
{	
	if (this.LastTime == null)
	{
		this.LastTime = timeMs; 
		return false;
	}
	
	var delta = timeMs - this.LastTime;
	this.LastTime = timeMs;
	if (delta > 200) delta = 200;
	var timeDiff = delta;
		
	var cam = ccbGetActiveCamera();
	
   if (cam == null)
		return false;
		
	var radius = ModelViewerCameraExRadius;
			
	// move forwards/backwards
	
	var pos = ccbGetSceneNodeProperty(cam, "Position");
	var target = ccbGetSceneNodeProperty(cam, "Target");
	var targetvect = target.substract(pos);
	
	var moveX = 0;			
	var moveY = 0;		
	
	if (this.MouseDown)
	{
		moveX = (ccbGetMousePosX() - this.MouseDownX) * this.RotateSpeed / 50000;			
		moveY = (ccbGetMousePosY() - this.MouseDownY) * this.RotateSpeed / 50000;			
	}
			
	var strafevect = new vector3d(targetvect.z * -1, 0, targetvect.x * 1);
	strafevect.normalize();
		
	if (this.MouseDownR && this.MouseDown && this.AllowPan)
	{
		// pan with both mouse buttons pressed
		
		var newtarget = new vector3d(target.x, target.y, target.z);
		var panX = (ccbGetMousePosX() - this.MouseDownX) * this.PanSpeed / 50000;			
		var panY = (ccbGetMousePosY() - this.MouseDownY) * this.PanSpeed / 50000;		
				
		// horizontal pan
				
		if ( !(panX < 0.0001 && panX > -0.001) )
		{
			strafevect.x *= timeDiff * panX;
			strafevect.z *= timeDiff * panX;
			pos = pos.add(strafevect);
			newtarget = newtarget.add(strafevect);
		}
		
		// vertical pan 
		
		if ( !(panY < 0.0001 && panY > -0.001) )
		{
			var upv = new vector3d(0, timeDiff * panY, 0);			
			var newpos = pos.add(upv);
			newtarget = newtarget.add(upv);
		}
		
		ccbSetSceneNodeProperty(cam, "Target", newtarget);
		target = newtarget;
	}
	else
	{
		// normal movement with left mouse button
		
		// sliding after movement ended
				
		if ( this.SlideAfterMovementEnd &&
			 this.SlidingSpeed != 0 )
		{		
			if ( moveX < 0.0001 && moveX > -0.001 )
			{
				// slide a bit after movement has finished
				moveX = this.SlidingMoveX;

				this.SlidingMoveX *= 0.9; // this is not frame independent, but since the fps is capped, its quite ok

				if (this.SlidingMoveX > 0)
					this.SlidingMoveX = Math.max(0.0, this.SlidingMoveX - (timeDiff / this.SlidingSpeed));				
				else
				if (this.SlidingMoveX < 0)
					this.SlidingMoveX = Math.min(0.0, this.SlidingMoveX + (timeDiff / this.SlidingSpeed));
			}
			else
				this.SlidingMoveX = moveX * (this.SlidingSpeed / 1000.0);

			if ( moveY < 0.0001 && moveY > -0.001 )
			{
				// slide a bit after movement has finished
				moveY = this.SlidingMoveY;

				this.SlidingMoveY *= 0.9; // this is not frame independent, but since the fps is capped, its quite ok

				if (this.SlidingMoveY > 0)
					this.SlidingMoveY = Math.max(0.0, this.SlidingMoveY - (timeDiff / this.SlidingSpeed));
				else
				if (this.SlidingMoveY < 0)
					this.SlidingMoveY = Math.min(0.0, this.SlidingMoveY + (timeDiff / this.SlidingSpeed));
			}		
			else
				this.SlidingMoveY = moveY * (this.SlidingSpeed / 1000.0);
		}
					
		// horizontal movement
				
		if ( !(moveX < 0.0001 && moveX > -0.001) )
		{
			strafevect.x *= timeDiff * moveX;
			strafevect.z *= timeDiff * moveX;
			pos = pos.add(strafevect);
		}
		
		// vertical movement
		
		if (!this.NoVerticalMovement && !(moveY < 0.0001 && moveY > -0.001))
		{
			var upv = new vector3d(0, timeDiff * moveY, 0);
			
			var newpos = pos.add(upv);
			var newPosNoY = new vector3d(newpos.x, newpos.y, newpos.z);
			newPosNoY.y = target.y;
			
			var minRadius = radius / 10.0;
			if (target.substract(newPosNoY).getLength() > minRadius)
				pos = newpos;
		}
		
		// also correct vertical position if bool NoVerticalMovement is on
		
		if (this.NoVerticalMovement)
		{
			if (this.NoVerticalMovementYPos == -66666.0)
				this.NoVerticalMovementYPos = pos.y;

			pos.y = this.NoVerticalMovementYPos;
		}
	}
	
	// set mouse
	
	this.MouseDownX = ccbGetMousePosX();
	this.MouseDownY = ccbGetMousePosY();
	
	
	// force circle on radius
	
	targetvect = pos.substract(target);
	
	targetvect.normalize();
	targetvect.x *= radius;
	targetvect.y *= radius;
	targetvect.z *= radius;
	
	pos = target.add(targetvect);
	
	ccbSetSceneNodeProperty(cam, "Position", pos);
	
	return true;
}

// mouseEvent: 0=move moved, 1=mouse clicked, 2=left mouse up,  3=left mouse down, 4=right mouse up, 5=right mouse up
behavior_ModelViewerCameraEx.prototype.onMouseEvent = function(mouseEvent, mouseWheelDelta)
{
	if (mouseEvent == 3)
	{
		this.MouseDown = true;
		this.MouseDownX = ccbGetMousePosX();
		this.MouseDownY = ccbGetMousePosY();
	}
	else
	if (mouseEvent == 2)
		this.MouseDown = false;
	else
	if (mouseEvent == 5)
	{
		this.MouseDownR = true;
		this.MouseDownX = ccbGetMousePosX();
		this.MouseDownY = ccbGetMousePosY();
	}
	else
	if (mouseEvent == 4)
		this.MouseDownR = false;
}

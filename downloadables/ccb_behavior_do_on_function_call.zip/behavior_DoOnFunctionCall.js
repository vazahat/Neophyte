// This is a CopperCube behavior which binds any CCB action(s) to a named javascript function.
// The attribute 'FunctionName' is the name of the global function object that is created.
// This can be called from anywhere in the window to execute the listed CopperCube actions.
// 'FunctionName' must be a valid javascript variable name, and it is good practise to prefix
// it with 'ccb' to match the pseudo-namespace of other CopperCube functions.

/*
    <behavior jsname="behavior_DoOnFunctionCall" description="When javascript function is called do something">
        <property name="FunctionName" type="string" />
        <property name="Action" type="action" />
    </behavior>
*/

behavior_DoOnFunctionCall = function () {
    "use strict";
};

behavior_DoOnFunctionCall.prototype.onAnimate = function (node) {
    "use strict";
    var action = this.Action,
        global = Function("return this")();    // Get global object regardless of current scope or environment
    global[this.FunctionName] = function () { ccbInvokeAction(action, node); };    // Create a global wrapper for ccbInvokeAction, with static arguments
    this.onAnimate = function () {};    // All finished, we can wipe the onAnimate method to boost performance
};
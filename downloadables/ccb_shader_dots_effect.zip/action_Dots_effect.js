/*	Info 
	
    Extension Name	: Action Dots effect
    Extension Type	: Action
    Author:			: Vazahat Khan (just_in_case)
    Date Created	: December 20, 2021, 09:18 PM
    Description		: Apply dots (circles) effects to a texture with transparency. 
	
*/
/* 	Donate
	
    If you like my work, please consider "buy me a cup of coffee" to support me.
    You can do that via PayPal :)
	
    PayPal: http://paypal.me/Vazahat
	Discord Server :- https://discord.gg/RKcq89S7uA
	YouTube :- https://www.youtube.com/GlitchedVelocity
	Itch.io :- https://vazahat.itch.io/
    Website - https://neophyte.cf
	

*/
/*	Changelog

    [December 20, 2021]	- Added Basic Shader code
                    - Added Shader Constants to use in shaders ( Amount)
                    - Calculation grid, offset, tilezie, cirlces and all
                	- Converted the Shader into an action
                    - Added different parameters (Actions property to control the shader
    [July 12, 2022]	- Added Support for fog ( windows platform only). 


*/



/* Usage
  Attach this action to a behavior and fill the parameters, Select the Affecting_node (the node on you want to get affected by this shader), Set the base_material_type, and the amount of circle that you wants to be drawn.
  
  
  
    Itch.io - https://vazahat.itch.io/cc-shader-spritesheet-animation
    Youtube - https://www.youtube.com/channel/UC_yfoGEKkmY63tnyy6hR7ZQ
    Website - https://neophyte.cf
    Discord - https://discord.gg/RKcq89S7uA
  
*/

/*  <action jsname="action_Dots_effect" description="Dots effect shader">
      <property name="Affecting_node" type="scenenode"/>
      <property name="Affect_all_material" type="bool" default="true" />
      <property name="Affecting_material" type="int" default="1" />
      <property name="Base_material_type" type="int" default="13" />
      <property name="Circles_amount" type="int" default="12" />
	  <property name="Fog_Enabled" type="bool" default="true" />

    </action>
*/


   action_Dots_effect = function () { };

   action_Dots_effect.prototype.execute = function () {
       this.Affecting_material -= 1;
       this.nodeName = ccbGetSceneNodeProperty(this.Affecting_node, "Name");

   
   
       var vertexShader = 
       "float4x4 mWorldViewProj;  // World * View * Projection          \n" + 
       "float4x4 mInvWorld;       // Inverted world matrix	 	        \n" + 
       "float4x4 mTransWorld;     // Transposed world matrix          	\n" +
       "														        \n" + 
       "float mFogDensity ; 	    									\n" + 
       "float fogEnable ;	    	    								\n" + 
       "// Vertex shader output structure						        \n" + 
       "struct VS_OUTPUT										        \n" + 
       "{														        \n" + 
       "	float4 Position   : POSITION;   // vertex position 	        \n" + 
       "	float4 Diffuse    : COLOR0;     // vertex diffuse           \n" + 
       "	float2 TexCoord   : TEXCOORD0;  // tex coords	            \n" + 
       "	float Fog	: FOG;							    			\n" +
       "};													            \n" + 
       "														        \n" + 
       "VS_OUTPUT main      ( in float4 vPosition : POSITION,	        \n" + 
       "                      in float3 vNormal   : NORMAL,	            \n" + 
       "                      float2 texCoord     : TEXCOORD0 )         \n" + 
       "{														        \n" + 
       "	VS_OUTPUT Output;									        \n" + 
       "														        \n" + 
       "	// transform position to clip space 			            \n" + 
       "	Output.Position = mul(vPosition, mWorldViewProj);	        \n" + 
       "														        \n" + 
       "	// transformed normal would be this:				        \n" + 
       "	float3 normal = mul(vNormal, mInvWorld);		            \n" + 
       "													            \n" + 
       "	// position in world coodinates	would be this:		        \n" + 
       "	// float3 worldpos = mul(mTransWorld, vPosition);           \n" + 
       "													            \n" + 
       "	Output.Diffuse = float4(1.0, 1.0, 1.0, 1.0);	            \n" + 
       "	Output.TexCoord = texCoord;						            \n" + 
       "			if (fogEnable == 1)									\n" + 
       "   		{ 														\n" + 
       "     			Output.Fog = saturate(1.0 / exp(Output.Position.z * mFogDensity));	\n" + 
       "  			}													\n" + 
       "  			else												\n" + 
       "  			 {     												\n" + 
       "     			Output.Fog = 1;									\n" + 
       "   		 }  													\n" + 
       "														        \n" + 
       "	return Output;										        \n" + 
       "}														";
       
       var fragmentShader = 
       "struct PS_OUTPUT							                        \n" + 
       "{											                        \n" + 
       "    float4 RGBColor : COLOR0; 		  		                        \n" +	
       "};											                        \n" +
       "												                    \n" + 
       "float4 FogColor;													\n" +
       "sampler2D tex0;							                            \n" +
       " float4 Width;                                                      \n" +
       " float4 Height;                                                     \n" + 
       " 												                    \n" +
       "PS_OUTPUT main( float2 TexCoord : TEXCOORD0,	                    \n" +
       "                float4 Position : POSITION,	                        \n" +
       "				 float Fog    : FOG,		                    	\n" +
       "                float4 Diffuse  : COLOR0 ) 	                        \n" +
       "{ 												                    \n" +
       "	PS_OUTPUT Output;							                    \n" +
       "     float2 posTexCoord = TexCoord;                                 \n" +
       "     posTexCoord *= float2(Width.x, Height.x);                      \n" + //Creation of grid for pixelation
       "     posTexCoord = ceil(posTexCoord);                               \n" +
       "     posTexCoord /= float2(Width.x, Height.x);                      \n" +
       "     float2 tileCoord = posTexCoord;                                \n" +
       "     posTexCoord -= TexCoord.xy;                                    \n" + // Divide cell into 0-1 uv
       "     posTexCoord *= float2(Width.x, Height.x);                      \n" +
       "     posTexCoord = float2(1,1) - posTexCoord;                       \n" +
       "     float2 circleCoord = float2(0.5, 0.5);                         \n" +    // creation of circles (dots)
       "     circleCoord -= posTexCoord;                                    \n" +
       "     float distance = length(circleCoord);                          \n" +
       "	float4 col = tex2D( tex0, tileCoord );  	                    \n" + 
       "	float4 ColorTexture =  col * step( 0, (0.5 * col.a) - distance);\n" +  // Final output color
       "	float4 fogcol = FogColor*(1-Fog);								\n"	+
       "	Output.RGBColor =  float4(ColorTexture.rgb*Fog+fogcol.rgb,ColorTexture.a);	\n" + 
       "	return Output;								                    \n" +
       "}";

      var me = this;
      myShaderCallBack = function () {
           
           var amount = me.Circles_amount;
           var GlobalfogEnable = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"Fog");
	       var fogEnable = me.Fog_Enabled;
	       if(fogEnable && GlobalfogEnable){var fogenable = 1;var fogDensity = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogDensity");
	       var fogColor = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogColor");}
	       else{ var fogenable = 0; var fogColor = new vector3d(1,1,1)};
   
           ccbSetShaderConstant(2, 'Width', amount, 0, 0, 0);
           ccbSetShaderConstant(2, 'Height', amount, 0, 0, 0);
           ccbSetShaderConstant(2, 'FogColor', fogColor.x,fogColor.y,fogColor.z,1);
           ccbSetShaderConstant(1, 'mFogDensity', fogDensity,0,0,0);
           ccbSetShaderConstant(1, 'fogEnable', fogenable,0,0,0);
           
       }
   
       // creating Material
       var newMaterial = ccbCreateMaterial(vertexShader, fragmentShader, this.Base_material_type,myShaderCallBack);
   
       //Check Material index and apply to specified mat index or to all the materials.
       var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);
   
       for (var i = 0; i < matCount; ++i) {
           if (this.Affect_all_material) {
               ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial);
           }
           else { ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial); }
       }
   }
//=======================================
// This is a CopperCube behavior which enables the player or NPCs to suffer damage when falling down from higher objects.
// The following params can be adjusted:
//=======================================
// player_node: affected player or npc node with also built-in behaviors "Game Actor with Health" & "Collide when moved (AffectedByGravity: yes)" enabled
//=======================================
// groundcheck_distance: adjust according to the "Collide when moved" behavior's Y-Size & Y-Position -> must show "onground = 1" on solid ground (console)
//=======================================
// damage_treshold: defines the minimum height from which the damage amount is calculated depending on the increasing fall height
//=======================================
// damage_factor: increase or decrease the overall relative amount of fall damage
//=======================================
// -----> by CopperCube forum member hadoken 2021 <-----
//
// (UPDATE: - fixed y_high reset at "onground = 1 & falldistance < this.damage_treshold")

/*
	<behavior jsname="behavior_HadokenFallDamage" description="behavior_HadokenFallDamage">
		<property name="player_node" type="scenenode" />	
		<property name="groundcheck_distance" type="float" default="20" />
		<property name="damage_treshold" type="float" default="80" />
		<property name="damage_factor" type="float" default="0.5" />		
	
	</behavior>
*/

behavior_HadokenFallDamage = function()
{
	this.onground = 1;
	this.y_high = 0;
	this.y_low = 0;
}

behavior_HadokenFallDamage.prototype.onAnimate = function()
{
	var player_node_pos = ccbGetSceneNodeProperty(this.player_node, "Position");

	var cx = player_node_pos.x;
	var cy = player_node_pos.y;
	var cz = player_node_pos.z;
	
	if (ccbGetCollisionPointOfWorldWithLine(cx, cy, cz, cx, cy-this.groundcheck_distance, cz)) {this.onground = 1;}
	else {this.onground = 0;}
     
	if (this.onground == 1) {this.y_low = player_node_pos.y;}

	if (this.onground == 0 && this.y_high <= player_node_pos.y) {this.y_high = player_node_pos.y;}
	
	var falldistance = this.y_high - this.y_low;

	// determine corresponding CopperCube health variable:
	var name = ccbGetSceneNodeProperty(this.player_node, "Name");
	var prefix = "#";	
	var suffix = ".health";	
	var prefix_plus_nodename = (prefix.concat(name)).toString();
	var cc_health_var = (prefix_plus_nodename.concat(suffix)).toString();
	//print (cc_health_var);

	if (this.onground == 1 && falldistance >= this.damage_treshold) 
	{
		ccbSetCopperCubeVariable(cc_health_var, (ccbGetCopperCubeVariable(cc_health_var) - this.damage_factor * falldistance));		
		this.y_high = 0;
	}
	
	if (this.onground == 1 && falldistance <= this.damage_treshold) 
	{
		this.y_high = 0;
	}

	//print("onground = " + this.onground);
}

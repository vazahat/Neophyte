//Snap to any Object on any direction created by Vazahat Pathan (just_in_case) based on Robert Codell's drop to ground plugin.

//Snap to Left (on negative of X axis)//
function snapToObjectNegativeX()
{
	var s = editorGetSelectedSceneNode();
	var type = ccbGetSceneNodeProperty(s, "Type");
	if (type.indexOf("mesh") != -1)
{
	
	var pos = ccbGetSceneNodeProperty(s, "Position");
	for (i=0; i<501; i++)
	{
	var adj = i/10;
	if (ccbDoesLineCollideWithBoundingBoxOfSceneNode(s, pos.x-100, pos.y, pos.z, pos.x-50+adj, pos.y, pos.z))
		{
	var dist = 50-adj;
	i = 500;
		}
	}
	var gnd = ccbGetCollisionPointOfWorldWithLine(pos.x, pos.y, pos.z, pos.x-500, pos.y, pos.z);
	if (gnd != null && dist != undefined) 
	{
	ccbSetSceneNodeProperty(s,"Position",gnd.x+dist, gnd.y, gnd.z);
	editorUpdateAllWindows();
	} else if (dist != undefined)
		{
		alert("no object found on negative X axis to snap");
		}
		else
		{
		alert("try move it slightly (can't be child node)");
		}
} else
	{
	alert("selected node has no 3D geometry");
	}
}

//Snap to Right (on Positive of X axis)//
function snapToObjectPositiveX()
{
	var s = editorGetSelectedSceneNode();
	var type = ccbGetSceneNodeProperty(s, "Type");
	if (type.indexOf("mesh") != -1)
{
	
	var pos = ccbGetSceneNodeProperty(s, "Position");
	for (i=0; i<501; i++)
	{
	var adj = i/10;
	if (ccbDoesLineCollideWithBoundingBoxOfSceneNode(s, pos.x+100, pos.y, pos.z, pos.x+50-adj, pos.y, pos.z))
		{
	var dist = 50-adj;
	i = 501;
		}
	}
	var top = ccbGetCollisionPointOfWorldWithLine(pos.x, pos.y, pos.z, pos.x+500, pos.y, pos.z);
	if (top != null && dist != undefined) 
	{
	ccbSetSceneNodeProperty(s,"Position",top.x-dist, top.y, top.z);
	editorUpdateAllWindows();
	} else if (dist != undefined)
		{
		alert("no object found on positive X axis to snap");
		}
		else
		{
		alert("try move it slightly (can't be child node)");
		}
} else
	{
	alert("selected node has no 3D geometry");
	}
}


//Snap to Back (on negative of Z axis)//
function snapToObjectNegativeZ()
{
	var s = editorGetSelectedSceneNode();
	var type = ccbGetSceneNodeProperty(s, "Type");
	if (type.indexOf("mesh") != -1)
{
	
	var pos = ccbGetSceneNodeProperty(s, "Position");
	for (i=0; i<501; i++)
	{
	var adj = i/10;
	if (ccbDoesLineCollideWithBoundingBoxOfSceneNode(s, pos.x, pos.y, pos.z-100, pos.x, pos.y, pos.z-50+adj))
		{
	var dist = 50-adj;
	i = 500;
		}
	}
	var gnd = ccbGetCollisionPointOfWorldWithLine(pos.x, pos.y, pos.z, pos.x, pos.y, pos.z-500);
	if (gnd != null && dist != undefined) 
	{
	ccbSetSceneNodeProperty(s,"Position",gnd.x, gnd.y, gnd.z+dist);
	editorUpdateAllWindows();
	} else if (dist != undefined)
		{
		alert("no object found on negative Z axis to snap");
		}
		else
		{
		alert("try move it slightly (can't be child node)");
		}
} else
	{
	alert("selected node has no 3D geometry");
	}
}

//Snap to Front (on Positive of Z axis)//
function snapToObjectPositiveZ()
{
	var s = editorGetSelectedSceneNode();
	var type = ccbGetSceneNodeProperty(s, "Type");
	if (type.indexOf("mesh") != -1)
{
	
	var pos = ccbGetSceneNodeProperty(s, "Position");
	for (i=0; i<501; i++)
	{
	var adj = i/10;
	if (ccbDoesLineCollideWithBoundingBoxOfSceneNode(s, pos.x, pos.y, pos.z+100, pos.x, pos.y, pos.z+50-adj))
		{
	var dist = 50-adj;
	i = 501;
		}
	}
	var top = ccbGetCollisionPointOfWorldWithLine(pos.x, pos.y, pos.z, pos.x, pos.y, pos.z+500);
	if (top != null && dist != undefined) 
	{
	ccbSetSceneNodeProperty(s,"Position",top.x, top.y, top.z-dist);
	editorUpdateAllWindows();
	} else if (dist != undefined)
		{
		alert("no object found on positive Z axis to snap");
		}
		else
		{
		alert("try move it slightly (can't be child node)");
		}
} else
	{
	alert("selected node has no 3D geometry");
	}
}


//Snap to Bottom (on negative of Y axis)//
function snapToObjectNegativeY()
{
	var s = editorGetSelectedSceneNode();
	var type = ccbGetSceneNodeProperty(s, "Type");
	if (type.indexOf("mesh") != -1)
{
	
	var pos = ccbGetSceneNodeProperty(s, "Position");
	for (i=0; i<501; i++)
	{
	var adj = i/10;
	if (ccbDoesLineCollideWithBoundingBoxOfSceneNode(s, pos.x, pos.y-100, pos.z, pos.x, pos.y-50+adj, pos.z))
		{
	var dist = 50-adj;
	i = 500;
		}
	}
	var gnd = ccbGetCollisionPointOfWorldWithLine(pos.x, pos.y, pos.z, pos.x, pos.y-500, pos.z);
	if (gnd != null && dist != undefined) 
	{
	ccbSetSceneNodeProperty(s,"Position",gnd.x, gnd.y+dist, gnd.z);
	editorUpdateAllWindows();
	} else if (dist != undefined)
		{
		alert("no object found on negative Y axis to snap");
		}
		else
		{
		alert("try move it slightly (can't be child node)");
		}
} else
	{
	alert("selected node has no 3D geometry");
	}
}

//Snap to Top (on Positive of Y axis)//
function snapToObjectPositiveY()
{
	var s = editorGetSelectedSceneNode();
	var type = ccbGetSceneNodeProperty(s, "Type");
	if (type.indexOf("mesh") != -1)
{
	
	var pos = ccbGetSceneNodeProperty(s, "Position");
	for (i=0; i<501; i++)
	{
	var adj = i/10;
	if (ccbDoesLineCollideWithBoundingBoxOfSceneNode(s, pos.x, pos.y+100, pos.z, pos.x, pos.y+50-adj, pos.z))
		{
	var dist = 50-adj;
	i = 501;
		}
	}
	var top = ccbGetCollisionPointOfWorldWithLine(pos.x, pos.y, pos.z, pos.x, pos.y+500, pos.z);
	if (top != null && dist != undefined) 
	{
	ccbSetSceneNodeProperty(s,"Position",top.x, top.y-dist, top.z);
	editorUpdateAllWindows();
	} else if (dist != undefined)
		{
		alert("no object found on positive Y axis to snap");
		}
		else
		{
		alert("try move it slightly (can't be child node)");
		}
} else
	{
	alert("selected node has no 3D geometry");
	}
}



editorRegisterMenuEntry("snapToObjectPositiveX()", "snap to Object PositiveX\tShift+X");
editorRegisterMenuEntry("snapToObjectNegativeX()", "snap to Object NegativeX\tShift+Ctrl+X");
editorRegisterMenuEntry("snapToObjectPositiveZ()", "snap to Object PositiveZ\tShift+Z");
editorRegisterMenuEntry("snapToObjectNegativeZ()", "snap to Object NegativeZ\tShift+Ctrl+Z");
editorRegisterMenuEntry("snapToObjectPositiveY()", "snap to Object PositiveY\tShift+Y");
editorRegisterMenuEntry("snapToObjectNegativeY()", "snap to Object NegativeY\tShift+Ctrl+Y");

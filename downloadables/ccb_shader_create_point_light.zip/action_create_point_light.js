/*	Info 
	
	Extension Name	: Action Create Point Light
	Extension Type	: Action
	Author:			: Vazahat Khan (just_in_case)
	Date Created	: ‎‎July ‎11, ‎2021, 01:28 PM
	Description		: Convert any specified node into a point light with many lighting options. 
	
*/
/* 	Donate
	
	If you like my work, please consider "buy me a cup of coffee" to support me.
	You can do that via PayPal :)
	
	PayPal: http://paypal.me/Vazahat
	

*/
/*	Changelog

    [July 11, ‎2021]	- Added Basic Shader code with diffuse color
					- Added basic light with color
					- Added Diffuse lighting with color
					- Added ambient lighting with color
					- Added Specular lighting with color and specular texture
					- Added Specular Brightness (specular strength) to control specularity
	[July 12, 2021]	- Added Attenuation to control light strength
					- Converted the Shader into an action
					- Added different parameters (Actions property to control the shader)
					- Added Function to convert decimal color into RGB to fix color parameters of the action
    [July 13, 2021] - Added ability to turn ON and OFF Specular lighting
					- Added ability to either specify an external specular texture or to supply in irredit/irrlicht tools as a  second texture
					- Added option to auto use default texture as specular map if specular lighting is turned on an no texture is specified
					- Added option to affect specific material or to affect all materials of the affected node
					- Added option to choose a base material type for the Shader ( not all the material types worked for example normal map doesn't work)
					  Use material type id for base material type for example (12 for Tranparent_Add material type)
	[July 14, 2021] - Fixed a bug which was causing to shader to use properties from last action for all nodes if multiple actions were apllied with different
					  propertis. Previously global variables were used which was causing the issue, Now Fixed
					- Added missing code which to make the specularity works for all the materials not just with the first material.
					- Fixed some more bugs with Specular texture and with affecting all the material types
					- Added Material index to start with 1 instead of zeo to remove confusion
					

	
*/



/* Usage
  
  Attach this action to a behavior event and then specify a scenenode in "Light_source" which will act as point light, specify an "Affecting_node"
  which will get affected by the light created using this shader. Specify additional light properties like light color, diffuse colo, ambiernt color,
  specular color and specular texture if specular lighting is turned on. You can adjust the strength of light and Specularity using the provide parameters.
  check if you want to affect all the materials of the "Affecting node" or you can uncheck it and can speicfy specific material index (for example zero "0"
  if you want to affect first material of the node only). You can also specify a "Base_material_type" to blend the shader with other material type for exmaple 
  (12 if you want to use Tranparent_Add as base material type). Not all the materials blend with the shader, only a few can be blended with shaders.
  
  NOTE:- Debugging window of the game/app can throw an error failed to load a texture if Specular lighting is OFF (it is not a error or bug neither it affect
  the game) this is use to turn ON/OFF Specular lighting. You can ignore the error in debugging window.
*/

/*  <action jsname="action_create_point_light" description="Shader action to convert any node into a Point Light">
	  <property name="Light_source" type="scenenode"/>
	  <property name="Affecting_node" type="scenenode"/>
	  <property name="Affect_all_material" type="bool" default="true" />
	  <property name="Affecting_material" type="int" default="1" />
	  <property name="Base_material_type" type="int" default="0" />
	  <property name="Light_strength" type="int" default="10" />
	  <property name="Light_color" type="color"	default="ffFFFFFF"/>
	  <property name="Diffuse_color" type="color"	default="ffFFFFFF"/>
	  <property name="Ambient_color" type="color" default="ff000000"/>
	  <property name="Specular_lighting" type="bool" default="true" />
	  <property name="Specular_color" type="color"	default="ffFFFFFF"/>
	  <property name="Specular_Texture" type="string"/>
	  <property name="Specularity_strength" type="int" default="40" />
	  
	  
    </action>
*/
action_create_point_light = function()
{

};

action_create_point_light.prototype.execute = function()
{	
	var Specular_Texture = "";
	this.Affecting_material -= 1;
	//Specular texture handler.
	var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);
	if (this.Specular_lighting)
	{
		if(this.Specular_Texture == null || this.Specular_Texture == "" ||this.Specular_Texture == undefined)
		{
			var NoSpecTex = ccbGetSceneNodeMaterialProperty(this.Affecting_node,this.Affecting_material,"Texture1");
			var defaultSpecTex = ccbGetSceneNodeMaterialProperty(this.Affecting_node,this.Affecting_material,"Texture2");
			if(defaultSpecTex == null || defaultSpecTex == "" || defaultSpecTex == undefined)
			{
				Specular_Texture = ccbLoadTexture(NoSpecTex);

			for(var i=0; i<matCount; ++i)	// to fix specularity with all materials.
			{
				if(this.Affect_all_material)
				{
					ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Texture2', Specular_Texture);
				}
				else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Texture2', Specular_Texture);}
			}
				
			}
			else{Specular_Texture = ccbLoadTexture(defaultSpecTex);}
			
		}
		else
		{
			Specular_Texture = ccbLoadTexture(this.Specular_Texture);
			for(var i=0; i<matCount; ++i)	// to fix specularity with all materials.
			{
				if(this.Affect_all_material)
				{
					ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Texture2', Specular_Texture);
				}
				else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Texture2', Specular_Texture);}
			}
		}
		
	}
	else 
	{
		for(var i=0; i<matCount; ++i)	// to fix specularity with all materials.
			{
				if(this.Affect_all_material)
				{
					ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Texture2', undefined);
				}
				else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Texture2', undefined);}
			}
	}
	
//Shader Part
var vertexShader = 
"		float4x4 mWorldViewProj;  // World * View * Projection 					\n" + 
"		float4x4 mTransWorld;     // Transposed world matrix					\n" +
"		float4x4 mInvWorld;       // Inverted world matrix	 					\n" + 
"		float3 lightPos ;														\n" +
"		float3 cameraPos ;														\n" + 
"		// Output to fragment program V2F										\n" + 
"		struct VS_OUTPUT														\n" + 
"		{																		\n" + 
"			float4 Position   : POSITION;   // vertex position 					\n" + 
"			float2 TexCoord   : TEXCOORD0;  // tex coords						\n" + 
"			float3 worldNormal  : TEXCOORD1;  // tex coords						\n" +
"			float3 lightVec   : TEXCOORD2;   // vertex Diffuse color			\n" + 
"			float3 eyeVec   : TEXCOORD3;										\n" +
"		};																		\n" + 
"																				\n" + 
"			//Input From app to vertex program A2V								\n" + 
"		VS_OUTPUT main      ( in float4 vPosition : POSITION,					\n" +
"		                      in float3 vNormal   : NORMAL,						\n" +
"		                      float2 texCoord     : TEXCOORD0 )					\n" +  
"		{																		\n" + 
"			//Vertex Shader														\n" + 
"			VS_OUTPUT Output;													\n" + 
"																				\n" + 
"			Output.Position = mul(vPosition, mWorldViewProj);					\n" + 
"			Output.worldNormal = mul(vNormal, mInvWorld);						\n" +
"			float3 worldSpacePos = mul(mTransWorld, vPosition);					\n" + 
"			Output.lightVec = lightPos - worldSpacePos;							\n" +
"			Output.eyeVec = cameraPos - worldSpacePos;							\n" +	
"			Output.TexCoord = texCoord;											\n" + 
"			return Output;														\n" + 
"		}";

var fragmentShader = 
"		struct PS_OUTPUT																\n" + 
"		{																				\n" + 
"		    float4 RGBColor : COLOR; 		  											\n" +	
"		};																				\n" +
"																						\n" + 
"		float4 lightColor;																\n" +
"		float4 AmbientColor;															\n" +
"		float4 DiffuseColor;															\n" +
"		sampler2D tex0;																	\n" + 
"		sampler2D tex1;																	\n" +
"		float4 SpecularColor;															\n" +
"		float4  SBrightness;															\n" +
"		float4  lightAttenuation;														\n" +
"																						\n" +
"		PS_OUTPUT main( float2 TexCoord : TEXCOORD0,									\n" +
"						float3 worldNormal  : TEXCOORD1,								\n" +
"						float3 lightVec  : TEXCOORD2,									\n" +
"						float3 eyeVec  : TEXCOORD3,										\n" +
"		                float4 Position : POSITION)										\n" +
"		{ 																				\n" +
"			PS_OUTPUT Output;															\n" +
"		    float4 ColorTexture = tex2D(tex0, TexCoord);								\n" +
"		    float4 SpecularTexture = tex2D(tex1, TexCoord);								\n" +
"			float3 N = normalize(worldNormal);											\n" +
"			float3 L = normalize(lightVec);												\n" +
"			float3 E = normalize(eyeVec);												\n" +
"			float3 HalfAngle = normalize(L + E); 										\n" +
"			float NdotH = saturate(dot(N,HalfAngle));									\n" +
"			float SB = SBrightness.x * SpecularTexture.a;								\n" +
"			float SPower = pow(NdotH, SB); 												\n" +
"			float4 Ambient = AmbientColor * ColorTexture; 								\n" +	
"			float4 diffuselight = saturate(dot(N,L)) * lightColor; 						\n" +
"			float4 Specular = SPower * SpecularColor * SpecularTexture; 				\n" +
"			float4 Diffuse = DiffuseColor * ColorTexture * diffuselight; 				\n" +	
"			float d = length(lightVec);													\n" +	
"			float attenuation =  (1 / d) * lightAttenuation.x; 							\n" +	
"			float4 light = (Diffuse + Specular) * lightColor * attenuation;				\n" +
"			Output.RGBColor =   Ambient + light;										\n" + 
"			return Output;																\n" +
"		}";

var me = this; 
this.registeredFunction = function() { me.GV(); }; 
//Shader Callaback Function
myShaderCallBack = function()
{
	var parameter = me.GV();
	var cam =  ccbGetActiveCamera();
	this.camPos = ccbGetSceneNodeProperty(cam,"Position");
	var light = ccbGetSceneNodeFromName(parameter.Light_source);
	var lightpos = ccbGetSceneNodeProperty(light,"Position");
	var lightcolor = RGB(parameter.Light_color);
	var Diffusecolor = RGB(parameter.Diffuse_color);
	var Ambientcolor = RGB(parameter.Ambient_color);
	this.Specularcolor = RGB(parameter.Specular_color);
	this.SB = parameter.Specularity_strength;
	this.AB = parameter.Light_strength;
	ccbSetShaderConstant(1, 'lightPos', lightpos.x,lightpos.y,lightpos.z,0);
	ccbSetShaderConstant(1, 'cameraPos', this.camPos.x,this.camPos.y,this.camPos.z,0);
	ccbSetShaderConstant(2, 'lightColor', lightcolor.x,lightcolor.y,lightcolor.z,1);
	ccbSetShaderConstant(2, 'AmbientColor', Ambientcolor.x,Ambientcolor.y,Ambientcolor.z,1);
	ccbSetShaderConstant(2, 'DiffuseColor', Diffusecolor.x,Diffusecolor.y,Diffusecolor.z,1);
	ccbSetShaderConstant(2, 'SpecularColor', this.Specularcolor.x,this.Specularcolor.y,this.Specularcolor.z,1);
	ccbSetShaderConstant(2, 'SBrightness', this.SB,1,1,1);
	ccbSetShaderConstant(2, 'lightAttenuation', this.AB,1,1,1);	
}
// creating Material
var newMaterial = ccbCreateMaterial(vertexShader, fragmentShader, this.Base_material_type, myShaderCallBack);

//Check Material index and apply to sepcifed mat index or to all the materials.
var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

for(var i=0; i<matCount; ++i)
{
	if(this.Affect_all_material)
	{
		ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial);
	}
	else {ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial);}
}

}
action_create_point_light.prototype.GV = function()
{
	return {
			Light_source : ccbGetSceneNodeProperty(this.Light_source,"Name"),
			Light_strength : this.Light_strength,
			Light_color : this.Light_color,
			Diffuse_color : this.Diffuse_color,
			Ambient_color : this.Ambient_color,
			Specular_lighting : this.Specular_lighting,
			Specular_color : this.Specular_color,
			Specularity_strength : this.Specularity_strength
			}
}
// Fixing the Color Property type Parameter of action to get RGB value and clamp them between 0 and 1.
function RGB(decimalcolorcode)
{var color = (decimalcolorcode); // use the property type or put a  decimal color value.
 var Rr = (color & 0xff0000) >> 16; // get red color by bitwise operation  
 var Gg = (color & 0x00ff00) >> 8; // get green color by bitwise operation 
 var Bb = (color & 0x0000ff); // get blue color by bitwise operation 
 var RrGgBb = new vector3d(Rr,Gg,Bb);
 var r = (Rr/255); // dividing red by 255 to clamp b/w 0-1 
 var g = (Gg/255); // dividing green by 255 to clamp b/w 0-1 
 var b = (Bb/255); // dividing blue by 255 to clamp b/w 0-1 
 var rgb = new vector3d (r,g,b); // final rgb value to use in the editor
 return rgb;
 }
 
 
 /*End Of Code*/
 
// Above extension is written by Vazahat Khan (just_in_case) //
 
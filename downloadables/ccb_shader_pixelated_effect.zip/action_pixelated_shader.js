/*	Info 
	
    Extension Name	: Action Pixelated effect shader
    Extension Type	: Action
    Author:			: Vazahat Khan (just_in_case)
    Date Created	: December 16, 2021, 03:01 PM
    Description		: Allows you to apply pixelated effect to any texture. 
	
*/
/* 	Donate
	
    If you like my work, please consider "buy me a cup of coffee" to support me.
    You can do that via PayPal :)
	
    PayPal: http://paypal.me/Vazahat
	Discord Server :- https://discord.gg/RKcq89S7uA
	YouTube :- https://www.youtube.com/GlitchedVelocity
	Itch.io :- https://vazahat.itch.io/
    Website - https://neophyte.cf
	

*/
/*	Changelog

    [December 16, 2021]	- Added Basic Shader code
                        - Added Shader Constants to use in shaders 
                        - Creation of grid in shader with ( horizontal and vertial values)
                        - Adjusted grid size and did  other calculations
                    	- Converted the Shader into an action
                        - Added different parameters (Actions property to control the shader)
                        - Wasted so many hours debugging an issue with animation timing
                        - Added animation speed multiplier in the code and as parameter in action property 
                        - Added functionality to inverse the Animation and added the parameter to check uncheck inverted animation
                        - Fixed some bugs that are encountered when inverse animation was been added
    [December 17, 2021] - Added ability to execute an action after the pixelation is cpmpleted
    [July 12, 2022]	- Added Support for fog ( windows platform only). 
      
    [To Do's]             - Ability to animate from current pixelated form to desired pixelated form
                   

*/



/* Usage
  Attach this action to a behavior and fill the parameters, Select the Affecting_node (the node on you want to get affected by this shader), Set the base_material_type, and texture X resoultion and Y resolution
  according to your texture resolution. Then insert the Number of pixels you want horizontally and vertically and supply the speed of animation and a action when the animation get finished.
  
    Itch.io - https://vazahat.itch.io/
    Youtube - https://www.youtube.com/channel/UC_yfoGEKkmY63tnyy6hR7ZQ
    Website - https://neophyte.cf
    Discord - https://discord.gg/RKcq89S7uA
  
*/

/*  <action jsname="action_pixelated_shader" description="Pixelated effect">
      <property name="Affecting_node" type="scenenode"/>
      <property name="Affect_all_material" type="bool" default="true" />
      <property name="Affecting_material" type="int" default="1" />
      <property name="Base_material_type" type="int" default="13" />
      <property name="Texture_X_res" type="int"	default="512"/>
      <property name="Texture_Y_res" type="int"	default="512"/>
      <property name="Horizontal_pixels" type="int" default="12" />
      <property name="Vertical_pixels" type="int"	default="20"/>
      <property name="Animation_Speed" type="int"	default="1"/>
      <property name="Inverted_animation" type="bool"	default="false"/>
      <property name="Action_on_finish" type="action"	default="20"/>      
	  <property name="Fog_Enabled" type="bool" default="true" />
    </action>
*/

if (!PixelatedCache)
    var PixelatedCache = {};

action_pixelated_shader = function () { };

action_pixelated_shader.prototype.execute = function () {

    this.Affecting_material -= 1;
    this.nodeName = ccbGetSceneNodeProperty(this.Affecting_node,"Name");
    //print(PixelatedCache.Texture_X_res);

    if(!PixelatedCache[this.nodeName]) PixelatedCache[this.nodeName] = {Texture_X_res: false, Texture_Y_res: false};
    if (this.Texture_X_res == PixelatedCache[this.nodeName].Texture_X_res && this.Texture_Y_res == PixelatedCache[this.nodeName].Texture_Y_res) return false;
    PixelatedCache[this.nodeName].Texture_X_res = this.Texture_X_res;
    PixelatedCache[this.nodeName].Texture_Y_res = this.Texture_Y_res;
    


    //Shader Part


    var vertexShader =
        "float4x4 mWorldViewProj;  // World * View * Projection \n" +
        "float4x4 mInvWorld;       // Inverted world matrix	 	\n" +
        "float4x4 mTransWorld;     // Transposed world matrix	\n" +
        "float mFogDensity ;									\n" + 
        "float fogEnable ;				    					\n" + 
        "														\n" +
        "// Vertex shader output structure						\n" +
        "struct VS_OUTPUT										\n" +
        "{														\n" +
        "	float4 Position   : POSITION;   // vertex position 	\n" +
        "	float4 Diffuse    : COLOR0;     // vertex diffuse 	\n" +
        "	float2 TexCoord   : TEXCOORD0;  // tex coords		\n" +
        "	float Fog	: FOG;									\n" +
        "};														\n" +
        "														\n" +
        "VS_OUTPUT main      ( in float4 vPosition : POSITION,	\n" +
        "                      in float3 vNormal   : NORMAL,	\n" +
        "                      float2 texCoord     : TEXCOORD0 )\n" +
        "{														\n" +
        "	VS_OUTPUT Output;									\n" +
        "														\n" +
        "	// transform position to clip space 				\n" +
        "	Output.Position = mul(vPosition, mWorldViewProj);	\n" +
        "														\n" +
        "	// transformed normal would be this:				\n" +
        "	float3 normal = mul(vNormal, mInvWorld);			\n" +
        "														\n" +
        "	// position in world coodinates	would be this:		\n" +
        "	// float3 worldpos = mul(mTransWorld, vPosition);	\n" +
        "														\n" +
        "	Output.Diffuse = float4(1.0, 1.0, 1.0, 1.0);		\n" +
        "	Output.TexCoord = texCoord;							\n" +
        "			if (fogEnable == 1)							\n" + 
        "   		{ 											\n" + 
        "     			Output.Fog = saturate(1.0 / exp(Output.Position.z * mFogDensity));	\n" + 
        "  			}											\n" + 
        "  			else										\n" + 
        "  			 {     										\n" + 
        "     			Output.Fog = 1;							\n" + 
        "   		 }  				    					\n" + 
        "														\n" +
        "	return Output;										\n" +
        "}														";

    var fragmentShader =
        "struct PS_OUTPUT													\n" +
        "{																	\n" +
        "    float4 RGBColor : COLOR0; 		  								\n" +
        "};																	\n" +
        "																	\n" +
        "float4 HorizontalPixel;											\n" +
        "float4 VerticalPixel;												\n" +
        "float4 FogColor;													\n" +
        "sampler2D tex0;													\n" +
        "																	\n" +
        "PS_OUTPUT main( float2 TexCoord : TEXCOORD0,						\n" +
        "                float4 Position : POSITION,						\n" +
        "				 float Fog    : FOG,			                    \n" +
        "                float4 Diffuse  : COLOR0 ) 						\n" +
        "{ 																	\n" +
        "	PS_OUTPUT Output;												\n" +
        "   float colm = HorizontalPixel.x;									\n" + 
        "   float rw = VerticalPixel.x;										\n" +
        "   float2 blockcount = { colm, rw }; 		                        \n" + //creation of grid (blocks) 
        "   float2 blockSize = 1.0 / blockcount;		                    \n" + //setting gridsize
        "   bool differentRow = floor(TexCoord.y / blockSize.y) % 2.0 >= 1.0; \n" + 
        "   if (differentRow)                                               \n" +
        "   {                                                               \n" +
        "        TexCoord.x += blockSize.x / 2.0;                           \n" +
        "   }                                                               \n" +
        "                                                                   \n" +
        "   float2 blockNumber = floor(TexCoord / blockSize);               \n" +
        "   float2 blockcenter = blockNumber * blockSize + blockSize / 2;   \n" +
        "	float4 col = tex2D( tex0, blockcenter );      					\n" + //setting final output texcoords
        "	float4 fogcol = FogColor*(1-Fog);								\n"	+
        "	Output.RGBColor =  float4(col.rgb*Fog+fogcol.rgb,col.a);	    \n" + 
        "	return Output;													\n" +
        "}";

    var me = this;
    var HCurrentPixels = this.Texture_X_res; // horizontal Current pixels ( we defined the horizontal resolution of texture here.)
    var VCurrentPixels = this.Texture_Y_res; // vertical current pixels ( we defined the vertical resolution of texture here.)
    // for inverting the animation
    if(this.Inverted_animation)
    {
        HCurrentPixels = 1;
        VCurrentPixels = 1;
    }

    // for setting equal time for horizontal and vertical animation
    if(me.Horizontal_pixels > me.Vertical_pixels){ VCurrentPixels += me.Horizontal_pixels - me.Vertical_pixels};
    if(me.Horizontal_pixels < me.Vertical_pixels){ HCurrentPixels += me.Vertical_pixels - me.Horizontal_pixels};

    //Shader Callback

    myShaderCallBack = function () {
       
        //Animation part
        //from original to pixelated amount
        var GlobalfogEnable = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"Fog");
        var fogEnable = me.Fog_Enabled;
        if(fogEnable && GlobalfogEnable){var fogenable = 1;var fogDensity = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogDensity");
        var fogColor = ccbGetSceneNodeProperty(ccbGetRootSceneNode(),"FogColor");}
        else{ var fogenable = 0; var fogColor = new vector3d(1,1,1)};

        if(!me.Inverted_animation && !me.Loop_animation)
        {
            if (HCurrentPixels > me.Horizontal_pixels) { HCurrentPixels -= me.Animation_Speed; }; // check if the horizontal currentpixel is greater than  horizontal pixel defined in property, then decrease the current pixel
            if (VCurrentPixels > me.Vertical_pixels) { VCurrentPixels -= me.Animation_Speed; };
            if (HCurrentPixels < me.Horizontal_pixels) { HCurrentPixels  = me.Horizontal_pixels};
            if (VCurrentPixels < me.Vertical_pixels) {VCurrentPixels = me.Vertical_pixels};
            
        }
        //from fully pixelated to desired pixelated
        if(me.Inverted_animation && !me.Loop_animation)
        {   
            if (HCurrentPixels < me.Horizontal_pixels) { HCurrentPixels += me.Animation_Speed; }; // check if the horizontal currentpixel is greater than  horizontal pixel defined in property, then decrease the current pixel
            if (VCurrentPixels < me.Vertical_pixels) { VCurrentPixels += me.Animation_Speed; };   
        }

        
        //Executing the action on complete animation cycle
        if(HCurrentPixels == me.Horizontal_pixels && VCurrentPixels == me.Vertical_pixels)
        {
            ccbInvokeAction(me.Action_on_finish);
        }

        //setting shader constant values
        var horizontal_pixels = HCurrentPixels;
        var vertical_pixels = VCurrentPixels;

        ccbSetShaderConstant(2, 'HorizontalPixel', horizontal_pixels, 0, 0, 0);
        ccbSetShaderConstant(2, 'VerticalPixel', vertical_pixels, 0, 0, 0);
        ccbSetShaderConstant(2, 'FogColor', fogColor.x,fogColor.y,fogColor.z,1);
        ccbSetShaderConstant(1, 'mFogDensity', fogDensity,0,0,0);
        ccbSetShaderConstant(1, 'fogEnable', fogenable,0,0,0);
    }

    // creating Material
    var newMaterial = ccbCreateMaterial(vertexShader, fragmentShader, this.Base_material_type, myShaderCallBack);

    //Check Material index and apply to specified mat index or to all the materials.
    var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

    for (var i = 0; i < matCount; ++i) {
        if (this.Affect_all_material) {
            ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial);
        }
        else { ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial); }
    }
}
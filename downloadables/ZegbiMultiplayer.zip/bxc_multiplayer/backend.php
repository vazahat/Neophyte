<?php
header('Access-Control-Allow-Origin: *');
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(-1);
$filename  = dirname(__FILE__).'/data.txt';

function userExist($user_id,$data)
{

	return $result;
}

// store new message in the file
$data = isset($_GET['data']) ? $_GET['data'] : '';
if ($data !== '' && strlen($data)>1)
{
	$insert	="";
// extraigo datos del usuario 
	
	$user_data 	= str_replace("{","",$data);
	$user_data 	= str_replace("}","",$user_data);
	$user 		= explode(";",$user_data);
	$user_id	= $user[0];
	$content_new=false;
		
	$result = file_get_contents($filename);

	$file	= explode("},{", $result);

	$content="";
	$isUser=false;
	$addRecord=true;
	for ($i=0;$i<count($file);$i=$i+1)
	{
		if ($i==0){$content.="{";}else{$content.=",{";}
		$file[$i] = str_replace("{","",$file[$i]);
		$file[$i] = str_replace("}","",$file[$i]);
		$file_data = explode(";",$file[$i]);
		$isUser=false;
		if (count ($file_data)> 0 && isset($file_data[3]))
		{
			$current_time=date('YmdHis');
			$descuento=$current_time-$file_data[3];
			//echo "---".$descuento;exit();
			if ($descuento<60 && isset($user[1]))
			{
				for ( $t=0;$t<count($file_data); $t=$t+1)
				{

					$comodin="";
					if ($t==0)
					{
						$file_id=$file_data[0];
						if ($file_id==$user_id)
						{
							$isUser=true;
							
						}
					}else{
						$comodin=";";
					}
					// add current timpestamp
					if ($t==3)
					{
						if ($isUser)
						{
							$content.=$comodin."".date('YmdHis');
							$addRecord=false;
							$comodin="";
						}else{
							$content.=$comodin."".$file_data[$t];
							
							$comodin="";
						}
					}else{
						if ($isUser && isset($user[$t]) )
						{
							$content.=$comodin."".$user[$t];
							$addRecord=false;
							$comodin="";
						}else{
							$content.=$comodin.$file_data[$t];
							$comodin="";
						}
					}

				}
			}
		}
		$content.="}";
	}
// armo archivo desde el servidor
	//$insert = count($user);
	if (!$isUser)
	{
		if (count($user)> 0 && $addRecord==true)
		{
			for ( $t=0;$t<count($user);$t=$t+1 )
			{
				if ($t==0)
					{
						$content_new.=$user[$t];
					}else{
						$content_new.=";".$user[$t];
					}
				
			}
		$tiempo = date('YmdHis');
		$content.=",{".$content_new.";".$tiempo.";holi}";		
		}
		
	}
	$content = str_replace("{},", "", $content);
	file_put_contents($filename,$content);
}

$result = file_get_contents($filename);

echo $result ;

?>
/*
<behavior jsname="behavior_multiPlayer" description="Basic Multiplayer . Need Internet Connection">
</behavior>
*/

function isset(str) {
    return window[str] !== undefined;
}

function finishedRequest(dataReceived)
{
  ccbSetCopperCubeVariable('player_id', dataReceived);
  var s = ccbGetSceneNodeFromName('name');
  ccbSetSceneNodeProperty(s, "Text",dataReceived);
}

function finishedRequestData(dataReceived)
{
ccbSetCopperCubeVariable('data', dataReceived);
//print(dataReceived);

}

function setInitial()
{
  // add player
  // set player id
  ccbDoHTTPRequest("http://smartcubeit.co.za/bxc_multiplayer/unikey.php", finishedRequest);
  ccbDoHTTPRequest("http://smartcubeit.co.za/bxc_multiplayer/backend.php", finishedRequestData);
  // set player position
  var s = ccbGetSceneNodeFromName("player");
  var position = ccbGetSceneNodeProperty(s, "Position");
  ccbSetCopperCubeVariable('player_position', position);
  var rotation = ccbGetSceneNodeProperty(s, "Rotation");
  ccbSetCopperCubeVariable('player_rotation', rotation);
  //console.log('initial1');
}

function checkPlayerPosition()
{
  // Set flag
  var flag=0;
  // set player position
  var s = ccbGetSceneNodeFromName("player");

  var position = ccbGetSceneNodeProperty(s, "Position");
  var old_position=ccbGetCopperCubeVariable('player_position');
  if (old_position!==position ){var flag=1;}
  ccbSetCopperCubeVariable('player_position', position);
  
  var rotation = ccbGetSceneNodeProperty(s, "Rotation");
    var old_rotation=ccbGetCopperCubeVariable('player_rotation');
  if (old_rotation!==rotation){var flag=1;}
  ccbSetCopperCubeVariable('player_rotation', rotation);

  // actualizo en el server en caso de que exista algun cambio

  if (flag==1)
  {
  var player_id=ccbGetCopperCubeVariable('player_id');
  var player_data=escape("{"+player_id+";"+position+";"+rotation+"}");
  ccbDoHTTPRequest("http://smartcubeit.co.za/bxc_multiplayer/backend.php?data="+player_data, finishedRequestData);
  }else{
    ccbDoHTTPRequest("http://smartcubeit.co.za/bxc_multiplayer/backend.php", finishedRequestData);
  }
}

function playerExistInData(player_target)
{//playerExist-------INI
var flag=0;
var data=ccbGetCopperCubeVariable('data');
var player=data.split("},{");
for (i=0; i<player.length;i=i+1)
{
var player_info=player[i];
var player_info=player_info.split("{").join("");
var player_info=player_info.split("}").join("");
var player_info=player_info.split("(").join("");
var player_info=player_info.split(")").join("");
var player_info_value=player_info.split(";");

if (player_info_value[0]==player_target)
    {
        var flag=1;
    }
   //if ( !playerExistInScene(player_info_value[0]) ){}
}
if (flag==1){return true;}else{return false;}
}//playerExist-------END

//------------------------------
function playersExistsInScene()
{//playerExistInScene-------INI
var player_id=ccbGetCopperCubeVariable('player_id');
var root = ccbGetSceneNodeFromName("players");
var count = ccbGetSceneNodeChildCount(root);

    for(var i=0; i<count; ++i)
    {
     var child = ccbGetChildSceneNode(root, i);
     var child_name = ccbGetSceneNodeProperty(child, "Name");
       if (child_name !=="player" && child_name !=="model1" && child_name !=="model2")
      {
        if (!playerExistInData(child_name)  && player_id!==child_name)
         {
          //borro el player 
          //console.log("borro "+child_name);
          ccbRemoveSceneNode( ccbGetSceneNodeFromName(child_name) );
         }
      }
    }
}//playerExistInScene-------END

//----------------------------
function playerExistInScene(player_target)
{
var player_id=ccbGetCopperCubeVariable('player_id');
var root = ccbGetSceneNodeFromName("players");
var count = ccbGetSceneNodeChildCount(root);

    for(var i=0; i<count; ++i)
    {
     var child = ccbGetChildSceneNode(root, i);
     var child_name = ccbGetSceneNodeProperty(child, "Name");
       if (child_name !=="player" && child_name !=="model1" && child_name !=="model2")
      {
        if (player_id!==child_name)
         {
           if (player_target==child_name){ return true; }
         }
      }
    }
return false;
}

//-----------------
function createNewPlayers()
{
ccbDoHTTPRequest("http://smartcubeit.co.za/bxc_multiplayer/backend.php", finishedRequestData);
var player_id=ccbGetCopperCubeVariable('player_id');
var data=ccbGetCopperCubeVariable('data');
if (!data){data="";}
var player=data.split("},{");

for (i=0; i<player.length;i=i+1)
 {
var player_info=player[i];
var player_info=player_info.split("{").join("");
var player_info=player_info.split("}").join("");
var player_info=player_info.split("(").join("");
var player_info=player_info.split(")").join("");
var player_info_value=player_info.split(";");
    if (player_id!==player_info_value[0] && typeof player_info_value[0] !== "undefined")
       {
        //print ("---->"+player_info_value[0]);
           if ( !playerExistInScene(player_info_value[0]) && player_info_value[0].length!==0 && player_info_value[0]!==""){
            var sourceNode = ccbGetSceneNodeFromName("model1");
            var newscenenode = ccbCloneSceneNode(sourceNode);
            ccbSetSceneNodeProperty(newscenenode, "Name",player_info_value[0]);
            var newNode = ccbGetSceneNodeFromName(player_info_value[0]);
            if ( typeof newNode !== "undefined" ){
            var pos=player_info_value[1].split(",");
            var pos_current = ccbGetSceneNodeProperty(newNode, "Position");
            var posx=parseFloat(pos[0]);
            var posy=parseFloat(pos[1]);
            var posz=parseFloat(pos[2]);
            ccbSetSceneNodeProperty(newNode, "Position",posx,posy,posz);
            rot=player_info_value[2].split(",");
            var rotx=parseFloat(rot[0]);
            var roty=parseFloat(rot[1]);
            var rotz=parseFloat(rot[2]);            
            ccbSetSceneNodeProperty(newNode, "Rotation",rotx,roty,rotz);
            ccbSetSceneNodeProperty(newNode, "Visible", true);
            //console.log("Creo A:"+player_info_value[1]);
            }


           }else{
            /*
            var s = ccbGetSceneNodeFromName(player_info_value[0]);
            var pos=player_info_value[1].split(",");
            var posx=parseFloat(pos[0]);
            var posy=parseFloat(pos[1]);
            var posz=parseFloat(pos[2]);
            var vel_to_target=0.1;
            var pos_current = ccbGetSceneNodeProperty(s, "Position");
            var pos_currentx=0;
            var pos_currenty=0;
            var pos_currentz=0;
            //console.log("actualizando Actual:"+pos_current.x+"To"+posx);
            if (pos_current.x<posx){pos_currentx=pos_current.x+vel_to_target;}
            if (pos_current.x>posx){pos_currentx=pos_current.x-vel_to_target;}

            if (pos_current.y<posx){pos_currenty=pos_current.y+vel_to_target;}
            if (pos_current.y>posx){pos_currenty=pos_current.y-vel_to_target;}

            if (pos_current.z<posx){pos_currentz=pos_current.z+vel_to_target;}
            if (pos_current.z>posx){pos_currentz=pos_current.z-vel_to_target;}            
            
            ccbSetSceneNodeProperty(s, "Position",pos_currentx,pos_currenty,pos_currentz);
            rot=player_info_value[2].split(",");
            var rotx=parseFloat(rot[0]);
            var roty=parseFloat(rot[1]);
            var rotz=parseFloat(rot[2]);            
            ccbSetSceneNodeProperty(s, "Rotation",rotx,roty,rotz);            
            //ccbSetSceneNodeProperty(s, "Rotation",player_info_value[2]);
            //print("posiciono objeto "+player_info_value[0]+": "+player_info_value[1]+"x"+player_info_value[2]);
            */
           }
       }
       
 }
}


function refresh()
{

var player_id=ccbGetCopperCubeVariable('player_id');
var data=ccbGetCopperCubeVariable('data');
try{
  data=data+"";
  if (typeof data !== "undefined"){
    var player=data.split("},{");
  }else{
    var player = "";
  }
  
  
}catch(e){
  console.log(e);
}



for (i=0; i<player.length;i=i+1)
 {
    var player_info=player[i];
    var player_info=player_info.split("{").join("");
    var player_info=player_info.split("}").join("");
    var player_info=player_info.split("(").join("");
    var player_info=player_info.split(")").join("");
    var player_info_value=player_info.split(";");
      if (player_id!==player_info_value[0] && player_info_value.length)
         {
          //print ("---->"+player_info_value[0]);
          if (typeof player_info_value[1] !== "undefined" && typeof player_info_value[0] !== "undefined" ){

              if (typeof player_info_value[0] !== "undefined"){
                var s = ccbGetSceneNodeFromName(player_info_value[0]);
              }
              var pos=player_info_value[1].split(",");
              var posx=parseFloat(pos[0]);
              var posy=parseFloat(pos[1]);
              var posz=parseFloat(pos[2]);
              var vel_to_target=1;
              
              if (typeof s !== "undefined"){
                var pos_current = ccbGetSceneNodeProperty(s, "Position");
              }
              var pos_currentx=0;
              var pos_currenty=0;
              var pos_currentz=0;
              var magnet=1;
          }

              //console.log("actualizando Actual "+player_info_value[0]+":"+pos_current.y+"To"+posy);
              if (typeof pos_current !== "undefined" )
              {
                if (pos_current.x<posx ){pos_currentx=pos_current.x+vel_to_target;}
                if (pos_current.x>posx ){pos_currentx=pos_current.x-vel_to_target;}
                if (pos_current.x>posx-magnet && pos_current.x<posx+magnet){ pos_currentx=posx;}

                if (pos_current.y<posy){pos_currenty=pos_current.y+vel_to_target;}
                if (pos_current.y>posy){pos_currenty=pos_current.y-vel_to_target;}
                if (pos_current.y>posy-magnet && pos_current.y<posy+magnet){ pos_currenty=posy;}              

                if (pos_current.z<posz){pos_currentz=pos_current.z+vel_to_target;}
                if (pos_current.z>posz){pos_currentz=pos_current.z-vel_to_target;}            
                if (pos_current.z>posz-magnet && pos_current.z<posz+magnet){ pos_currentz=posz;}              

                if (typeof s !== "undefined"){
                  ccbSetSceneNodeProperty(s, "Position",pos_currentx,pos_currenty,pos_currentz);
                  rot=player_info_value[2].split(",");
                  var rotx=parseFloat(rot[0]);
                  var roty=parseFloat(rot[1]);
                  var rotz=parseFloat(rot[2]);            
                  ccbSetSceneNodeProperty(s, "Rotation",rotx,roty,rotz);            
                }


              }

              //ccbSetSceneNodeProperty(s, "Rotation",player_info_value[2]);
              //print("posiciono objeto "+player_info_value[0]+": "+player_info_value[1]+"x"+player_info_value[2]);
         }
         
  } 
}
//----------------------------------------------------------------------------------
behavior_multiPlayer = function()
{
  setInitial();
  this.counter=true;
  this.counter_check=true;
  this.counter_refresh=true;
  this.server_speed=25;
};

behavior_multiPlayer.prototype.onAnimate = function(node, timeMs)
{
  
  this.counter=this.counter+1;
  this.counter_check=this.counter_check+1;
  this.counter_refresh=this.counter_refresh+1;
  if (this.counter>this.server_speed){ this.counter=0;}
  if (this.counter_check>100){ this.counter_check=0;}
  if (this.counter_refresh>1){ this.counter_refresh=0;}
  //----------------
  //print (this.counter);
  if (this.counter==this.server_speed){ checkPlayerPosition();}
  if (this.counter_check==100){  createNewPlayers(); playersExistsInScene();}
  if ( timeMs>100){ refresh();}
  
}
<?php
header('Access-Control-Allow-Origin: *');
echo md5(uniqid(rand(), true));
?>
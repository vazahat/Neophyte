// CopperCube editor plugin that applies a random vertex color to a mesh

function randomVertexColor() {
    var meshnode = editorGetSelectedSceneNode();

    var bufferCount = ccbGetSceneNodeMeshBufferCount(meshnode);

    function getColor() {

        return color = "0x" + Math.random().toString(16).slice(2, 8);
    }

    getColor();

    if (bufferCount == 0)

        alert('The selected node has no 3D geometry.');

    else {
        for (var i = 0; i < bufferCount; ++i) {
            var vertexcount = ccbGetMeshBufferVertexCount(meshnode, i);

            for (var v = 0; v < vertexcount; ++v) {
                ccbSetMeshBufferVertexColor(meshnode, i, v, parseInt(Number(color), 10));
            }
        }
    }
}

editorRegisterMenuEntry("randomVertexColor()", "Apply random vertex color\tCtrl+P");
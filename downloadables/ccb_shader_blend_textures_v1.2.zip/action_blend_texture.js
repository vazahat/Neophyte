/*	Info 
	
    Extension Name	: Action Overlay texture
    Extension Type	: Action
    Author:			: Vazahat Khan (just_in_case)
    Date Created	: February 28, 2021
    Description		: Blend two  textures together with multiple blend modes. 
	
*/
/* 	Donate
	
    If you like my work, please consider "buy me a cup of coffee" to support me.
    You can do that via PayPal :)
	
    PayPal  - http://paypal.me/Vazahat
	Itch.io - https://vazahat.itch.io/
    Youtube - https://www.youtube.com/channel/UC_yfoGEKkmY63tnyy6hR7ZQ
    Website - https://neophyte.cf
    Discord - https://discord.gg/RKcq89S7uA
	

*/
/*	Changelog v1.2
	 			
	[February 17, 2022]	- Added webGL shader support
						- Added ability to specify affecting node
						- Added ability to affect all the materials

/* Usage
	Attach the shader action to any behavior and fill the parameters, select the affecting node (the node on which you want to apply the shader to).
	Check if you want to affect all the materials of the texture or you can uncheck it and specify a specific material index to be affected by the shader.
	Select the base material type, you can choose 12,13,14 for transparency features and 0 for solid material. Then check the blending mode to blend the textures with.
	there are 4 modes available, Add, Subtract, Multiply and Divide. You also need to supply a second texture for affecting materials. You can do so by going in irredit/irrlicht
	properties of your scenenode. 
*/
/*  <action jsname="action_blend_texture" description="Blend two textures together">
	  <property name="Affecting_node" type="scenenode"/>
	  <property name="Affect_all_material" type="bool" default="true" />
	  <property name="Affecting_material" type="int" default="1" />
	  <property name="Base_material_type" type="int" default="13" />
	  <property name="Blend_Add" type="bool" default="false" />
	  <property name="Blend_Multiply" type="bool" default="false" />
	  <property name="Blend_Subtract" type="bool" default="false" />
	  <property name="Blend_Divide" type="bool" default="false" />
	  
    </action>
*/
action_blend_texture = function()
{
};


action_blend_texture.prototype.execute = function(currentNode)
{	
	var platform = ccbGetPlatform();
	this.Affecting_material -= 1 ;
if(platform == "windows"  || platform ==  "macosx")
{

	//For Blend Mode Type Add
	if(this.Blend_Add == true){
		var vertexShader_Add = 
		"float4x4 mWorldViewProj;  // World * View * Projection \n" + 
		"float4x4 mInvWorld;       // Inverted world matrix	 	\n" + 
		"float4x4 mTransWorld;     // Transposed world matrix	\n" + 
		"														\n" + 
		"// Vertex shader output structure						\n" + 
		"struct VS_OUTPUT										\n" + 
		"{														\n" + 
		"	float4 Position   : POSITION;   // vertex position 	\n" + 
		"	float4 Diffuse    : COLOR0;     // vertex diffuse 	\n" + 
		"	float2 TexCoord   : TEXCOORD0;  // tex coords		\n" + 
		"};														\n" + 
		"														\n" + 
		"VS_OUTPUT main      ( in float4 vPosition : POSITION,	\n" + 
		"                      in float3 vNormal   : NORMAL,	\n" + 
		"                      float2 texCoord     : TEXCOORD0 )\n" + 
		"{														\n" + 
		"	VS_OUTPUT Output;									\n" + 
		"														\n" + 
		"	// transform position to clip space 				\n" + 
		"	Output.Position = mul(vPosition, mWorldViewProj);	\n" + 
		"														\n" + 
		"	// transformed normal would be this:				\n" + 
		"	float3 normal = mul(vNormal, mInvWorld);			\n" + 
		"														\n" + 
		"	// position in world coodinates	would be this:		\n" + 
		"	// float3 worldpos = mul(mTransWorld, vPosition);	\n" + 
		"														\n" + 
		"	Output.Diffuse = float4(1.0, 1.0, 1.0, 1.0);		\n" + 
		"	Output.TexCoord = texCoord;							\n" + 
		"														\n" + 
		"	return Output;										\n" + 
		"}														";

		var fragmentShader_Add = 
		"struct PS_OUTPUT								\n" + 
		"{												\n" + 
		"    float4 RGBColor : COLOR0; 		  			\n" +	
		"};												\n" +
		"												\n" + 
		"sampler2D tex0;								\n" + 
		"sampler2D tex1;								\n" + 
		"												\n" +
		"PS_OUTPUT main( float2 TexCoord : TEXCOORD0,	\n" +
		"                float4 Position : POSITION,	\n" +
		"                float4 Diffuse  : COLOR0 ) 	\n" +
		"{ 												\n" +
		"	PS_OUTPUT Output;							\n" +
		"	float4 col1 = tex2D( tex0, TexCoord );  	\n" + 
		"	float4 col2 = tex2D( tex1, TexCoord );  	\n" + 
		"	Output.RGBColor = abs(col1+col2);			\n" + 
		"	return Output;								\n" +
		"}";
		
		var newMaterial_Add = ccbCreateMaterial(vertexShader_Add, fragmentShader_Add,this.Base_material_type, null);
		//Check Material index and apply to specified mat index or to all the materials.
   	 	var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

    	for (var i = 0; i < matCount; ++i)
		{
        	if (this.Affect_all_material)
			{
        	    ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial_Add);
       		}
       		else { ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial_Add); }
    	}
		
	}
	
	
	//For Blend Mode Type multiply
	if(this.Blend_Multiply == true){
		var vertexShader_Multiply = 
		"float4x4 mWorldViewProj;  // World * View * Projection \n" + 
		"float4x4 mInvWorld;       // Inverted world matrix	 	\n" + 
		"float4x4 mTransWorld;     // Transposed world matrix	\n" + 
		"														\n" + 
		"// Vertex shader output structure						\n" + 
		"struct VS_OUTPUT										\n" + 
		"{														\n" + 
		"	float4 Position   : POSITION;   // vertex position 	\n" + 
		"	float4 Diffuse    : COLOR0;     // vertex diffuse 	\n" + 
		"	float2 TexCoord   : TEXCOORD0;  // tex coords		\n" + 
		"};														\n" + 
		"														\n" + 
		"VS_OUTPUT main      ( in float4 vPosition : POSITION,	\n" + 
		"                      in float3 vNormal   : NORMAL,	\n" + 
		"                      float2 texCoord     : TEXCOORD0 )\n" + 
		"{														\n" + 
		"	VS_OUTPUT Output;									\n" + 
		"														\n" + 
		"	// transform position to clip space 				\n" + 
		"	Output.Position = mul(vPosition, mWorldViewProj);	\n" + 
		"														\n" + 
		"	// transformed normal would be this:				\n" + 
		"	float3 normal = mul(vNormal, mInvWorld);			\n" + 
		"														\n" + 
		"	// position in world coodinates	would be this:		\n" + 
		"	// float3 worldpos = mul(mTransWorld, vPosition);	\n" + 
		"														\n" + 
		"	Output.Diffuse = float4(1.0, 1.0, 1.0, 1.0);		\n" + 
		"	Output.TexCoord = texCoord;							\n" + 
		"														\n" + 
		"	return Output;										\n" + 
		"}														";

		var fragmentShader_Multiply = 
		"struct PS_OUTPUT								\n" + 
		"{												\n" + 
		"    float4 RGBColor : COLOR0; 		  			\n" +	
		"};												\n" +
		"												\n" + 
		"sampler2D tex0;								\n" + 
		"sampler2D tex1;								\n" + 
		"												\n" +
		"PS_OUTPUT main( float2 TexCoord : TEXCOORD0,	\n" +
		"                float4 Position : POSITION,	\n" +
		"                float4 Diffuse  : COLOR0 ) 	\n" +
		"{ 												\n" +
		"	PS_OUTPUT Output;							\n" +
		"	float4 col1 = tex2D( tex0, TexCoord );  	\n" + 
		"	float4 col2 = tex2D( tex1, TexCoord );  	\n" + 
		"	Output.RGBColor = abs(col1*col2);			\n" + 
		"	return Output;								\n" +
		"}";

		var newMaterial_Multiply = ccbCreateMaterial(vertexShader_Multiply, fragmentShader_Multiply, this.Base_material_type, null);
		//Check Material index and apply to specified mat index or to all the materials.
		var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

    	for (var i = 0; i < matCount; ++i)
		{
        	if (this.Affect_all_material)
			{
        	    ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial_Multiply);
       		}
       		else { ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial_Multiply); }
    	}
	}
	
	//For Blend Mode Type Subtract
	if(this.Blend_Subtract == true){
		var vertexShader_Subtract = 
		"float4x4 mWorldViewProj;  // World * View * Projection \n" + 
		"float4x4 mInvWorld;       // Inverted world matrix	 	\n" + 
		"float4x4 mTransWorld;     // Transposed world matrix	\n" + 
		"														\n" + 
		"// Vertex shader output structure						\n" + 
		"struct VS_OUTPUT										\n" + 
		"{														\n" + 
		"	float4 Position   : POSITION;   // vertex position 	\n" + 
		"	float4 Diffuse    : COLOR0;     // vertex diffuse 	\n" + 
		"	float2 TexCoord   : TEXCOORD0;  // tex coords		\n" + 
		"};														\n" + 
		"														\n" + 
		"VS_OUTPUT main      ( in float4 vPosition : POSITION,	\n" + 
		"                      in float3 vNormal   : NORMAL,	\n" + 
		"                      float2 texCoord     : TEXCOORD0 )\n" + 
		"{														\n" + 
		"	VS_OUTPUT Output;									\n" + 
		"														\n" + 
		"	// transform position to clip space 				\n" + 
		"	Output.Position = mul(vPosition, mWorldViewProj);	\n" + 
		"														\n" + 
		"	// transformed normal would be this:				\n" + 
		"	float3 normal = mul(vNormal, mInvWorld);			\n" + 
		"														\n" + 
		"	// position in world coodinates	would be this:		\n" + 
		"	// float3 worldpos = mul(mTransWorld, vPosition);	\n" + 
		"														\n" + 
		"	Output.Diffuse = float4(1.0, 1.0, 1.0, 1.0);		\n" + 
		"	Output.TexCoord = texCoord;							\n" + 
		"														\n" + 
		"	return Output;										\n" + 
		"}														";

		var fragmentShader_Subtract = 
		"struct PS_OUTPUT								\n" + 
		"{												\n" + 
		"    float4 RGBColor : COLOR0; 		  			\n" +	
		"};												\n" +
		"												\n" + 
		"sampler2D tex0;								\n" + 
		"sampler2D tex1;								\n" + 
		"												\n" +
		"PS_OUTPUT main( float2 TexCoord : TEXCOORD0,	\n" +
		"                float4 Position : POSITION,	\n" +
		"                float4 Diffuse  : COLOR0 ) 	\n" +
		"{ 												\n" +
		"	PS_OUTPUT Output;							\n" +
		"	float4 col1 = tex2D( tex0, TexCoord );  	\n" + 
		"	float4 col2 = tex2D( tex1, TexCoord );  	\n" + 
		"	Output.RGBColor = abs(col1-col2);			\n" + 
		"	return Output;								\n" +
		"}";

		var newMaterial_Subtract = ccbCreateMaterial(vertexShader_Subtract, fragmentShader_Subtract, this.Base_material_type, null);
		//Check Material index and apply to specified mat index or to all the materials.
		var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

    	for (var i = 0; i < matCount; ++i)
		{
        	if (this.Affect_all_material)
			{
        	    ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial_Subtract);
       		}
       		else { ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial_Subtract); }
    	}
	}
	
	//For Blend Mode Type Divide
	if(this.Blend_Divide == true){
		var vertexShader_Divide = 
		"float4x4 mWorldViewProj;  // World * View * Projection \n" + 
		"float4x4 mInvWorld;       // Inverted world matrix	 	\n" + 
		"float4x4 mTransWorld;     // Transposed world matrix	\n" + 
		"														\n" + 
		"// Vertex shader output structure						\n" + 
		"struct VS_OUTPUT										\n" + 
		"{														\n" + 
		"	float4 Position   : POSITION;   // vertex position 	\n" + 
		"	float4 Diffuse    : COLOR0;     // vertex diffuse 	\n" + 
		"	float2 TexCoord   : TEXCOORD0;  // tex coords		\n" + 
		"};														\n" + 
		"														\n" + 
		"VS_OUTPUT main      ( in float4 vPosition : POSITION,	\n" + 
		"                      in float3 vNormal   : NORMAL,	\n" + 
		"                      float2 texCoord     : TEXCOORD0 )\n" + 
		"{														\n" + 
		"	VS_OUTPUT Output;									\n" + 
		"														\n" + 
		"	// transform position to clip space 				\n" + 
		"	Output.Position = mul(vPosition, mWorldViewProj);	\n" + 
		"														\n" + 
		"	// transformed normal would be this:				\n" + 
		"	float3 normal = mul(vNormal, mInvWorld);			\n" + 
		"														\n" + 
		"	// position in world coodinates	would be this:		\n" + 
		"	// float3 worldpos = mul(mTransWorld, vPosition);	\n" + 
		"														\n" + 
		"	Output.Diffuse = float4(1.0, 1.0, 1.0, 1.0);		\n" + 
		"	Output.TexCoord = texCoord;							\n" + 
		"														\n" + 
		"	return Output;										\n" + 
		"}														";

		var fragmentShader_Divide = 
		"struct PS_OUTPUT								\n" + 
		"{												\n" + 
		"    float4 RGBColor : COLOR0; 		  			\n" +	
		"};												\n" +
		"												\n" + 
		"sampler2D tex0;								\n" + 
		"sampler2D tex1;								\n" + 
		"												\n" +
		"PS_OUTPUT main( float2 TexCoord : TEXCOORD0,	\n" +
		"                float4 Position : POSITION,	\n" +
		"                float4 Diffuse  : COLOR0 ) 	\n" +
		"{ 												\n" +
		"	PS_OUTPUT Output;							\n" +
		"	float4 col1 = tex2D( tex0, TexCoord );  	\n" + 
		"	float4 col2 = tex2D( tex1, TexCoord );  	\n" + 
		"	Output.RGBColor = abs(col1/col2);			\n" + 
		"	return Output;								\n" +
		"}";

		var newMaterial_Divide = ccbCreateMaterial(vertexShader_Divide, fragmentShader_Divide, this.Base_material_type, null);
		//Check Material index and apply to specified mat index or to all the materials.
		var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

    	for (var i = 0; i < matCount; ++i)
		{
        	if (this.Affect_all_material)
			{
        	    ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial_Divide);
       		}
       		else { ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial_Divide); }
    	}
	}
}

// Shaders For WEBGL platforms::::::::
if(platform == "webgl")
{
	//For Blend Mode Type Add
	if(this.Blend_Add == true){
		var vertexShader_Add = 									
			"uniform mat4 worldviewproj;								\n" +
			"															\n" +
			"attribute vec4 vPosition;									\n" +
			"attribute vec4 vNormal;									\n" +
			"attribute vec4 vColor;										\n" +
			"attribute vec2 vTexCoord1;									\n" +
			"attribute vec2 vTexCoord2;									\n" +
			"															\n" +
			"varying vec4 v_color;										\n" +
			"varying vec2 v_texCoord1;									\n" +
			"varying vec2 v_texCoord2;									\n" +
			"															\n" +
			"void main()												\n" +
			"{															\n" +
			"	v_color = vColor;										\n" +
			"	gl_Position = worldviewproj * vPosition;				\n" +
			"	v_texCoord1 = vTexCoord1.st;							\n" +
			"	v_texCoord2 = vTexCoord2.st;							\n" +
			"}															";

			var fragmentShader_Add = 
			"uniform sampler2D texture1;								\n" +
			"uniform sampler2D texture2;								\n" +
			"															\n" +
			"varying vec2 v_texCoord1;									\n" +
			"varying vec2 v_texCoord2;									\n" +
			"															\n" +
			"void main()												\n" +
			"{															\n" +
			"	vec2 texCoord = vec2(v_texCoord1.s, v_texCoord1.t);		\n" +
			"	vec4 Col1 = texture2D(texture1, texCoord);				\n" +
			"	vec4 Col2 = texture2D(texture2, texCoord);				\n" +
			"	gl_FragColor = Col1 + Col2 ;							\n" +
			"}															\n";


		var newMaterial_Add = ccbCreateMaterial(vertexShader_Add, fragmentShader_Add,this.Base_material_type, null);
		//Check Material index and apply to specified mat index or to all the materials.
		var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

    	for (var i = 0; i < matCount; ++i)
		{
        	if (this.Affect_all_material)
			{
        	    ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial_Add);
       		}
       		else { ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial_Add); }
    	}
		
	}
	
	
	//For Blend Mode Type multiply
	if(this.Blend_Multiply == true){
		var vertexShader_Multiply = 									
			"uniform mat4 worldviewproj;								\n" +
			"															\n" +
			"attribute vec4 vPosition;									\n" +
			"attribute vec4 vNormal;									\n" +
			"attribute vec4 vColor;										\n" +
			"attribute vec2 vTexCoord1;									\n" +
			"attribute vec2 vTexCoord2;									\n" +
			"															\n" +
			"varying vec4 v_color;										\n" +
			"varying vec2 v_texCoord1;									\n" +
			"varying vec2 v_texCoord2;									\n" +
			"															\n" +
			"void main()												\n" +
			"{															\n" +
			"	v_color = vColor;										\n" +
			"	gl_Position = worldviewproj * vPosition;				\n" +
			"	v_texCoord1 = vTexCoord1.st;							\n" +
			"	v_texCoord2 = vTexCoord2.st;							\n" +
			"}															";

			var fragmentShader_Multiply = 
			"uniform sampler2D texture1;								\n" +
			"uniform sampler2D texture2;								\n" +
			"															\n" +
			"varying vec2 v_texCoord1;									\n" +
			"varying vec2 v_texCoord2;									\n" +
			"															\n" +
			"void main()												\n" +
			"{															\n" +
			"	vec2 texCoord = vec2(v_texCoord1.s, v_texCoord1.t);		\n" +
			"	vec4 Col1 = texture2D(texture1, texCoord);				\n" +
			"	vec4 Col2 = texture2D(texture2, texCoord);				\n" +
			"	gl_FragColor = Col1 * Col2 ;							\n" +
			"}															\n";

		var newMaterial_Multiply = ccbCreateMaterial(vertexShader_Multiply, fragmentShader_Multiply, this.Base_material_type, null);
		//Check Material index and apply to specified mat index or to all the materials.
		var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

    	for (var i = 0; i < matCount; ++i)
		{
        	if (this.Affect_all_material)
			{
        	    ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial_Multiply);
       		}
       		else { ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial_Multiply); }
    	}
	}
	
	//For Blend Mode Type Subtract
	if(this.Blend_Subtract == true){
		var vertexShader_Subtract = 									
			"uniform mat4 worldviewproj;								\n" +
			"															\n" +
			"attribute vec4 vPosition;									\n" +
			"attribute vec4 vNormal;									\n" +
			"attribute vec4 vColor;										\n" +
			"attribute vec2 vTexCoord1;									\n" +
			"attribute vec2 vTexCoord2;									\n" +
			"															\n" +
			"varying vec4 v_color;										\n" +
			"varying vec2 v_texCoord1;									\n" +
			"varying vec2 v_texCoord2;									\n" +
			"															\n" +
			"void main()												\n" +
			"{															\n" +
			"	v_color = vColor;										\n" +
			"	gl_Position = worldviewproj * vPosition;				\n" +
			"	v_texCoord1 = vTexCoord1.st;							\n" +
			"	v_texCoord2 = vTexCoord2.st;							\n" +
			"}															";

			var fragmentShader_Subtract = 
			"uniform sampler2D texture1;								\n" +
			"uniform sampler2D texture2;								\n" +
			"															\n" +
			"varying vec2 v_texCoord1;									\n" +
			"varying vec2 v_texCoord2;									\n" +
			"															\n" +
			"void main()												\n" +
			"{															\n" +
			"	vec2 texCoord = vec2(v_texCoord1.s, v_texCoord1.t);		\n" +
			"	vec4 Col1 = texture2D(texture1, texCoord);				\n" +
			"	vec4 Col2 = texture2D(texture2, texCoord);				\n" +
			"	gl_FragColor = Col1 - Col2 ;							\n" +
			"}															\n";

		var newMaterial_Subtract = ccbCreateMaterial(vertexShader_Subtract, fragmentShader_Subtract, this.Base_material_type, null);
		//Check Material index and apply to specified mat index or to all the materials.
		var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

    	for (var i = 0; i < matCount; ++i)
		{
        	if (this.Affect_all_material)
			{
        	    ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial_Subtract);
       		}
       		else { ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial_Subtract); }
    	}
	}
	
	//For Blend Mode Type Divide
	if(this.Blend_Divide == true){
		var vertexShader_Divide = 									
			"uniform mat4 worldviewproj;								\n" +
			"															\n" +
			"attribute vec4 vPosition;									\n" +
			"attribute vec4 vNormal;									\n" +
			"attribute vec4 vColor;										\n" +
			"attribute vec2 vTexCoord1;									\n" +
			"attribute vec2 vTexCoord2;									\n" +
			"															\n" +
			"varying vec4 v_color;										\n" +
			"varying vec2 v_texCoord1;									\n" +
			"varying vec2 v_texCoord2;									\n" +
			"															\n" +
			"void main()												\n" +
			"{															\n" +
			"	v_color = vColor;										\n" +
			"	gl_Position = worldviewproj * vPosition;				\n" +
			"	v_texCoord1 = vTexCoord1.st;							\n" +
			"	v_texCoord2 = vTexCoord2.st;							\n" +
			"}															";

			var fragmentShader_Divide = 
			"uniform sampler2D texture1;								\n" +
			"uniform sampler2D texture2;								\n" +
			"															\n" +
			"varying vec2 v_texCoord1;									\n" +
			"varying vec2 v_texCoord2;									\n" +
			"															\n" +
			"void main()												\n" +
			"{															\n" +
			"	vec2 texCoord = vec2(v_texCoord1.s, v_texCoord1.t);		\n" +
			"	vec4 Col1 = texture2D(texture1, texCoord);				\n" +
			"	vec4 Col2 = texture2D(texture2, texCoord);				\n" +
			"	gl_FragColor = Col1 / Col2 ;							\n" +
			"}															\n";

		var newMaterial_Divide = ccbCreateMaterial(vertexShader_Divide, fragmentShader_Divide, this.Base_material_type, null);
		//Check Material index and apply to specified mat index or to all the materials.
		var matCount = ccbGetSceneNodeMaterialCount(this.Affecting_node);

    	for (var i = 0; i < matCount; ++i)
		{
        	if (this.Affect_all_material)
			{
        	    ccbSetSceneNodeMaterialProperty(this.Affecting_node, i, 'Type', newMaterial_Divide);
       		}
       		else { ccbSetSceneNodeMaterialProperty(this.Affecting_node, this.Affecting_material, 'Type', newMaterial_Divide); }
    	}
	}


}		
	
}

// ***Author:- VAZAHAT PATHAN***

//        ****AKA****

 //   ****Just_in_case**** 

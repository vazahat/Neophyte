// Freezes the scale and rotation of the selected mesh and also normalizes all normals, 
// making lighting on WebGL and Flash faster and more accurate
// Version: 1.1
// Author: N.Gebhardt

vector3d.prototype.getLength = function() // fixing wrong get length implementation of old coppercube versions
{
	return Math.sqrt( this.x*this.x + this.y*this.y + this.z*this.z );
}

function freezeScale_rotate(vect, rotation)
{
	var pirad = 3.14159265358 / 180.0;
	
	var cr = Math.cos( rotation.x * pirad );
	var sr = Math.sin( rotation.x * pirad);
	var cp = Math.cos( rotation.y * pirad);
	var sp = Math.sin( rotation.y * pirad);
	var cy = Math.cos( rotation.z * pirad);
	var sy = Math.sin( rotation.z * pirad);

	var M_0_ = ( cp*cy );
	M_1_ = ( cp*sy );
	M_2_ = ( -sp );

	var srsp = sr*sp;
	var crsp = cr*sp;

	M_4_ = ( srsp*cy-cr*sy );
	M_5_ = ( srsp*sy+cr*cy );
	M_6_ = ( sr*cp );

	M_8_ = ( crsp*cy+sr*sy );
	M_9_ = ( crsp*sy-sr*cy );
	M_10_ = ( cr*cp );

	var tmpx = vect.x;
	var tmpy = vect.y;
	var tmpz = vect.z;

	vect.x = tmpx*M_0_ + tmpy*M_4_ + tmpz*M_8_;
	vect.y = tmpx*M_1_ + tmpy*M_5_ + tmpz*M_9_;
	vect.z = tmpx*M_2_ + tmpy*M_6_ + tmpz*M_10_;
}

function freezeScale(alsoFreezeRotation)
{
	var meshnode = editorGetSelectedSceneNode();
	var bufferCount = ccbGetSceneNodeMeshBufferCount(meshnode);
	if (bufferCount == 0)
	  alert('The selected node has no 3D geometry.');
	else
	{
	  var scale = ccbGetSceneNodeProperty(meshnode, "Scale");
	  var rotation = ccbGetSceneNodeProperty(meshnode, "Rotation");
	  
	  for (var i=0; i<bufferCount; ++i)
	  {
		ccbSetSceneNodeMaterialProperty(meshnode, i, "Type", 0);
		
		var vertexcount = ccbGetMeshBufferVertexCount(meshnode, i);
		for (var v=0; v<vertexcount; ++v)
		{
		   var nrm = ccbGetMeshBufferVertexNormal(meshnode, i, v);
		
		   if (nrm != null)
		   {
				nrm.normalize();
				ccbSetMeshBufferVertexNormal(meshnode, i, v, nrm);
		   }
		   
		   var pos = ccbGetMeshBufferVertexPosition(meshnode, i, v);
		   if (pos != null)
		   {
				pos.x *= scale.x;
				pos.y *= scale.y;
				pos.z *= scale.z;
				
				if (alsoFreezeRotation)
					freezeScale_rotate(pos, rotation);
				
				ccbSetMeshBufferVertexPosition(meshnode, i, v, pos);
		   }
		   
		   //ccbSetMeshBufferVertexColor(meshnode, i, v, 0xffffffff);
		}
	  }  
	  
	  ccbSetSceneNodeProperty(meshnode, "Rotation", 0.0, 0.0, 0.0);
	  ccbSetSceneNodeProperty(meshnode, "Scale", 1.0, 1.0, 1.0);
	  ccbUpdateSceneNodeBoundingBox(meshnode);
	}
}

// add the function to the plugin menu
editorRegisterMenuEntry("freezeScale(true)", "Freeze scale and normalize normals of selected mesh\tCtrl+K");

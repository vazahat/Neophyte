/*  <action jsname="action_Directional_enemy" description="Create a 2D 8 directional enemy">
      <property name="Player" type="scenenode" />
	  <property name="Enemy" type="scenenode" />
	  <property name="Variable" type="string" default="Enemy1" />
	  <property name="UP_Animation" type="scenenode" />
	  <property name="DOWN_Animation" type="scenenode" />
	  <property name="LEFT_Animation" type="scenenode" />
	  <property name="RIGHT_Animation" type="scenenode" />
	  <property name="UP_RIGHT_Animation" type="scenenode" />
	  <property name="UP_LEFT_Animation" type="scenenode" />
	  <property name="DOWN_RIGHT_Animation" type="scenenode" />
	  <property name="DOWN_LEFT_Animation" type="scenenode" />
	 
    </action>
*/

action_Directional_enemy = function()
{
};

action_Directional_enemy.prototype.execute = function(currentNode)
{
	
	var position = ccbGetSceneNodeProperty(this.Player, "Position");
	var rotation = ccbGetSceneNodeProperty(this.Player, "Rotation");
	var target_position = ccbGetSceneNodeProperty(this.Enemy, "Position");
	var target_rotation = ccbGetSceneNodeProperty(this.Enemy, "Rotation");
	var animation = ccbGetCopperCubeVariable(this.variable)

	
	if (position.z < target_position.z && position.x > target_position.x+50)
		ccbSetCopperCubeVariable(this.variable, "down_right")
	if (position.z < target_position.z && position.x < target_position.x-50)
		ccbSetCopperCubeVariable(this.variable, "down_left")
	if (position.z < target_position.z && position.x > target_position.x-10 && position.x < target_position.x+10)
		ccbSetCopperCubeVariable(this.variable, "down")
	if (position.x < target_position.x && position.z > target_position.z-10 && position.z < target_position.z+10)
		ccbSetCopperCubeVariable(this.variable, "left")
	if (position.z > target_position.z && position.x < target_position.x-50)
		ccbSetCopperCubeVariable(this.variable, "up_left")
	if (position.z > target_position.z && position.x > target_position.x+50)
		ccbSetCopperCubeVariable(this.variable, "up_right")
	if (position.z > target_position.z && position.x > target_position.x-10 && position.x < target_position.x+10)
		ccbSetCopperCubeVariable(this.variable, "up")
	if (position.x > target_position.x && position.z > target_position.z-10 && position.z < target_position.z+10)
		ccbSetCopperCubeVariable(this.variable, "right")
	if (animation == "down")
		ccbSetSceneNodeProperty(this.DOWN_Animation, "Visible", true);
	else ccbSetSceneNodeProperty(this.DOWN_Animation, "Visible", false);
	if (animation == "up")
		ccbSetSceneNodeProperty(this.UP_Animation, "Visible", true);
	else ccbSetSceneNodeProperty(this.UP_Animation, "Visible", false);
	if (animation == "left")
		ccbSetSceneNodeProperty(this.LEFT_Animation, "Visible", true);
	else ccbSetSceneNodeProperty(this.LEFT_Animation, "Visible", false);
	if (animation == "right")
		ccbSetSceneNodeProperty(this.RIGHT_Animation, "Visible", true);
	else ccbSetSceneNodeProperty(this.RIGHT_Animation, "Visible", false);
	if (animation == "up_left")
		ccbSetSceneNodeProperty(this.UP_LEFT_Animation, "Visible", true);
	else ccbSetSceneNodeProperty(this.UP_LEFT_Animation, "Visible", false);
	if (animation == "down_left")
		ccbSetSceneNodeProperty(this.DOWN_LEFT_Animation, "Visible", true);
	else ccbSetSceneNodeProperty(this.DOWN_LEFT_Animation, "Visible", false);
	if (animation == "up_right")
		ccbSetSceneNodeProperty(this.UP_RIGHT_Animation, "Visible", true);
	else ccbSetSceneNodeProperty(this.UP_RIGHT_Animation, "Visible", false);
    if (animation == "down_right")
		ccbSetSceneNodeProperty(this.DOWN_RIGHT_Animation, "Visible", true);
	else ccbSetSceneNodeProperty(this.DOWN_RIGHT_Animation, "Visible", false);
	
	if (animation == "")
		ccbSetCopperCubeVariable(this.variable, "down")
}

// ***Author:- VAZAHAT PATHAN***

//        ****AKA****

 //   ****Just_in_case**** 

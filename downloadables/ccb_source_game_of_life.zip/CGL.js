/* 
 * (C) Smn Mhmdy, (smarturl.it/SmnMhmdy \\ autosam.sm@gmail.com \\ discord.gg/e6TpKsq)
 * 
 * Conway's Game of life simulator
 * Written in one day, I'm sure it can be optimized to make it more performant.
*/

var Grid, Grid3d, GridScale = 10;
var Cols = 50, Rows = 50, Guide = true;
var StartSim = false, Generation = 0, LastGeneration = 0;
var scrWidth, scrHeight;
var InfoBarContainer = ccbGetSceneNodeFromName("InfoBarContainer"), InfoBar = ccbGetChildSceneNode(InfoBarContainer, 0);
var CellPrefab = ccbGetSceneNodeFromName("CellPrefab");
var bAllowDrawing = true;
var viewMode = 2, tiltMode = false, inputString = "", inputString_p = /[A-Z]|[1-9]/;
var mDown, mDownR;
var relativeY = 0, relativeX = 0;
var Mouse = {
    X: 0, 
    Y: 0,
};
var MouseOnGrid = {
    X: 0,
    Y: 0,
};
Time = {
    Step: 100, // time between each step
    Start: 0,
    Now: 0,
};

scrWidth = ccbGetScreenWidth();
scrHeight = ccbGetScreenHeight();

// // setting grid based on screen res
// var Cols = Math.round(ccbGetScreenWidth() / GridScale);
// var Rows = Math.round(ccbGetScreenHeight() / GridScale);

var drawnCells3d = [];
for (var dc3d_x = 0; dc3d_x < Cols; dc3d_x++)
    drawnCells3d[dc3d_x] = [];

Start();
function Start() { // starting function
    // creating the starting grid
    Grid = fGrid(Cols, Rows, 0);
    Grid3d = fGrid3d(Cols, Rows, 0);
    Time.Start = new Date().getTime();
}

function Update() { // runs each frame
    Time.Now = new Date().getTime();

    if (viewMode == 3) bAllowDrawing = false;
    else bAllowDrawing = true;

    //scrWidth = ccbGetScreenWidth();
    //scrHeight = ccbGetScreenHeight();

    Mouse.X = Math.round(ccbGetMousePosX() / GridScale) * GridScale - relativeX;
    Mouse.Y = Math.round(ccbGetMousePosY() / GridScale) * GridScale - relativeY;

    MouseOnGrid.X = Mouse.X / GridScale - 1;
    MouseOnGrid.Y = Mouse.Y / GridScale - 1;

    // mouse indicator
    if (Mouse.X <= Cols * GridScale - relativeX && Mouse.Y <= Rows * GridScale - relativeY && Mouse.X >= 0 && Mouse.Y >= 0)
        var MouseInGrid = true;
    else
        var MouseInGrid = false;

    // drawing and erasing
    if (MouseInGrid && bAllowDrawing) {
        if (mDown)
            DrawCell(MouseOnGrid.X, MouseOnGrid.Y);
        if (mDownR)
            EraseCell(MouseOnGrid.X, MouseOnGrid.Y);

        ccbDrawColoredRectangle(0xffffffff, Mouse.X - GridScale + relativeX, Mouse.Y - GridScale + relativeY, Mouse.X + relativeX, Mouse.Y + relativeY);
    }
    
    // drawing the grid cells
    var aliveCells = 0;
    for (x = 0; x < Cols; x++)
        for (y = 0; y < Rows; y++) {
            if (Grid[x][y]) {
                aliveCells++;
                if((x * GridScale) + relativeX > (Cols * GridScale) - relativeX/GridScale) {
                    continue;
                }
                if(viewMode == 2)
                    ccbDrawColoredRectangle(0x77ffffff, 
                        x * GridScale + relativeX, 
                        y * GridScale + relativeY, 
                        x * GridScale + GridScale + relativeX, 
                        y * GridScale + GridScale + relativeY);
                //ccbDrawTextureRectangle("Textures//State_01.png", x * GridScale, y * GridScale, x * GridScale + GridScale, y * GridScale + GridScale);
            }
        }

    // drawing 3d cells
    if (viewMode == 3) {
        for (x = 0; x < Cols; x++)
            for (y = 0; y < Rows; y++) {
                if (Grid[x][y]) {
                    drawnCells3d[x][y] = Grid3d[x][y];
                    ccbSetSceneNodeProperty(Grid3d[x][y], "Visible", true);
                } else {
                    ccbSetSceneNodeProperty(drawnCells3d[x][y], "Visible", false);
                    drawnCells3d[x][y] = 0;
                }
            }
    }

    // drawing the grid guides
    if (Guide && viewMode == 2) {
        for (x = relativeX/GridScale; x < Clamp(Cols + relativeX/GridScale, 0, Cols); x++) {
            ccbDrawColoredRectangle(0x10ffffff, x * GridScale, relativeY, x * GridScale + 1, Rows * GridScale + relativeY);
        }
        for (y = relativeY/GridScale; y < Clamp(Rows + relativeY/GridScale, 0, Rows); y++) {
            ccbDrawColoredRectangle(0x10ffffff, relativeX, y * GridScale, Cols * GridScale + relativeX, y * GridScale + 1);
        }
    }

    // simulation
    if (Time.Now - Time.Start > Time.Step && StartSim) {
        Time.Start = new Date().getTime();
        Simulate();
    }

    // stopping the simulation if there are no alive cells
    if (!aliveCells) {
    	StartSim = false;
    	if(Generation)
    		LastGeneration = Generation;
    	Generation = 0;
    }

    // counting currently selected cell's neigbours
    if (!StartSim) {
        var currentNeighbours = GetNeighbours(MouseOnGrid.X, MouseOnGrid.Y);
    } else
        var currentNeighbours = "is running";

    // printing information
    var Info_State = (StartSim) ? "RUNNING" : "STOPPED";
    var Info = (!tiltMode) ? Info_State +
                "\n\nAliveCells: \t\t" + aliveCells +
                "\nGeneration: \t\t" + Generation + " (" + LastGeneration + ")" +
                "\nCollumns: \t\t" + Cols +
                "\nRows: \t\t" + Rows +
                "\nSimTime: \t\t" + Time.Step + "ms" +
                "\nCollumns: \t\t" + Cols +
                "\nGridScale: \t\t" + GridScale +
                "\nCell: \t\t" + MouseOnGrid.X + " . " + MouseOnGrid.Y +
                "\nNeighbours: \t\t" + currentNeighbours +
                "\nGridPosition: \t\t" + relativeX / GridScale + " / " + relativeY / GridScale +
                "\n\nPress Space to start and stop the simulation." +
                "\nPress X to step through the simulation." +
                "\nPress R to reset the simulation." +
                "\nPress V to toggle between 2d and 3d view." +
                "\nPress P to populate the simulation." +
                "\nPress + or - to change the size of the grid." +
                "\nPress S to save the current grid." +
                "\nPress O to load the saved grid." +
                "\nPress Tab to toggle the guide panel." +
                "\nPress ` (tilde key) to load from \"Models\" folder."+
                "\n\nScreen W/H: " + scrWidth + "/" + scrHeight
        : Info_State +
        "\n\nOpen lgc file from Models\\\n" + inputString.toLowerCase() + ".lgc"
        ;

    ccbSetSceneNodeProperty(InfoBar, "Text", Info);
}

function fGrid(col, row, state) { // 2d grid generator
    var Grid = [];
    for (x = 0; x < col; x++) {
        Grid[x] = [];
        for (y = 0; y < row; y++) {
            Grid[x][y] = state;
        }
    }
    return Grid;
}

function fGrid3d(col, row, state) { // 3d grid generator
    var Grid3d = [];
    for (x = 0; x < col; x++) {
        Grid3d[x] = [];
        for (y = 0; y < row; y++) {
            this.Instance = ccbCloneSceneNode(CellPrefab);
            ccbSetSceneNodeProperty(this.Instance, "Name", x + "_" + y);
            ccbSetSceneNodeProperty(this.Instance, "Position", new vector3d(x * 10 + 10, 10000, y * 10 + 10));

            if (state)
                ccbSetSceneNodeProperty(this.Instance, "Visible", true);
            else
                ccbSetSceneNodeProperty(this.Instance, "Visible", false);

            Grid3d[x][y] = this.Instance;
        }
    }
    return Grid3d;
}

function DrawCell(x, y) { // drawing on grid cell
    if(x < 0 || y < 0) return;
    Grid[x][y] = 1;
}

function EraseCell(x, y) { // erasing from grid cell
    Grid[x][y] = 0;
}

function Simulate() { // logic simulation
    // creating the next iteration's grid
    nGrid = fGrid(Cols, Rows, 0);
    Generation ++;

    for (x = 0; x < Cols; x++)
        for (y = 0; y < Rows; y++) {

            var n = GetNeighbours(x, y);

            // die
            if (n < 2 || n > 3)
                nGrid[x][y] = 0;
            // stay alive
            if (n == 2)
                nGrid[x][y] = (Grid[x][y]) ? 1 : 0;
            // born
            if (n === 3)
                nGrid[x][y] = 1;
        }
    Grid = nGrid;
}

function GetNeighbours(x, y) { // getting cells neighbours
    var neighbours = 0;
    for (_x = -1; _x <= 1; _x++)
        for (_y = -1; _y <= 1; _y++) {

            x_check = x + _x;
            y_check = y + _y;

            if (x_check < 0 || x_check >= Cols)
                continue;
            if (y_check < 0 || y_check >= Rows)
                continue;
            if (!_y && !_x) continue;

            if (Grid[x_check][y_check]) neighbours++;
        }
    return neighbours;
}

function Clamp(n, min, max) { // clamp
    if (n < min) n = min;
    if (n > max) n = max;
    return n;
}

function MouseDown(key) { // mouse down event handler
    if (key == 0)
        mDown = true;
    if (key == 1)
        mDownR = true;
}

function MouseUp(key) { // mouse up event handler
    if (key == 0)
        mDown = false;
    if (key == 1)
        mDownR = false;
}

function KeyDown(key) { // key down event handler
    var Char = String.fromCharCode(key);
    // print(Char + " " + key);
    if(key == 192){ // toggle tilt mode (for loading lgc files)
    	tiltMode = !tiltMode;
    	return;
    }
    // setting grid relative pos (buggy)
    if(key == 39){ // right
        relativeX += GridScale;
    }
    if(key == 37){ // left
        relativeX -= GridScale;
    }
    if(key == 40){ // up
        relativeY += GridScale;
    }
    if(key == 38){ // down
        relativeY -= GridScale;
    }
    if(tiltMode) { // in tilt mode
        if(!inputString_p.test(Char)) Char = '';
    	if(key == 13){ // loading lgc file from Models folder (enter)
	        StartSim = false;
	        var LoadString = ccbReadFileContent("Models\\" + inputString + ".lgc");
	        if (!LoadString) return;
	        var LoadStringParsed = LoadString.split("\n");
	        for (x = 0; x < Cols; x++) {
	            for (y = 0; y < Rows; y++) {
	                Grid[x][y] = parseInt(LoadStringParsed[x][y]);
	            }
	        }
	        tiltMode = false; // tilt mode off
	        return;
    	}
    	if(key == 8){ // backspace
    		inputString_n = "";
    		if(inputString)
	    		for(var i = 0; i < inputString.length - 1; i++){
	    			inputString_n = (!inputString_n) ? inputString[i] : inputString_n + inputString[i]; 
	    		}
	    	inputString = inputString_n;
    	} else { // input handler
	    	inputString = inputString + Char;
	    	return;
    	}
    }

    switch(Char){
    	case "X": // step through simulation
    		Simulate();
    		break; 
	    case "R": // reset grids to dead
	        Grid = fGrid(Cols, Rows, 0);
            relativeX = 0, relativeY = 0;
	        break;
	    case "P": // reset grid to alive
	    	Grid = fGrid(Cols, Rows, 1);
	    	break;
	    case "S": // save current grid
	    	if(viewMode == 2){
		        StartSim = false;
		        var SaveString;
		        for (x = 0; x < Cols; x++) {
		            SaveString = SaveString + "\n";
		            for (y = 0; y < Rows; y++) {
		                if (!x && !y)
		                    SaveString = Grid[x][y];
		                else
		                    SaveString = SaveString + "" + Grid[x][y];
		            }
		        }
		        ccbWriteFileContent("Model.lgc", SaveString);
	    	}
	    	break;
	    case "O": // load grid from "Model.lgc" in current directory
	        StartSim = false;
	        var LoadString = ccbReadFileContent("Model.lgc");
	        if (!LoadString) return;
	        var LoadStringParsed = LoadString.split("\n");
	        for (x = 0; x < Cols; x++) {
	            for (y = 0; y < Rows; y++) {
	                Grid[x][y] = parseInt(LoadStringParsed[x][y]);
	            }
	        }
	    	break;
	    case "V": // toggle perspective (2d mode and 3d mode)
	        var activeCam = ccbGetActiveCamera();
	        var activeCam_n = ccbGetSceneNodeProperty(activeCam, "Name");
	        if (!view2dCam) { // one time execution
	            var view2dCam = ccbGetSceneNodeFromName("c2d");
	            var view2dCam_n = ccbGetSceneNodeProperty(view2dCam, "Name");
	            var view3dCam = ccbGetSceneNodeFromName("c3d");
	            var Root = ccbGetRootSceneNode();
	            var dLight = ccbGetSceneNodeFromName("dLight");
	        }
	        ccbSetSceneNodeProperty(activeCam, "Visible", false);
	        if (activeCam_n == view2dCam_n) { // going 3d
	            viewMode = 3;
	            ccbSetSceneNodeProperty(view3dCam, "Visible", true);
	            ccbSetSceneNodeProperty(dLight, "Visible", true);
	            ccbSetSceneNodeProperty(Root, "Fog", false);
	            ccbSetSceneNodeProperty(Root, "BackgroundColor", 0, 0, 0);
	            ccbSetSceneNodeProperty(view3dCam, "Position", new vector3d(MouseOnGrid.X * 10, 10200, MouseOnGrid.Y * 10));
	            ccbSetSceneNodeProperty(view3dCam, "Target", new vector3d(MouseOnGrid.X * 10 - 100, 10000, MouseOnGrid.Y * 10));
	            ccbSetCursorVisible(false);
	            ccbSetActiveCamera(view3dCam);
	        } else { // going 2d
	            viewMode = 2;
	            ccbSetSceneNodeProperty(view2dCam, "Visible", true);
	            ccbSetSceneNodeProperty(dLight, "Visible", false);
	            ccbSetSceneNodeProperty(Root, "Fog", true);
	            ccbSetSceneNodeProperty(Root, "BackgroundColor", 77, 77, 77);
                ccbSetSceneNodeProperty(Root, "BackgroundColor", 26, 26, 26);
	            ccbSetCursorVisible(true);
	            ccbSetActiveCamera(view2dCam);
	        }
	    	break;
    }

    // non char codes
    if (key == 32) { // toggle simulation (space)
        StartSim = !StartSim;
    }
    if (key == 107) // grid upscale (+)
        GridScale++;
    if (key == 109 && GridScale > 1) // grid downscale (-)
        GridScale--;
    if (key == 9) { // toggle infobar (tab)
        ccbSetSceneNodeProperty(InfoBarContainer, "Visible", !ccbGetSceneNodeProperty(InfoBarContainer, "Visible"));
        Guide = ccbGetSceneNodeProperty(InfoBarContainer, "Visible");
    }
}

function KeyUp(key) { // key up event handler

}

// event registerers
ccbRegisterOnFrameEvent(Update);
ccbRegisterMouseDownEvent("MouseDown");
ccbRegisterMouseUpEvent("MouseUp");
ccbRegisterKeyDownEvent("KeyUp");
ccbRegisterKeyDownEvent("KeyDown");
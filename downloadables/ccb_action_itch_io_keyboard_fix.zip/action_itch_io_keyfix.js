/*	Info 
	
Extension Name	: Itch.io webGL keyboard fix
Extension Type	: Action
Author:			: Vazahat Khan (just_in_case)
Date updated	: June 21, 2022, 07:02 PM
Description		: A CopperCube action that solves the problem of keypress on itch.io when you publish your webGL game there. 

*/
/* 	Donate

If you like my work, please consider "buy me a cup of coffee" to support me.
You can do that via PayPal :)

PayPal: http://paypal.me/Vazahat
Discord Server :- https://discord.gg/RKcq89S7uA
YouTube :- https://www.youtube.com/GlitchedVelocity
Itch.io :- https://vazahat.itch.io/


*/
/*	

    USAGE:- Simply attach the action to your before first drawing do something behavior.

 */

/*	Changelog:-

[June 21, 2022]	- Created the action by setting the focus to the "3D area" Coppercube default name for webGL based games canvas window.


/*  <action jsname="action_itch_io_keyfix" description="itch.io keyboard fix">
</action>
*/

action_itch_io_keyfix = function()
{
};

action_itch_io_keyfix.prototype.execute = function(node)
{

    var playarea = document.getElementById('3darea'); // getting our window play area which is "3darea"
    playarea.setAttribute('tabindex','0'); 
    playarea.focus(); // Setting focus of our game to our playarea

}


/*End Of Code*/

// ***Author:- VAZAHAT PATHAN***

//        ****AKA****

//   ****Just_in_case**** 


// Above extension is written by Vazahat Khan (just_in_case) //
//You are not allowed to remove this License info or any attribution details//
//License info:-//
/* All rights are reserved to Vazahat Khan.
You are allowed to use this asset( code ) in your coppercube projects freely for commercial and personal use without removing the attribtution comments from the code*/
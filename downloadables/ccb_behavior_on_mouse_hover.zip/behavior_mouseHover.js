/*	Info 
	
    Extension Name	: Behavior Mouse Hover
    Extension Type	: Behavior
    Author:			: Vazahat Khan (just_in_case)
    Date Created	: January 11, 2022, 14:28
    Description		: Do something when mouse is over a 3D object. 
	
*/
/* 	Donate
	
    If you like my work, please consider "buy me a cup of coffee" to support me.
    You can do that via PayPal :)
	
    PayPal: http://paypal.me/Vazahat
    Itch.io - https://vazahat.itch.io/cc-shader-spritesheet-animation
    Youtube - https://www.youtube.com/channel/UC_yfoGEKkmY63tnyy6hR7ZQ
    Website - https://neophyte.cf
    Discord - https://discord.gg/RKcq89S7uA
	

*/
/*	Changelog

    [january 11, 2022]	- Created the behavior
                        - Fixed a bug that was causing the hover effect to be true when scene starts.
         

*/

/*  
  <behavior jsname="behavior_mouseHover" description="Do something when mouse hover on a 3D object">
    <property name="On_Which_Node" type="scenenode" />
    <property name="Action_On_Hover" type="action" />
    <property name="Action_when_not_hovering" type="action" />
  </behavior>
*/

// Constructor
behavior_mouseHover = function(){
    this.lastTime = 0;
    this.x = 1;
}

// Runs this code on every frame
behavior_mouseHover.prototype.onAnimate = function (node, Time){
    if(!this.node){
        this.node = node;
    }
    
    this.x++;

 var mouseX = ccbGetMousePosX();
 var mouseY = ccbGetMousePosY();
 
  // test collision

  var cube = this.On_Which_Node;   
  var endPoint3d = ccbGet3DPosFrom2DPos(mouseX, mouseY);
  var startPos3D = ccbGetSceneNodeProperty(ccbGetActiveCamera(), "Position");
 
  if(this.x >= 3) //  to fix a bug that was causing the hover to be true when the scene starts.
  {
  if (ccbDoesLineCollideWithBoundingBoxOfSceneNode(cube, startPos3D.x, startPos3D.y,
                          startPos3D.z, endPoint3d.x, endPoint3d.y, endPoint3d.z))
    {
      ccbInvokeAction(this.Action_On_Hover);
      this.x = 10;
    }
  else
  {
    ccbInvokeAction(this.Action_when_not_hovering);
  }
  }
}


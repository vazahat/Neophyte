// The following is a scripted behaviour for "CopperCube 3D".
//The Behaviour Provides an option to CopperCube Users, This behaviour provides an option to add "Cheats" to CopperCube Projects.
//This Behaviour is Created by a non-Programmer:- Vazahat Pathan.
/*
	<behavior jsname="behavior_consoleCheat" description="Console_Cheat_code">
		<property name="Cheat" type="string" default="VAZAHAT" />		
		<property name="Action" type="action" />
	</behavior>
*/

behavior_consoleCheat = function()
{
	this.CheatObject = null;
	this.Console = "";
};



behavior_consoleCheat.prototype.onAnimate = function(currentNode, timeMs)
{
	this.CheatObject = currentNode;
	
	return true;
}



behavior_consoleCheat.prototype.onKeyEvent = function(key, pressed, node)
{

	if (!pressed || this.CheatObject == null)
		return;
		
	if (!ccbGetSceneNodeProperty(this.CheatObject, "Visible"))
		return;
	
	
	if (key == 8)
	{
		if (pressed)		
			this.Console = this.Console.substring(0, this.Console.length - 1);
	}
	else	
	if (key >=	32)
	{	
		if (pressed)	
			this.Console += String.fromCharCode(key);
	}
	
	if (this.CheatObject != null)
	{
		ccbSetSceneNodeProperty(this.CheatObject, 'Draw Text', true);
		ccbSetSceneNodeProperty(this.CheatObject, 'Text', this.Console);
	}
	
	if (this.Cheat != '')
		ccbSetCopperCubeVariable(this.Cheat, this.Console);
	
	
	if (key == 13)
		{
			if (pressed)					
					if (this.Cheat == this.Console)							
						ccbInvokeAction(this.Action, node);	
						this.Console = "";
						ccbSetSceneNodeProperty(this.CheatObject, 'Text', this.Console);
		}		
	
}

//AUTHOR: VAZAHAT PATHAN aka Just_in_Case.....
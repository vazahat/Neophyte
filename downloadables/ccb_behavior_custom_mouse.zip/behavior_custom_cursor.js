/*	Info 
	
    Extension Name	: Behavior Custom Mouse
    Extension Type	: Behavior
    Author:			: Vazahat Khan (just_in_case)
    Date Created	: February 23, 2022, 14:28
    Description		: Allows you to create custom mouse cursor with bunch of different options. 
	
*/
/* 	Donate
	
    If you like my work, please consider "buy me a cup of coffee" to support me.
    You can do that via PayPal :)
	
    PayPal: http://paypal.me/Vazahat
    Itch.io - https://vazahat.itch.io/cc-shader-spritesheet-animation
    Youtube - https://www.youtube.com/channel/UC_yfoGEKkmY63tnyy6hR7ZQ
    Website - https://neophyte.cf
    Discord - https://discord.gg/RKcq89S7uA
	

*/
/*	Changelog

    [February 23, 2022]	- Created the base behavior
                        - Added use of 2D overlay as mouse cursor.
						- Added ability to treat the mouse cursor as crosshair, that is fixing it to the center of screen, regardless of
						  actual mouse position.
						- Instead of checking the collision with actual mouse location, checking it with the overlay to get acuurate results.
						- Added Target node parameter to be used for executing different action
						- Tested the behavior and fixed some bugs
						- Added action for left and right click. ( on mouse down only)
						- Added action for mouse hover and on when not hovering from one of my already created previous behavior.
						- Fixed some more bugs that were spotted when testing the final version.
         

*/

/*
	<behavior jsname="behavior_custom_cursor" description="Custom Mouse">
		<property name="Cursor_image_Overlay" type="scenenode"/>
		<property name="Target_Node" type="scenenode"/>
		<property name="Treat_as_Crosshair" type="bool" default="false" />
		<property name="Action_On_hover" type="action" />
		<property name="Action_when_not_hovering" type="action" />
		<property name="Action_On_left_click" type="action" />
		<property name="Action_On_right_click" type="action" />
	</behavior>
*/

behavior_custom_cursor = function()
{
	this.x = 1;
	this.left_Click = false;
	this.right_Click = false;
};

behavior_custom_cursor.prototype.onAnimate = function()
{
	this.x++;
	ccbSetCursorVisible(false);
	ccbSetSceneNodeProperty(this.Cursor_image_Overlay, "Position Mode",  "absolute (pixels)");
	var mouseX = ccbGetMousePosX();
	var mouseY = ccbGetMousePosY();
	var overlay_X = ccbGetSceneNodeProperty(this.Cursor_image_Overlay, "Pos X (pixels)");
	var overlay_Y = ccbGetSceneNodeProperty(this.Cursor_image_Overlay, "Pos Y (pixels)");
	var overlay_size_X = ccbGetSceneNodeProperty(this.Cursor_image_Overlay, "Width (pixels)");
	var endPoint3d = ccbGet3DPosFrom2DPos(overlay_X, overlay_Y);
	var startPos3D = ccbGetSceneNodeProperty(ccbGetActiveCamera(),"Position");
	var endPoint3dM = ccbGet3DPosFrom2DPos(overlay_X+(overlay_size_X/2), overlay_Y+(overlay_size_X/2));
   
   if(this.Treat_as_Crosshair)
   {
	   var screenX = ccbGetScreenWidth();
	   var screenY = ccbGetScreenHeight();
	   ccbSetSceneNodeProperty(this.Cursor_image_Overlay, "Pos X (pixels)", screenX/2);
	   ccbSetSceneNodeProperty(this.Cursor_image_Overlay, "Pos Y (pixels)", screenY/2);
   }
   else{
	   var mouseX = ccbGetMousePosX();
	   var mouseY = ccbGetMousePosY();
	   ccbSetSceneNodeProperty(this.Cursor_image_Overlay, "Position Mode",  "absolute (pixels)");
	   ccbSetSceneNodeProperty(this.Cursor_image_Overlay, "Pos X (pixels)", mouseX);
	   ccbSetSceneNodeProperty(this.Cursor_image_Overlay, "Pos Y (pixels)", mouseY);
   }
   
	//OnHover
	if(this.x >= 3) //  to fix a bug that was causing the hover to be true when the scene starts.
	{ 	

		if(!this.Treat_as_Crosshair)
		{
			if (ccbDoesLineCollideWithBoundingBoxOfSceneNode(this.Target_Node, startPos3D.x, startPos3D.y,startPos3D.z, endPoint3d.x, endPoint3d.y, endPoint3d.z))
			{
				if(!this.left_Click && !this.right_Click)
				{
					ccbInvokeAction(this.Action_On_hover);
					this.initiate_hover = true;
				}
			}
			else
			{
				
				{
					if(this.initiate_hover){ccbInvokeAction(this.Action_when_not_hovering)};
				}
			}
		}
		else // when cursor is set to be crosshair
		{
			if (ccbDoesLineCollideWithBoundingBoxOfSceneNode(this.Target_Node, startPos3D.x, startPos3D.y,startPos3D.z, endPoint3dM.x, endPoint3dM.y, endPoint3dM.z))
			{
				if(!this.left_Click && !this.right_Click)
				{
					ccbInvokeAction(this.Action_On_hover);
					this.initiate_hover = true;
				}
			}
			else
			{
				
				{
					if(this.initiate_hover){ccbInvokeAction(this.Action_when_not_hovering)};
				}
			}
		}
	}
	
}

behavior_custom_cursor.prototype.onMouseEvent = function(mouseEvent, mouseWheelDelta,node)
{
	var overlay_X = ccbGetSceneNodeProperty(this.Cursor_image_Overlay, "Pos X (pixels)");
	var overlay_Y = ccbGetSceneNodeProperty(this.Cursor_image_Overlay, "Pos Y (pixels)");
	var overlay_size_X = ccbGetSceneNodeProperty(this.Cursor_image_Overlay, "Width (pixels)");
	var endPoint3d = ccbGet3DPosFrom2DPos(overlay_X, overlay_Y);
	var startPos3D = ccbGetSceneNodeProperty(ccbGetActiveCamera(),"Position");
	var endPoint3dM = ccbGet3DPosFrom2DPos(overlay_X+(overlay_size_X/2), overlay_Y+(overlay_size_X/2));
	var endPoint3dL = ccbGet3DPosFrom2DPos(overlay_X+(overlay_size_X), overlay_Y+(overlay_size_X));
	if(mouseEvent == 5)
	{
		this.right_Click = true;
		
		if( ccbDoesLineCollideWithBoundingBoxOfSceneNode(this.Target_Node, startPos3D.x, startPos3D.y,startPos3D.z, endPoint3dM.x, endPoint3dM.y, endPoint3dM.z))
		{
			ccbInvokeAction(this.Action_On_right_click);
		}
		else if( ccbDoesLineCollideWithBoundingBoxOfSceneNode(this.Target_Node, startPos3D.x, startPos3D.y,startPos3D.z, endPoint3d.x, endPoint3d.y, endPoint3d.z))
		{
			if(!this.Treat_as_Crosshair){
				ccbInvokeAction(this.Action_On_right_click);}
		}
		else if( ccbDoesLineCollideWithBoundingBoxOfSceneNode(this.Target_Node, startPos3D.x, startPos3D.y,startPos3D.z, endPoint3dL.x, endPoint3dL.y, endPoint3dL.z))
		{
			if(!this.Treat_as_Crosshair){
				ccbInvokeAction(this.Action_On_right_click);}
		}
	}
	else if(mouseEvent == 4){this.right_Click = false;}
	if(mouseEvent == 3)
	{
		this.left_Click = true;
		
		if( ccbDoesLineCollideWithBoundingBoxOfSceneNode(this.Target_Node, startPos3D.x, startPos3D.y,startPos3D.z, endPoint3dM.x, endPoint3dM.y, endPoint3dM.z))
		{
			ccbInvokeAction(this.Action_On_left_click);
		}
		else if( ccbDoesLineCollideWithBoundingBoxOfSceneNode(this.Target_Node, startPos3D.x, startPos3D.y,startPos3D.z, endPoint3d.x, endPoint3d.y, endPoint3d.z))
		{
			if(!this.Treat_as_Crosshair){
				ccbInvokeAction(this.Action_On_left_click);}
		}
		else if( ccbDoesLineCollideWithBoundingBoxOfSceneNode(this.Target_Node, startPos3D.x, startPos3D.y,startPos3D.z, endPoint3dL.x, endPoint3dL.y, endPoint3dL.z))
		{
			if(!this.Treat_as_Crosshair){
				ccbInvokeAction(this.Action_On_left_click);}
		}
	}
	else if( mouseEvent == 2){this.left_Click = false;}
	
	
}
/*End Of Code*/
 
// Above extension is written by Vazahat Khan (just_in_case) //
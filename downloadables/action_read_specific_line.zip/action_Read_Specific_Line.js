// The following is a scripted action for "CopperCube 3D".
//The Behaviour Provides an option to CopperCube Users, This behaviour provides an option to  to read a specific line of a text from external file.
//This Behaviour is Created by a non-Programmer:- Vazahat Pathan.
/*
	<action jsname="action_Read_Specific_Line" description="Read a specific line of text from a file">
	  <property name="Filename" type="string" default="Filename.txt" description="Enter the Filemname to be entered"/>
      <property name="Line_to_print" type="int" default="6" description="Enter the no of line to be printed"/>
	  <property name="overlay" type="scenenode" />
	</action>
*/
action_Read_Specific_Line = function () {
};

action_Read_Specific_Line.prototype.execute = function (currentNode)
 { 
     // variables to be created
	 var text = ccbReadFileContent(this.Filename);
     var lines = text.split("\n");
     this.length = lines.length + 1 - this.Line_to_print;

     // draw the specified line on the 2D Overlay
     var renderlines = lines[lines.length-this.length];
     this.effect = renderlines;
	 ccbSetSceneNodeProperty(this.overlay, 'Draw Text', true);
	 ccbSetSceneNodeProperty(this.overlay, 'Text', this.effect);
	
};

// ***Author:- VAzAHAT PATHAN***

//        ****AKA****

 //   ****Just_in_case**** 